#!/bin/sh

exec ./test-ftello${EXEEXT} 1 2 < "$srcdir/test-ftello2.sh"
