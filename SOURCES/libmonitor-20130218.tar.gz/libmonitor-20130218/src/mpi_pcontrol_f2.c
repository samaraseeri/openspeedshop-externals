/*
 *  Override mpi_pcontrol__ in Fortran.
 *
 */

#include "config.h"
#include "common.h"
#include "monitor.h"

typedef void mpi_pcontrol_fcn_t(int level, int *ierror);
#ifdef MONITOR_STATIC
extern mpi_pcontrol_fcn_t  __real_mpi_pcontrol__;
#endif
static mpi_pcontrol_fcn_t  *real_mpi_pcontrol = NULL;

int
MONITOR_WRAP_NAME(mpi_pcontrol__)(int level, int *ierror)
{
    int count;

    MONITOR_DEBUG1("\n");
    MONITOR_GET_REAL_NAME_WRAP(real_mpi_pcontrol, mpi_pcontrol__);
    (*real_mpi_pcontrol)(level, ierror);
}
