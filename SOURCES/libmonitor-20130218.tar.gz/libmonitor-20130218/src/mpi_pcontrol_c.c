/*
 *  Override MPI_Pcontrol in C/C++.
 *
 *  
 */

#include "config.h"
#include "common.h"
#include "monitor.h"

typedef int mpi_pcontrol_fcn_t(int level);
#ifdef MONITOR_STATIC
extern mpi_pcontrol_fcn_t  __real_MPI_Pcontrol;
#endif
static mpi_pcontrol_fcn_t  *real_mpi_pcontrol = NULL;

int
MONITOR_WRAP_NAME(MPI_Pcontrol)(int level)
{
    int ret, count;

    MONITOR_DEBUG("level = %d\n", level);               \

    MONITOR_GET_REAL_NAME_WRAP(real_mpi_pcontrol, MPI_Pcontrol);
    ret = (*real_mpi_pcontrol)(level);
    monitor_mpi_pcontrol(level);


    return (ret);
}
