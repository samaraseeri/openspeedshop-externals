/****************************************************************************
 * Copyright 2003-2015 Dorian C. Arnold, Philip C. Roth, Barton P. Miller   *
 *                  Detailed MRNet usage rights in "LICENSE" file.          *
 ****************************************************************************/

#ifndef XT_TOOLUTIL_H
#define XT_TOOLUTIL_H

int FindMyNid( void );

#endif // XT_TOOLUTIL_H
