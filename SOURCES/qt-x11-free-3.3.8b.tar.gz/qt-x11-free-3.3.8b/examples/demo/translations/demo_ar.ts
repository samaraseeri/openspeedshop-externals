<!DOCTYPE TS><TS>
<context>
    <name>BookForm</name>
    <message>
        <source>Book</source>
        <translation type="obsolete">كتاب</translation>
    </message>
    <message>
        <source>Surname</source>
        <translation type="obsolete">لقب</translation>
    </message>
    <message>
        <source>surname</source>
        <translation type="obsolete">لقب</translation>
    </message>
    <message>
        <source>Forename</source>
        <translation type="obsolete">إسم</translation>
    </message>
    <message>
        <source>forename</source>
        <translation type="obsolete">إسم</translation>
    </message>
    <message>
        <source>surname ASC</source>
        <translation type="obsolete">لقب</translation>
    </message>
    <message>
        <source>forename ASC</source>
        <translation type="obsolete">إسم</translation>
    </message>
    <message>
        <source>(default)</source>
        <translation type="obsolete">(إفتراضي)</translation>
    </message>
    <message>
        <source>author</source>
        <translation type="obsolete">مؤلّف</translation>
    </message>
    <message>
        <source>Title</source>
        <translation type="obsolete">عنوان</translation>
    </message>
    <message>
        <source>title</source>
        <translation type="obsolete">عنوان</translation>
    </message>
    <message>
        <source>Price</source>
        <translation type="obsolete">سعر</translation>
    </message>
    <message>
        <source>price</source>
        <translation type="obsolete">سعر</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation type="obsolete">ملاحظات</translation>
    </message>
    <message>
        <source>notes</source>
        <translation type="obsolete">ملاحظات</translation>
    </message>
    <message>
        <source>title ASC</source>
        <translation type="obsolete">عنوان</translation>
    </message>
    <message>
        <source>book</source>
        <translation type="obsolete">كتاب</translation>
    </message>
    <message>
        <source>&amp;Connect...</source>
        <translation type="obsolete">&amp;وصل...</translation>
    </message>
    <message>
        <source>&amp;Edit Books</source>
        <translation type="obsolete">ت&amp;حرير الكتب</translation>
    </message>
</context>
<context>
    <name>ConnectDialog</name>
    <message>
        <source>Connect...</source>
        <translation>وصل...</translation>
    </message>
    <message>
        <source>Connection settings</source>
        <translation>إعدادات الوصل</translation>
    </message>
    <message>
        <source>Database Name:</source>
        <translation>إسم قاعدة البيانات:</translation>
    </message>
    <message>
        <source>&amp;Username:</source>
        <translation>إسم المست&amp;عمل:</translation>
    </message>
    <message>
        <source>&amp;Password:</source>
        <translation>&amp;كلمة السّر:</translation>
    </message>
    <message>
        <source>&amp;Hostname:</source>
        <translation>إسم الم&amp;ضيف:</translation>
    </message>
    <message>
        <source>P&amp;ort:</source>
        <translation>م&amp;نفذ:</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>إفتراضي</translation>
    </message>
    <message>
        <source>D&amp;river</source>
        <translation>&amp;قائد</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;موافقة</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>إ&amp;لغاء</translation>
    </message>
</context>
<context>
    <name>DnDDemo</name>
    <message>
        <source>copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished">نسخ</translation>
    </message>
    <message>
        <source>cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="unfinished">قصّ</translation>
    </message>
    <message>
        <source>paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="unfinished">تلصيق</translation>
    </message>
    <message>
        <source>raise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Raise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lower</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lower</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>new</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished">جديد</translation>
    </message>
    <message>
        <source>load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished">حفظ</translation>
    </message>
    <message>
        <source>undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished">تراجع</translation>
    </message>
    <message>
        <source>redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="unfinished">إعادة</translation>
    </message>
    <message>
        <source>delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Home</source>
        <translation type="unfinished">منزل</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DnDDemoBase</name>
    <message>
        <source>Form1</source>
        <translation>استمارة1</translation>
    </message>
</context>
<context>
    <name>EditBookForm</name>
    <message>
        <source>Edit Books</source>
        <translation type="obsolete">تحرير الكتب</translation>
    </message>
    <message>
        <source>title ASC</source>
        <translation type="obsolete">عنوان</translation>
    </message>
    <message>
        <source>(default)</source>
        <translation type="obsolete">(إفتراضي)</translation>
    </message>
    <message>
        <source>book</source>
        <translation type="obsolete">كتاب</translation>
    </message>
    <message>
        <source>Price</source>
        <translation type="obsolete">سعر</translation>
    </message>
    <message>
        <source>Title</source>
        <translation type="obsolete">عنوان</translation>
    </message>
    <message>
        <source>title</source>
        <translation type="obsolete">عنوان</translation>
    </message>
    <message>
        <source>price</source>
        <translation type="obsolete">سعر</translation>
    </message>
    <message>
        <source>&amp;Insert</source>
        <translation type="obsolete">إ&amp;دراج</translation>
    </message>
    <message>
        <source>&amp;Update</source>
        <translation type="obsolete">تحد&amp;يث</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="obsolete">&amp;حذف</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="obsolete">إ&amp;غلاق</translation>
    </message>
    <message>
        <source>|&lt; &amp;First</source>
        <translation type="obsolete">|&lt; ال&amp;أوّل</translation>
    </message>
    <message>
        <source>&lt;&lt; &amp;Prev</source>
        <translation type="obsolete">&lt;&lt; ال&amp;سّابق</translation>
    </message>
    <message>
        <source>&amp;Next &gt;&gt;</source>
        <translation type="obsolete">ال&amp;تّالي &gt;&gt;</translation>
    </message>
    <message>
        <source>&amp;Last &gt;|</source>
        <translation type="obsolete">الأ&amp;خير &gt;|</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="obsolete">مؤلّف</translation>
    </message>
    <message>
        <source>author_view</source>
        <translation type="obsolete">منظر المؤلّف</translation>
    </message>
    <message>
        <source>name</source>
        <translation type="obsolete">إسم</translation>
    </message>
</context>
<context>
    <name>FigureEditor</name>
    <message>
        <source>Drag the nodes around!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <source>Qt Demo Collection</source>
        <translation>مجموعة عرض Qt</translation>
    </message>
    <message>
        <source>&amp;Exit</source>
        <translation>&amp;خروج</translation>
    </message>
    <message>
        <source>Ctrl+Q</source>
        <translation>تحكّم+Q</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;ملفّ</translation>
    </message>
    <message>
        <source>St&amp;yle</source>
        <translation>&amp;طراز</translation>
    </message>
    <message>
        <source>Demo Categories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Widgets</source>
        <translation type="unfinished">ويدجت</translation>
    </message>
    <message>
        <source>Drag and Drop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SQL Explorer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Graph Drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3D Demo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fractal landscape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OpenGL info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Richtext Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help Browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Internationalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asteroids</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GLLandscape</name>
    <message>
        <source>Wireframe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flat shaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Smooth shaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GLLandscapeViewer</name>
    <message>
        <source>Qt/OpenGL example</source>
        <translation>مثال عن Qt/OpenGL</translation>
    </message>
    <message>
        <source>X-rotation</source>
        <translation>دوران سيني</translation>
    </message>
    <message>
        <source>Y-rotation</source>
        <translation>دوران صادي</translation>
    </message>
    <message>
        <source>Z-rotation</source>
        <translation>دوران عيني</translation>
    </message>
    <message>
        <source>Rendering mode</source>
        <translation>نمط الارجاع</translation>
    </message>
    <message>
        <source>&amp;Wireframe</source>
        <translation>ع&amp;لبة التّوصيلات</translation>
    </message>
    <message>
        <source>Fl&amp;at shaded</source>
        <translation>تظليل م&amp;ستوي</translation>
    </message>
    <message>
        <source>&amp;Smooth shaded</source>
        <translation>تظليل أ&amp;ملس</translation>
    </message>
    <message>
        <source>&amp;Landscape</source>
        <translation>م&amp;نظر</translation>
    </message>
    <message>
        <source>&amp;Fractalize</source>
        <translation>&amp;كسر</translation>
    </message>
    <message>
        <source>&amp;Reset grid</source>
        <translation>إ&amp;عادة وضع الشّبكة</translation>
    </message>
    <message>
        <source>&amp;Animate</source>
        <translation>ت&amp;حريك</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>تكبير</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>حجم</translation>
    </message>
</context>
<context>
    <name>GLWorkspace</name>
    <message>
        <source>&amp;Scene</source>
        <translation>م&amp;شهد</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;جديد</translation>
    </message>
    <message>
        <source>New</source>
        <translation>جديد</translation>
    </message>
    <message>
        <source>Wirebox</source>
        <translation>علبة التّوصيلات</translation>
    </message>
    <message>
        <source>&amp;Wirebox</source>
        <translation>ع&amp;لبة التّوصيلات</translation>
    </message>
    <message>
        <source>Gear</source>
        <translation>ترس</translation>
    </message>
    <message>
        <source>&amp;Gears</source>
        <translation>ت&amp;روس</translation>
    </message>
    <message>
        <source>Texture</source>
        <translation>حبكة</translation>
    </message>
    <message>
        <source>&amp;Texture</source>
        <translation>&amp;حبكة</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation>&amp;طبع</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>طبع</translation>
    </message>
    <message>
        <source>Window Size</source>
        <translation>حجم النّافذة</translation>
    </message>
    <message>
        <source>&amp;Window Size</source>
        <translation>حجم ال&amp;نّافذة</translation>
    </message>
    <message>
        <source>Low Resolution</source>
        <translation>تمييز منخفض</translation>
    </message>
    <message>
        <source>&amp;Low Resolution</source>
        <translation>تمييز من&amp;خفض</translation>
    </message>
    <message>
        <source>Medium Resolution</source>
        <translation>تمييز متوسّط</translation>
    </message>
    <message>
        <source>&amp;Medium Resolution</source>
        <translation>تمييز مت&amp;وسّط</translation>
    </message>
    <message>
        <source>High Resolution</source>
        <translation>تمييز عالي</translation>
    </message>
    <message>
        <source>&amp;High Resolution</source>
        <translation>تمييز &amp;عالي</translation>
    </message>
    <message>
        <source>Setup</source>
        <translation>إعداد</translation>
    </message>
    <message>
        <source>&amp;Setup...</source>
        <translation>إع&amp;داد...</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>إغلاق</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>إ&amp;غلاق</translation>
    </message>
    <message>
        <source>WireBox</source>
        <translation type="obsolete">علبة التّوصيلات</translation>
    </message>
    <message>
        <source>Nurbs</source>
        <translation>نرب</translation>
    </message>
</context>
<context>
    <name>HelpWindow</name>
    <message>
        <source>&amp;New Window</source>
        <translation>نافذة &amp;جديدة</translation>
    </message>
    <message>
        <source>&amp;Open File</source>
        <translation>&amp;فتح ملفّ</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation>&amp;طبع</translation>
    </message>
    <message>
        <source>&amp;Backward</source>
        <translation>لل&amp;وراء</translation>
    </message>
    <message>
        <source>&amp;Forward</source>
        <translation>لل&amp;أمام</translation>
    </message>
    <message>
        <source>&amp;Home</source>
        <translation>م&amp;نزل</translation>
    </message>
    <message>
        <source>Add Bookmark</source>
        <translation>إضافة مؤشّر</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;ملفّ</translation>
    </message>
    <message>
        <source>&amp;Go</source>
        <translation>إ&amp;ذهب</translation>
    </message>
    <message>
        <source>History</source>
        <translation>تاريخ</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation>مؤشّرات</translation>
    </message>
    <message>
        <source>Backward</source>
        <translation>للوراء</translation>
    </message>
    <message>
        <source>Forward</source>
        <translation>للأمام</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>منزل</translation>
    </message>
</context>
<context>
    <name>I18nDemo</name>
    <message>
        <source>Close the current window.</source>
        <translation>إغلاق النّافذة الجارية.</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>إغلاق</translation>
    </message>
    <message>
        <source>Close all opened windows.</source>
        <translation>إغلاق جميع النّوافذ المفتوحة.</translation>
    </message>
    <message>
        <source>Close All</source>
        <translation>إغلاق الجميع</translation>
    </message>
    <message>
        <source>Tile opened windows.</source>
        <translation>تطويب النّوافذ المفتوحة.</translation>
    </message>
    <message>
        <source>Tile</source>
        <translation>تطويب</translation>
    </message>
    <message>
        <source>Cascade opened windows.</source>
        <translation>تشليل النّوافذ المفتوحة.</translation>
    </message>
    <message>
        <source>Cascade</source>
        <translation>تشليل</translation>
    </message>
    <message>
        <source>--language--</source>
        <translation>--اللّغة--</translation>
    </message>
    <message>
        <source>&lt;h3&gt;About Qt&lt;/h3&gt;&lt;p&gt;This program uses Qt version %1, a multiplatform C++ GUI toolkit from Trolltech. Qt provides single-source portability across Windows 95/98/NT/2000, Linux, Solaris, HP-UX and many other versions of Unix with X11.&lt;/p&gt;&lt;p&gt;See &lt;tt&gt;http://www.trolltech.com/qt/&lt;/tt&gt; for more information.&lt;/p&gt;</source>
        <translation type="obsolete">&lt;h3&gt;حول Qt&lt;/h3&gt;&lt;p&gt;هذا البرنامج يستعمل Qt إصدار %1، طقم أدوات C++ لتطوير البرامج البيانية على جميع المنصّات من شركة ترولتك. Qt توفّر إمكانية حمل نفس المصدر إلى ويندوز95\98\NT\2000 ، لينكس، سولاريس، HP-UX و العديد من الإصدارات الأخرى ليونيكس مع X11. أنظر &lt;tt&gt;http://www.trolltech.com/qt/&lt;/tt&gt; للمزيد من المعلومات.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">&amp;جديد</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;h3&gt;About Qt&lt;/h3&gt;&lt;p&gt;This program uses Qt version %1, a multiplatform C++ GUI toolkit from Trolltech. Qt provides single-source portability across Windows 95/98/NT/2000, Mac OS X, Linux, Solaris, HP-UX and many other versions of Unix with X11.&lt;/p&gt;&lt;p&gt;See &lt;tt&gt;http://www.trolltech.com/qt/&lt;/tt&gt; for more information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KAstTopLevel</name>
    <message>
        <source>Score</source>
        <translation>حاصل</translation>
    </message>
    <message>
        <source>Level</source>
        <translation>مستوى</translation>
    </message>
    <message>
        <source>Ships</source>
        <translation>مركبات</translation>
    </message>
    <message>
        <source>Fuel</source>
        <translation>وقود</translation>
    </message>
    <message>
        <source>Press N to start playing</source>
        <translation>إضغط على N لبدأ اللّعب</translation>
    </message>
    <message>
        <source>Ship Destroyed. Press L to launch.</source>
        <translation>دمّرت المركبة، إضغط على L للإطلاق.</translation>
    </message>
    <message>
        <source>Game Over!</source>
        <translation>انتهت اللّعبة!</translation>
    </message>
</context>
<context>
    <name>KAsteroidsView</name>
    <message>
        <source>QCanvas demo</source>
        <translation>عرض QCanvas</translation>
    </message>
    <message>
        <source>This game has been implemented using the QCanvas class.
The QCanvas class is not part of the Professional Edition. Please 
contact Trolltech if you want to upgrade to the Enterprise Edition.</source>
        <translation>تمّ إنجاز هذه اللّعبة باستعمال فصيلة QCanvas.
فصيلة QCanvas ليست جزء من التّحريرة الاحترافية. تفضّل
بالإتّصال بترولتك إن أردت التّرفيع إلى تحريرة الشّركات.</translation>
    </message>
    <message>
        <source>Error: Cannot read sprite images</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintPreview</name>
    <message>
        <source>Print Preview</source>
        <translation>مراجعة الطّبع</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>مراجعة</translation>
    </message>
    <message>
        <source>TextLabel1</source>
        <translation>علامة النّص 1</translation>
    </message>
    <message>
        <source>Modify</source>
        <translation>تعديل</translation>
    </message>
    <message>
        <source>&amp;Invert Colors</source>
        <translation>&amp;عكس الألوان</translation>
    </message>
    <message>
        <source>&amp;Mirror</source>
        <translation>م&amp;رآة</translation>
    </message>
    <message>
        <source>&amp;Flip</source>
        <translation>&amp;قلب</translation>
    </message>
    <message encoding="UTF-8">
        <source>Rotate 90° &amp;left</source>
        <translation>دوران ب 90° للي&amp;سار</translation>
    </message>
    <message encoding="UTF-8">
        <source>Rotate 90° &amp;right</source>
        <translation>دوران ب 90° للي&amp;مين</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>مساع&amp;دة</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation>&amp;طبع</translation>
    </message>
    <message>
        <source>&amp;Discard</source>
        <translation>&amp;نبذ</translation>
    </message>
</context>
<context>
    <name>SqlEx</name>
    <message>
        <source>Form1</source>
        <translation>استمارة1</translation>
    </message>
    <message>
        <source>Tables</source>
        <translation>جداول</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>طراز</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>مطلوب</translation>
    </message>
    <message>
        <source>SQL Query</source>
        <translation>استفهام SQL</translation>
    </message>
    <message>
        <source>&amp;Submit</source>
        <translation>&amp;بعث</translation>
    </message>
    <message>
        <source>C&amp;lear</source>
        <translation>&amp;محو</translation>
    </message>
    <message>
        <source>Press &quot;Connect&quot; to open a database</source>
        <translation>إضغط على &quot;وصل&quot; لفتح قاعدة بيانات</translation>
    </message>
    <message>
        <source>&amp;Connect...</source>
        <translation>&amp;وصل...</translation>
    </message>
</context>
<context>
    <name>TextEdit</name>
    <message>
        <source>&amp;File</source>
        <translation>&amp;ملفّ</translation>
    </message>
    <message>
        <source>New</source>
        <translation>جديد</translation>
    </message>
    <message>
        <source>&amp;New...</source>
        <translation>&amp;جديد...</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>فتح</translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation>&amp;فتح...</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>حفظ</translation>
    </message>
    <message>
        <source>&amp;Save...</source>
        <translation>حف&amp;ظ...</translation>
    </message>
    <message>
        <source>Save As</source>
        <translation>حفظ تحت</translation>
    </message>
    <message>
        <source>Save &amp;As...</source>
        <translation>حفظ &amp;تحت...</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>طبع</translation>
    </message>
    <message>
        <source>&amp;Print...</source>
        <translation>طب&amp;ع...</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>إغلاق</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>إ&amp;غلاق</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>ت&amp;حرير</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>تراجع</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;تراجع</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>إعادة</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>إعا&amp;دة</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>قصّ</translation>
    </message>
    <message>
        <source>&amp;Cut</source>
        <translation>&amp;قصّ</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>نسخ</translation>
    </message>
    <message>
        <source>C&amp;opy</source>
        <translation>&amp;نسخ</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>تلصيق</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>ت&amp;لصيق</translation>
    </message>
    <message>
        <source>For&amp;mat</source>
        <translation>&amp;طراز</translation>
    </message>
    <message>
        <source>Standard</source>
        <translation>قياسي</translation>
    </message>
    <message>
        <source>Bullet List (Disc)</source>
        <translation>قائمة مطّية (قرص)</translation>
    </message>
    <message>
        <source>Bullet List (Circle)</source>
        <translation>قائمة مطّية (دائرة)</translation>
    </message>
    <message>
        <source>Bullet List (Square)</source>
        <translation>قائمة مطّية (مربّع)</translation>
    </message>
    <message>
        <source>Ordered List (Decimal)</source>
        <translation>قائمة مرتّبة (عشرية)</translation>
    </message>
    <message>
        <source>Ordered List (Alpha lower)</source>
        <translation>قائمة مرتّبة (ألف للتحت)</translation>
    </message>
    <message>
        <source>Ordered List (Alpha upper)</source>
        <translation>قائمة مرتّبة (ألف للفوق)</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation>بيّن</translation>
    </message>
    <message>
        <source>&amp;Bold</source>
        <translation>&amp;بيّن</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation>مائل</translation>
    </message>
    <message>
        <source>&amp;Italic</source>
        <translation>ما&amp;ئل</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation>تسطير</translation>
    </message>
    <message>
        <source>&amp;Underline</source>
        <translation>تسطي&amp;ر</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>يسار</translation>
    </message>
    <message>
        <source>&amp;Left</source>
        <translation>ي&amp;سار</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>توسيط</translation>
    </message>
    <message>
        <source>C&amp;enter</source>
        <translation>ت&amp;وسيط</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>يمين</translation>
    </message>
    <message>
        <source>&amp;Right</source>
        <translation>&amp;يمين</translation>
    </message>
    <message>
        <source>Justify</source>
        <translation>ضبط الهامش</translation>
    </message>
    <message>
        <source>&amp;Justify</source>
        <translation>ضبط ال&amp;هامش</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>لون</translation>
    </message>
    <message>
        <source>&amp;Color...</source>
        <translation>&amp;لون...</translation>
    </message>
    <message>
        <source>noname</source>
        <translation>دون إسم</translation>
    </message>
    <message>
        <source>HTML-Files (*.htm *.html);;All Files (*)</source>
        <translation>ملفّات (html htm);;جميع الملفّات (*)</translation>
    </message>
</context>
<context>
    <name>WidgetsBase</name>
    <message>
        <source>Widgets</source>
        <translation>ويدجت</translation>
    </message>
    <message>
        <source>Applix</source>
        <translation>أبليكس</translation>
    </message>
    <message>
        <source>Binary</source>
        <translation>ثنائي</translation>
    </message>
    <message>
        <source>Core</source>
        <translation>نواة</translation>
    </message>
    <message>
        <source>Deb</source>
        <translation>Deb</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>وثيقة</translation>
    </message>
    <message>
        <source>Pdf</source>
        <translation>Pdf</translation>
    </message>
    <message>
        <source>Readme</source>
        <translation>إقرأني</translation>
    </message>
    <message>
        <source>Shellscript</source>
        <translation>سلسلة البرنامج الوسيطي</translation>
    </message>
    <message>
        <source>Recycled</source>
        <translation>مسترجع</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>فيديو</translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;h1&gt;&lt;b&gt;&lt;font size=&quot;5&quot; &gt;Richtext  &lt;/h1&gt;
&lt;/p&gt;&lt;p&gt;Qt supports formatted rich text, such as the heading above, &lt;i&gt;&lt;font &gt;emphasized&lt;/font&gt;&lt;/i&gt;, &lt;b&gt;&lt;font &gt;bold &lt;/font&gt;&lt;/b&gt;and &lt;u&gt;&lt;font &gt;underlined &lt;/font&gt;&lt;/u&gt;text, as well as colored text. This is &lt;font color=&quot;#ff0000&quot; &gt;red&lt;/font&gt;, while this is &lt;font color=&quot;#00bb00&quot; &gt;green&lt;/font&gt;, and this is &lt;font color=&quot;#0000ff&quot; &gt;blue&lt;/font&gt;.  &lt;/p&gt;
&lt;&gt; &lt;/&gt;
</source>
        <translation type="obsolete">&lt;p&gt;&lt;h1&gt;&lt;b&gt;&lt;font size=&quot;5&quot; &gt;نصّ غنيّ&lt;/h1&gt;
&lt;/p&gt;&lt;p&gt;Qt تدعم النّصوص الغنيّة المقاسة، كالعنوان الآنف، النّصوص &lt;i&gt;&lt;font &gt;المائلة&lt;/font&gt;&lt;/i&gt;، &lt;b&gt;&lt;font &gt;البيّنة &lt;/font&gt;&lt;/b&gt;و &lt;u&gt;&lt;font &gt;المسطّرة&lt;/font&gt;&lt;/u&gt;، كما تدعم النّصوص الملوّنة كذلك. هذا &lt;font color=&quot;#ff0000&quot; &gt;أحمر&lt;/font&gt;، بينما هذا &lt;font color=&quot;#00bb00&quot; &gt;أخضر&lt;/font&gt;، و هذا &lt;font color=&quot;#0000ff&quot; &gt;أزرق&lt;/font&gt;.
&lt;/p&gt;
&lt;&gt; &lt;/&gt;</translation>
    </message>
    <message>
        <source>Iconview</source>
        <translation>منظر بالإيقونات</translation>
    </message>
    <message>
        <source>Item 1</source>
        <translation>البند 1</translation>
    </message>
    <message>
        <source>Item 2</source>
        <translation>البند 2</translation>
    </message>
    <message>
        <source>Item 3</source>
        <translation>البند 3</translation>
    </message>
    <message>
        <source>Item 4</source>
        <translation>البند 4</translation>
    </message>
    <message>
        <source>Item 5</source>
        <translation>البند 5</translation>
    </message>
    <message>
        <source>Item 6</source>
        <translation>البند 6</translation>
    </message>
    <message>
        <source>Item 7</source>
        <translation>البند 7</translation>
    </message>
    <message>
        <source>Item 8</source>
        <translation>البند 8</translation>
    </message>
    <message>
        <source>Item 9</source>
        <translation>البند 9</translation>
    </message>
    <message>
        <source>Item 10</source>
        <translation>البند 10</translation>
    </message>
    <message>
        <source>Item 11</source>
        <translation>البند 11</translation>
    </message>
    <message>
        <source>Item 12</source>
        <translation>البند 12</translation>
    </message>
    <message>
        <source>Item 13</source>
        <translation>البند 13</translation>
    </message>
    <message>
        <source>Item 14</source>
        <translation>البند 14</translation>
    </message>
    <message>
        <source>Item 15</source>
        <translation>البند 15</translation>
    </message>
    <message>
        <source>Item 16</source>
        <translation>البند 16</translation>
    </message>
    <message>
        <source>Item 17</source>
        <translation>البند 17</translation>
    </message>
    <message>
        <source>Table</source>
        <translation>جدول</translation>
    </message>
    <message>
        <source>Tables</source>
        <translation>جداول</translation>
    </message>
    <message>
        <source>are</source>
        <translation>تكون</translation>
    </message>
    <message>
        <source>easy</source>
        <translation>سهل</translation>
    </message>
    <message>
        <source>with</source>
        <translation>مع</translation>
    </message>
    <message>
        <source>Qt</source>
        <translation>Qt</translation>
    </message>
    <message>
        <source>6</source>
        <translation type="obsolete">6</translation>
    </message>
    <message>
        <source>7</source>
        <translation type="obsolete">7</translation>
    </message>
    <message>
        <source>8</source>
        <translation type="obsolete">8</translation>
    </message>
    <message>
        <source>9</source>
        <translation type="obsolete">9</translation>
    </message>
    <message>
        <source>10</source>
        <translation type="obsolete">10</translation>
    </message>
    <message>
        <source>11</source>
        <translation type="obsolete">11</translation>
    </message>
    <message>
        <source>12</source>
        <translation type="obsolete">12</translation>
    </message>
    <message>
        <source>4</source>
        <translation type="obsolete">4</translation>
    </message>
    <message>
        <source>5</source>
        <translation type="obsolete">5</translation>
    </message>
    <message>
        <source>13</source>
        <translation type="obsolete">13</translation>
    </message>
    <message>
        <source>Listview</source>
        <translation>منظر بالقائمة</translation>
    </message>
    <message>
        <source>Things</source>
        <translation>أشياء</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>نصّ</translation>
    </message>
    <message>
        <source>Stuff</source>
        <translation>حاجة</translation>
    </message>
    <message>
        <source>Airbrush</source>
        <translation>فرشاة هوائية</translation>
    </message>
    <message>
        <source>What stuff?</source>
        <translation>أيّ حاجة؟</translation>
    </message>
    <message>
        <source>Eraser</source>
        <translation>ممحاة</translation>
    </message>
    <message>
        <source>Here?</source>
        <translation>هنا؟</translation>
    </message>
    <message>
        <source>Pixmap item</source>
        <translation>بند لخريطة عناصر الصّورة</translation>
    </message>
    <message>
        <source>Nothing</source>
        <translation>لا شيء</translation>
    </message>
    <message>
        <source>Nothing Again</source>
        <translation>لا شيء مجدّدا</translation>
    </message>
    <message>
        <source>Pixmap subitem 1</source>
        <translation>بند تحتي لخريطة عناصر الصّورة 1</translation>
    </message>
    <message>
        <source>Subitem</source>
        <translation>بند تحتي</translation>
    </message>
    <message>
        <source>Pixmap subitem 2 </source>
        <translation>بند تحتي لخريطة عناصر الصّورة 2</translation>
    </message>
    <message>
        <source>Group box</source>
        <translation>علبة المجموعة</translation>
    </message>
    <message>
        <source>Pick a base color:</source>
        <translation>اختر لونا قاعديّا:</translation>
    </message>
    <message>
        <source>&amp;Reset colors</source>
        <translation>إ&amp;عادة وضع الألوان</translation>
    </message>
    <message>
        <source>pale green</source>
        <translation>أخضر شاحب</translation>
    </message>
    <message>
        <source>deep sky blue</source>
        <translation>أزرق سماوي عميق</translation>
    </message>
    <message>
        <source>steel blue</source>
        <translation>أزرق فولاذي</translation>
    </message>
    <message>
        <source>powder blue</source>
        <translation>أزرق مسحوقي</translation>
    </message>
    <message>
        <source>sandy brown</source>
        <translation>بنّي رملي</translation>
    </message>
    <message>
        <source>dark orange</source>
        <translation>برتقالي داكن</translation>
    </message>
    <message>
        <source>indian red</source>
        <translation>أحمر هندي</translation>
    </message>
    <message>
        <source>hot pink</source>
        <translation>وردي حارّ</translation>
    </message>
    <message>
        <source>Enter a color name and hit return:</source>
        <translation>أدخل إسم لون و إظغط على عودة:</translation>
    </message>
    <message>
        <source>Color test area</source>
        <translation>منطقة تجربة اللّون</translation>
    </message>
    <message>
        <source>Check boxes</source>
        <translation>علب الفحص</translation>
    </message>
    <message>
        <source>Apples</source>
        <translation>تفّاح</translation>
    </message>
    <message>
        <source>Banana</source>
        <translation>موزة</translation>
    </message>
    <message>
        <source>Orange</source>
        <translation>برتقالي</translation>
    </message>
    <message>
        <source>Radio buttons</source>
        <translation>أزرار إذاعية</translation>
    </message>
    <message>
        <source>Sprite</source>
        <translation>شبح</translation>
    </message>
    <message>
        <source>Farris</source>
        <translation>فاريس</translation>
    </message>
    <message>
        <source>Solo</source>
        <translation>وحيد</translation>
    </message>
    <message>
        <source>Date/Time editors</source>
        <translation>المحرّرات تاريخ\زمن</translation>
    </message>
    <message>
        <source>DateTime string goes here!</source>
        <translation>السّلسلة تاريخ\زمن تأتي هنا!</translation>
    </message>
    <message>
        <source>&lt;h1&gt;&lt;b&gt;&lt;font size=&quot;4&quot; &gt;Richtext  &lt;/h1&gt;
&lt;p&gt;Qt supports formatted rich text, such as the heading above, &lt;i&gt;&lt;font &gt;emphasized&lt;/font&gt;&lt;/i&gt;, &lt;b&gt;&lt;font &gt;bold &lt;/font&gt;&lt;/b&gt;and &lt;u&gt;&lt;font &gt;underlined &lt;/font&gt;&lt;/u&gt;text, as well as colored text. This is &lt;font color=&quot;#ff0000&quot; &gt;red&lt;/font&gt;, while this is &lt;font color=&quot;#00bb00&quot; &gt;green&lt;/font&gt;, and this is &lt;font color=&quot;#0000ff&quot; &gt;blue&lt;/font&gt;.  &lt;/p&gt;
&lt;&gt; &lt;/&gt;
</source>
        <translation type="obsolete">&lt;p&gt;&lt;h1&gt;&lt;b&gt;&lt;font size=&quot;4&quot; &gt;نصّ غنيّ&lt;/h1&gt;
&lt;/p&gt;&lt;p&gt;Qt تدعم النّصوص الغنيّة المقاسة، كالعنوان الآنف، النّصوص &lt;i&gt;&lt;font &gt;المائلة&lt;/font&gt;&lt;/i&gt;، &lt;b&gt;&lt;font &gt;البيّنة &lt;/font&gt;&lt;/b&gt;و &lt;u&gt;&lt;font &gt;المسطّرة&lt;/font&gt;&lt;/u&gt;، كما تدعم النّصوص الملوّنة كذلك. هذا &lt;font color=&quot;#ff0000&quot; &gt;أحمر&lt;/font&gt;، بينما هذا &lt;font color=&quot;#00bb00&quot; &gt;أخضر&lt;/font&gt;، و هذا &lt;font color=&quot;#0000ff&quot; &gt;أزرق&lt;/font&gt;.
&lt;/p&gt;
&lt;&gt; &lt;/&gt;</translation>
    </message>
    <message>
        <source>Check Boxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cherry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Radio Buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Whisky</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date/Time Editors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter a color and hit return:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot;font-size:8pt;font-family:MS Shell Dlg&quot;&gt;
&lt;p style=&quot;margin-top:16px&quot;&gt;&lt;span style=&quot;font-size:12pt;font-weight:600&quot;&gt;Rich Text&lt;/span&gt;&lt;/p&gt;
&lt;p&gt;Qt supports rich text. This is &lt;span style=&quot;font-style:italic&quot;&gt;italics&lt;/span&gt;, this is &lt;span style=&quot;font-weight:600&quot;&gt;bold&lt;/span&gt;, this is &lt;span style=&quot;text-decoration:underline&quot;&gt;underlined&lt;/span&gt;, this is &lt;span style=&quot;color:#ff0000&quot;&gt;red&lt;/span&gt;, this is &lt;span style=&quot;color:#00ff00&quot;&gt;green&lt;/span&gt;, and this is &lt;span style=&quot;color:#0000ff&quot;&gt;blue&lt;/span&gt;.&lt;/p&gt;
&lt;/body&gt;&lt;/html&gt;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icon View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Standard paint tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>143 messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(5 new)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draft #1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot;font-size:8pt;font-family:MS Shell Dlg&quot;&gt;
&lt;p style=&quot;margin-top:18px&quot;&gt;&lt;span style=&quot;font-size:9pt;font-weight:600&quot;&gt;Richtext &lt;/span&gt;&lt;/p&gt;
&lt;p&gt;Qt supports formatted rich text, such as the heading above, &lt;span style=&quot;font-style:italic&quot;&gt;emphasized&lt;/span&gt;, &lt;span style=&quot;font-weight:600&quot;&gt;bold &lt;/span&gt;and &lt;span style=&quot;text-decoration:underline&quot;&gt;underlined &lt;/span&gt;text, as well as colored text. This is &lt;span style=&quot;color:#ff0000&quot;&gt;red&lt;/span&gt;, while this is &lt;span style=&quot;color:#00bb00&quot;&gt;green&lt;/span&gt;, and this is &lt;span style=&quot;color:#0000ff&quot;&gt;blue&lt;/span&gt;. &lt;/p&gt;
&lt;/body&gt;&lt;/html&gt;
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
