<!DOCTYPE TS><TS>
<context encoding="UTF-8">
    <name>MyWidget</name>
    <message encoding="UTF-8">
        <source>View</source>
        <translation type="unfinished">Ansicht</translation>
    </message>
    <message encoding="UTF-8">
        <source>&amp;File</source>
        <translation type="unfinished">&amp;Datei</translation>
    </message>
    <message encoding="UTF-8">
        <source>E&amp;xit</source>
        <translation type="unfinished">Be&amp;enden</translation>
    </message>
    <message encoding="UTF-8">
        <source>First</source>
        <translation type="unfinished">Erstens</translation>
    </message>
    <message encoding="UTF-8">
        <source>Third</source>
        <translation type="unfinished">Drittens</translation>
    </message>
    <message encoding="UTF-8">
        <source>Language: English</source>
        <translation type="unfinished">Sprache: Deutsch</translation>
    </message>
    <message encoding="UTF-8">
        <source>The Main Window</source>
        <translation type="unfinished">Das Hauptfenster</translation>
    </message>
    <message encoding="UTF-8">
        <source>Ctrl+Q</source>
        <translation type="unfinished">Ctrl+E</translation>
    </message>
    <message encoding="UTF-8">
        <source>Oblique</source>
        <translation type="unfinished">Schief</translation>
    </message>
    <message encoding="UTF-8">
        <source>Second</source>
        <translation type="unfinished">Zweitens</translation>
    </message>
    <message encoding="UTF-8">
        <source>Isometric</source>
        <translation type="unfinished">Isometrisch</translation>
    </message>
    <message encoding="UTF-8">
        <source>Perspective</source>
        <translation type="unfinished">Perspektivisch</translation>
    </message>
    <message encoding="UTF-8">
        <source>Internationalization Example</source>
        <translation type="unfinished">Internationalisierungsbeispiel</translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>QAccel</name>
    <message encoding="UTF-8">
        <source>Ctrl</source>
        <translation type="obsolete">Strg</translation>
    </message>
</context>
<context>
    <name>QVDialog</name>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
