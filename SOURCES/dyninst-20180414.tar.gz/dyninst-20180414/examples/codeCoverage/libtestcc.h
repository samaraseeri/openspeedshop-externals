/*
 * Header for libtestcc
 */

#ifndef __LIB_TESTCC_H__
#define __LIB_TESTCC_H__

extern void libFooFunction(int callOtherFunction);

#endif
