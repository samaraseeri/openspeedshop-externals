#include <stdio.h>

void foo()
{
    fprintf(stderr, "Hello, world!\n");
}

int main()
{
    foo();

    return 0;
}

