/****************************************************************************
 * Copyright © 2003-2015 Dorian C. Arnold, Philip C. Roth, Barton P. Miller *
 *                  Detailed MRNet usage rights in "LICENSE" file.          *
 ****************************************************************************/

#include "mrnet/Network.h"
#include "RSHChildNode.h"
#include "InternalNode.h"
#include "utils.h"
#include "mrnet/MRNet.h"


namespace MRN
{

RSHChildNode::RSHChildNode(void)
{
}

RSHChildNode::~RSHChildNode(void)
{
}


} // namespace MRN
