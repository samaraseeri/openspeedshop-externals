/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2007, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich GmbH, Federal
 * Republic of Germany
 *
 * See the file COPYRIGHT in the package base directory for details
 **/

#ifndef _VT_UNIFY_H_
#define _VT_UNIFY_H_

#if HAVE_CONFIG_H
#  include <config.h>
#endif

#include "vt_unify_defs.h"

#include <string>
#include <vector>

#define STRBUFSIZE 1024

#if SIZEOF_LONG == 4
#  define ATOL8 atoll
#else
#  define ATOL8 atol
#endif

#define UPDATE_PROGESSBAR                                     \
{                                                             \
   uint32_t sum_progress = 0;                                 \
   for( uint32_t j = 0; j < vec_progress.size(); j++ )        \
      sum_progress += vec_progress[j];                        \
	                                                      \
   uint32_t percentage = sum_progress / vec_progress.size();  \
	                                                      \
   if( percentage < 10 )                                      \
      std::cout << "00" << percentage << "%\r" << std::flush; \
   else if( percentage < 100 )                                \
      std::cout << "0" << percentage << "%\r" << std::flush;  \
   else                                                       \
      std::cout << percentage << "%\r" << std::flush;         \
}

class Unifyer
{
   //
   // unify control structure for each file stream
   //
   struct UnifyControl_struct
   {
      UnifyControl_struct() : streamid(0)
	 {
	    ltime[0] = 0; ltime[1] = 1;
	    offset[0] = 0; offset[1] = 0;
	 }

      UnifyControl_struct(uint32_t _streamid,
			  int64_t * _ltime, int64_t * _offset)
	 : streamid(_streamid)
	 {
	    ltime[0] = _ltime[0]; ltime[1] = _ltime[1];
	    offset[0] = _offset[0]; offset[1] = _offset[1];
	 }

      uint32_t    streamid;   // id of input stream
      int64_t     ltime[2];   // local times ...
      int64_t     offset[2];  // ... and chronological offsets to global time
   };

public:
   
   Unifyer();    // contructor
   ~Unifyer();   // destructor

   bool run();

   uint64_t correctTime( uint32_t uid, uint64_t time );

private:

   bool initialize();
   bool readUnifyControlFiles();
   bool createTokenFactory();
   bool unifyDefinitions( std::vector<DefBufEntry_Base_struct*> *
			  p_vecGlobDefs );
   bool unifyEvents();
   bool writeGlobalDefinitions( std::vector<DefBufEntry_Base_struct*> *
				p_vecGlobDefs );
   bool writeMasterControl();
   bool getMinStartTime();
   bool cleanUp();

   uint64_t m_uMinStartTime;   // minimal start time
   std::vector<UnifyControl_struct*> m_vecUnifyCtls;   // unify control vector
};

extern Unifyer * theUnifyer;

#endif // _VT_UNIFY_H_
