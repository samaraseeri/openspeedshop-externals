/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2007, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich GmbH, Federal
 * Republic of Germany
 *
 * See the file COPYRIGHT in the package base directory for details
 **/

#include "vt_unify.h"
#include "vt_unify_defs.h"
#include "vt_unify_hdlr.h"
#include "vt_unify_tkfac.h"

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>

#include <assert.h>
#include "vt_inttypes.h"
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#if (defined (VT_OMP))
#include <omp.h>
#endif

#include <otf.h>

#define USAGETEXT "Usage: " << ExeName \
                  << " <#files> <inprefix> [-o <outprefix>] [-c <on|off>] [-k] [-v]" \
                  << std::endl \
                  << "       <#files>        - number of trace files" \
                  << std::endl \
                  << "       <inprefix>      - prefix of input trace filename" \
                  << std::endl \
                  << "       -o <outprefix>  - prefix of output trace filename" \
                  << std::endl \
                  << "       -c <on|off>     - trace file compression (on/off) default=on" \
                  << std::endl \
                  << "                         (needs OTF version 1.2 or higher)" \
                  << std::endl \
                  << "       -k              - keep input trace files" \
                  << std::endl \
                  << "                         (if no <outprefix> given or <outprefix> = <inprefix>," \
                  << std::endl \
                  << "                          then output trace files will be prefix with 'u_')" \
                  << std::endl \
                  << "       -v              - verbose mode"

//
// structure that contains the program options
//
struct Params_struct
{
   Params_struct() 
      : uctl_files_num(0), in_file_prefix(""), out_file_prefix(""),
      docompress(true), doclean(true), beverbose(false) {}

   uint32_t    uctl_files_num;
   std::string in_file_prefix;
   std::string out_file_prefix;
   bool        docompress;
   bool        doclean;
   bool        beverbose;
} Params;

static bool ParseCommandLine( int argc, char ** argv );

static const std::string ExeName = "vtunify";
static const std::string TmpFileSuffix = "__ufy.tmp";
static const std::string UniFilePrefix = "u_";

Unifyer * theUnifyer;   // instance of class Unifyer

int
main( int argc, char ** argv )
{
   int rc;

   // parse command line
   if( !ParseCommandLine( argc, argv ) )
      return 1;

   // show help text, if command line parameters are incomplete
   //
   if( Params.uctl_files_num == 0
       || Params.in_file_prefix.length() == 0 )
   {
      std::cout << USAGETEXT << std::endl;
      return 0;
   }

   // set namestub of output streams, if necessary
   if( Params.out_file_prefix.length() == 0 )
      Params.out_file_prefix = Params.in_file_prefix;

   // if input files should be kept and output filename
   // is equal to input filename, then prefix output filename
   if( !Params.doclean &&
       Params.out_file_prefix == Params.in_file_prefix )
   {
      int32_t fileidx = Params.out_file_prefix.rfind('/');

      if( fileidx > -1 )
      {
	 Params.out_file_prefix =
	    Params.out_file_prefix.substr( 0, fileidx + 1 ) +
	    UniFilePrefix +
	    Params.out_file_prefix.substr( fileidx + 1 );
      }
      else
      {
	 Params.out_file_prefix = UniFilePrefix + Params.out_file_prefix;
      }
   }

   // create instance of unifyer
   theUnifyer = new Unifyer();
   assert( theUnifyer );

   // start unifying
   rc = theUnifyer->run() ? 0 : 1;

   delete theUnifyer;

   return rc;
}

static bool
ParseCommandLine( int argc, char ** argv )
{
   bool error = false;

   for( int i = 1; i < argc; i++ )
   {
      if( i == 1 )
      {
	 Params.uctl_files_num = atoi( argv[1] );
	 if( Params.uctl_files_num == 0 )
	 {
	    std::cerr << "<#files> must be positive integer" << std::endl;
	    error = true;
	 }
      }
      else if( i == 2 )
      {
	 Params.in_file_prefix = argv[2];
	 if( Params.in_file_prefix.compare( 0, 1, "/" ) != 0 &&
	     Params.in_file_prefix.compare( 0, 2, "./" ) != 0 )
	    Params.in_file_prefix = std::string("./") + Params.in_file_prefix;
      }
      else if( strcmp( argv[i], "-o" ) == 0 )
      {
	 if( i == argc - 1 )
	 {
	    std::cerr << ExeName << ": <outprefix> expected -- -o" << std::endl;
	    error = true;
	 }
	 else
	 {
	    Params.out_file_prefix = argv[++i];
	    if( Params.out_file_prefix.compare( 0, 1, "/" ) != 0 &&
		Params.out_file_prefix.compare( 0, 2, "./" ) != 0 )
	       Params.out_file_prefix = std::string("./") + Params.out_file_prefix;
	 }
      }
      else if( strcmp( argv[i], "-c" ) == 0 )
      {
	 if( i == argc - 1 || 
	     ( strcmp( argv[i+1], "on" ) != 0 &&
	       strcmp( argv[i+1], "off" ) != 0 ) )
	 {
	    std::cerr << ExeName << ": <on|off> expected -- -c" << std::endl;
	    error = true;
	 }
	 else
	 {
	    Params.docompress = strcmp( argv[++i], "on" ) == 0 ? 1 : 0;
	 }	 
      }
      else if( strcmp( argv[i], "-k" ) == 0 )
      {
	 Params.doclean = false;
      }
      else if( strcmp( argv[i], "-v" ) == 0 )
      {
	 Params.beverbose = true;
      }
      else
      {
	 std::cerr << ExeName << ": invalid option -- " << argv[i] << std::endl;
	 error = true;
      }

      if( error )
	 break;
   }

   return !error;
}

//////////////////// class Unifyer ////////////////////

// public methods
//

Unifyer::Unifyer()
{
   m_uMinStartTime = (uint64_t)-1;
}

Unifyer::~Unifyer()
{
   for( uint32_t i = 0; i < m_vecUnifyCtls.size(); i++ )
      delete( m_vecUnifyCtls[i] );
}

bool
Unifyer::run()
{
   bool error = false;

   // initialize unifying
   if( !initialize() )
      return false;

   // allocate vector for global definition
   std::vector<DefBufEntry_Base_struct*> * p_vec_glob_defs =
      new std::vector<DefBufEntry_Base_struct*>();
   assert( p_vec_glob_defs );

   // unify definitions
   if( !unifyDefinitions( p_vec_glob_defs ) )
      error = true;

   // write global definitions (stream id = 0)
   if( !error && !writeGlobalDefinitions( p_vec_glob_defs ) )
      error = true;

   // get minimum start time
   if( !error && !getMinStartTime() )
      error = true;

   // unify events
   if( !error && !unifyEvents() )
      error = true;

   // create OTF master control
   if( !error && !writeMasterControl() )
      error = true;

   // remove local definitions/events streams, unify control files
   // and temporary files
   if( !error && !cleanUp() )
      error = true;

   // free global definition record vector
   //
   for( uint32_t i = 0; i < p_vec_glob_defs->size(); i++ )
      delete (*p_vec_glob_defs)[i];
   delete p_vec_glob_defs;

   return !error;
}

uint64_t
Unifyer::correctTime( uint32_t uid, uint64_t time )
{
   assert( uid < m_vecUnifyCtls.size() );

   int64_t * ltime = m_vecUnifyCtls[uid]->ltime;
   int64_t * offset = m_vecUnifyCtls[uid]->offset;
   
   double d_time = (double)time;
   double d_ltime0 = (double)ltime[0];
   double d_offset0 = (double)offset[0];
   double d_ltime1 = (double)ltime[1];
   double d_offset1 = (double)offset[1];

   return (uint64_t)(d_time + (((d_offset1 - d_offset0) / (d_ltime1 - d_ltime0)) * (d_time - d_ltime0)) + d_offset0);
}

// private methods
//

bool
Unifyer::initialize()
{
   // read unify control files (*.uctl)
   if( !readUnifyControlFiles() )
      return false;

   // create token factory
   if( !createTokenFactory() )
      return false;

   return true;
}

bool
Unifyer::readUnifyControlFiles()
{
   if( Params.beverbose )
      std::cout << "Reading unify control files ..." << std::endl;

   bool error = false;
   uint32_t i;
   
   for( i = 0; i < Params.uctl_files_num; i++ )
   {
      char filename[STRBUFSIZE];

      // create file name
      sprintf( filename, "%s.%x.uctl",
	       Params.in_file_prefix.c_str(), i+1 );

      // open unify control file for reading
      //
      std::ifstream in( filename );
      
      if( !in )
      {
	 std::cerr << ExeName << ": Error: "
		   << "Cannot open file " << filename << std::endl;

	 error = true;
	 break;
      }

      if( Params.beverbose )
	 std::cout << " Opened " << filename << " for reading" << std::endl;

      char buffer[STRBUFSIZE];
      uint32_t line_no = 0;

      std::vector<uint32_t> vec_streamids;
      int64_t ltime[2] = { 0, 1 };
      int64_t offset[2] = { 0, 0 };

      // read line per line
      //
      while( in.getline( buffer, STRBUFSIZE ) )
      {
	 line_no++;

	 // line_no = 1: ids of input streams
	 //
	 if( line_no == 1 )
	 {
	    char * p;

	    p = strtok( buffer, ":" );
	    do
	    {
	       vec_streamids.push_back( atoi( p ) );
	    } while( ( p = strtok( 0, ":" ) ) );

	    if( vec_streamids.size() == 0 )
	    {
	       std::cerr << filename << ":" << line_no 
			 << ": Could not be parsed" << std::endl;
	       error = true;
	       break;
	    }
	 }
	 // line_no = 2: read chronological offsets to global time
	 //              and local times
	 //
	 else if( line_no == 2 )
	 {
	    char * p;
	    uint32_t n = 0;

	    p = strtok( buffer, ":" );
	    do
	    {
	       n++;

	       switch( n )
	       {
	          case 1:
		     ltime[0] = ATOL8(p);
		     break;
	          case 2:
		     offset[0] = ATOL8(p);
		     break;
	          case 3:
		     ltime[1] = ATOL8(p);
		     break;
	          case 4:
		     offset[1] = ATOL8(p);
		     break;
	          default:
		     break;
	       }
	    } while( ( p = strtok( 0, ":" ) ) );

	    if( n != 4 )
	    {
	       std::cerr << filename << ":" << line_no 
			 << ": Could not be parsed" << std::endl;
	       
	       error = true;
	       break;
	    }
	 }
	 else
	 {
	    break;
	 }
      }

      // close unify control file
      in.close();

      if( Params.beverbose )
	 std::cout << " Closed " << filename << std::endl;

      if( !error )
      {
	 // add to unify control vector
	 //
	 for( uint32_t i = 0; i < vec_streamids.size(); i++ )
	 {
	    m_vecUnifyCtls.push_back( 
	       new UnifyControl_struct(vec_streamids[i],
				       ltime,
				       offset) );
	 }
      }
      else
      {
	 break;
      }
   }

   return !error;
}

bool
Unifyer::createTokenFactory()
{
   bool error = false;

   // allocate token factory for ...
   while( 1 )
   {
      // ... DefSclFile
      theTokenFactory[TKFAC__DEF_SCL_FILE] =
	 new TokenFactory_DefSclFile();
      if( theTokenFactory[TKFAC__DEF_SCL_FILE] == 0 )
      { error = true; break; }

      // ... DefScl
      theTokenFactory[TKFAC__DEF_SCL] =
	 new TokenFactory_DefScl();
      if( theTokenFactory[TKFAC__DEF_SCL] == 0 )
      { error = true; break; }

      // ... DefFunctionGroup
      theTokenFactory[TKFAC__DEF_FUNCTION_GROUP] =
	 new TokenFactory_DefFunctionGroup();
      if( theTokenFactory[TKFAC__DEF_FUNCTION_GROUP] == 0 )
      { error = true; break; }

      // ... DefFunction
      theTokenFactory[TKFAC__DEF_FUNCTION] =
	 new TokenFactory_DefFunction();
      if( theTokenFactory[TKFAC__DEF_FUNCTION] == 0 )
      { error = true; break; }
      
      // ... DefCollectiveOperation
      theTokenFactory[TKFAC__DEF_COLL_OP] =
	 new TokenFactory_DefCollectiveOperation();
      if( theTokenFactory[TKFAC__DEF_COLL_OP] == 0 )
      { error = true; break; }

      // ... DefCounterGroup
      theTokenFactory[TKFAC__DEF_COUNTER_GROUP] =
	 new TokenFactory_DefCounterGroup();
      if( theTokenFactory[TKFAC__DEF_COUNTER_GROUP] == 0 )
      { error = true; break; }

      // ... DefCounter
      theTokenFactory[TKFAC__DEF_COUNTER] =
	 new TokenFactory_DefCounter();
      if( theTokenFactory[TKFAC__DEF_COUNTER] == 0 )
      { error = true; break; }

      // ... DefProcessGroup
      theTokenFactory[TKFAC__DEF_PROCESS_GROUP] =
	 new TokenFactory_DefProcessGroup();
      if( theTokenFactory[TKFAC__DEF_PROCESS_GROUP] == 0 )
      { error = true; }

      break;
   }

   return !error;
}

bool
LocDefsCmp( DefBufEntry_Base_struct * a,
	    DefBufEntry_Base_struct * b )
{
   // both record types are DEF_BUF_ENTRY_TYPE__DefinitionComment ? ...
   //
   if( a->etype == DEF_BUF_ENTRY_TYPE__DefinitionComment &&
       b->etype == DEF_BUF_ENTRY_TYPE__DefinitionComment )
   {
      DefBufEntry_DefinitionComment_struct * c1 =
	 static_cast<DefBufEntry_DefinitionComment_struct*>(a);
      DefBufEntry_DefinitionComment_struct * c2 =
	 static_cast<DefBufEntry_DefinitionComment_struct*>(b);

      // ... sort by trace order
      return c1->orderidx < c2->orderidx;
   }
   // both records have the same type ? ...
   //
   if( a->etype == b->etype &&
       ( a->etype != DEF_BUF_ENTRY_TYPE__DefCreator &&
	 a->etype != DEF_BUF_ENTRY_TYPE__DefTimerResolution ) )
       
   {
      // ... sort by local process id
      return a->loccpuid < b->loccpuid;
   }
   // otherwise ...
   else
   {
      // ... sort by type
      return a->etype < b->etype;
   }
}

bool
GlobDefsCmp( DefBufEntry_Base_struct * a,
	     DefBufEntry_Base_struct * b )
{
   // both record types are DEF_BUF_ENTRY_TYPE__DefProcess ? ...
   //
   if( a->etype == DEF_BUF_ENTRY_TYPE__DefProcess &&
       b->etype == DEF_BUF_ENTRY_TYPE__DefProcess )
   {
      // ... sort as follow:
      // Master 0
      //  Child 1/0
      //  Child 2/0
      // Master 1
      //  Child 1/1
      // Child  2/1
      // ...

      DefBufEntry_DefProcess_struct * p1 =
	 static_cast<DefBufEntry_DefProcess_struct*>(a);
      DefBufEntry_DefProcess_struct * p2 =
	 static_cast<DefBufEntry_DefProcess_struct*>(b);

      // both are master
      if( p1->parent == 0 && p2->parent == 0 )
	 return p1->deftoken < p2->deftoken;
      // p2 child of p1
      else if( p1->deftoken == p2->parent )
	 return true;
      // p1 child of p2
      else if( p1->parent == p2->deftoken )
	 return false;
      // both are childs and have same master
      else if( p1->parent != 0 && ( p1->parent == p2->parent ) )
	 return p1->deftoken < p2->deftoken;
      // both are childs, but not from same master
      else if( p1->parent != 0 && p2->parent != 0 &&
	       ( p1->parent != p2->parent ) )
	 return p1->parent < p2->parent;
      // p1 is master and p2 is child, but both have no reference
      else if( p1->parent == 0 && p2->parent != 0 )
	 return p1->deftoken < p2->parent;
      // p1 is child and p2 is master, but both have no reference
      else
	 return p1->parent < p2->deftoken;
   }
   // both record types are DEF_BUF_ENTRY_TYPE__DefProcessGroup ? ...
   //
   else if( a->etype == DEF_BUF_ENTRY_TYPE__DefProcessGroup &&
            b->etype == DEF_BUF_ENTRY_TYPE__DefProcessGroup )
   {
      DefBufEntry_DefProcessGroup_struct * p1 =
         static_cast<DefBufEntry_DefProcessGroup_struct*>(a);
      DefBufEntry_DefProcessGroup_struct * p2 =
         static_cast<DefBufEntry_DefProcessGroup_struct*>(b);

      int cmprc = strcmp( p1->name, p2->name );

      if( cmprc == 0 )
         return p1->deftoken < p2->deftoken;
      else
         return cmprc < 0 ? true : false;
   }
   // both record types are DEF_BUF_ENTRY_TYPE__DefinitionComment ? ...
   //
   if( a->etype == DEF_BUF_ENTRY_TYPE__DefinitionComment &&
       b->etype == DEF_BUF_ENTRY_TYPE__DefinitionComment )
   {
      DefBufEntry_DefinitionComment_struct * c1 =
	 static_cast<DefBufEntry_DefinitionComment_struct*>(a);
      DefBufEntry_DefinitionComment_struct * c2 =
	 static_cast<DefBufEntry_DefinitionComment_struct*>(b);

      // ... sort by trace order
      return c1->orderidx < c2->orderidx;
   }
   // both records have the same type ? ...
   //
   else if( a->etype == b->etype &&
	    ( a->etype != DEF_BUF_ENTRY_TYPE__DefCreator &&
	      a->etype != DEF_BUF_ENTRY_TYPE__DefTimerResolution ) )
       
   {
      // ... sort by defined token
      return a->deftoken < b->deftoken;
   }
   // otherwise ...
   else
   {
      // ... sort by type
      return a->etype < b->etype;
   }
}

bool 
Unifyer::unifyDefinitions( std::vector<DefBufEntry_Base_struct*> *
			   p_vecGlobDefs )
{
   if( Params.beverbose )
      std::cout << "Reading local definitions ..." << std::endl;

   // allocate vector for local definition
   std::vector<DefBufEntry_Base_struct*> * p_vec_loc_defs =
      new std::vector<DefBufEntry_Base_struct*>();
   assert( p_vec_loc_defs );

   // create record handler and set the local definition
   // record vector as first handler argument for ...
   //
   OTF_HandlerArray * p_handler_array =
      OTF_HandlerArray_open();
   assert( p_handler_array );

   // ... OTF_DEFINITIONCOMMENT_RECORD
   OTF_HandlerArray_setHandler( p_handler_array,
       (OTF_FunctionPointer*)Handle_DefinitionComment,
       OTF_DEFINITIONCOMMENT_RECORD );
   OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
      p_vec_loc_defs,
      OTF_DEFINITIONCOMMENT_RECORD );	

   // ... OTF_DEFCREATOR_RECORD
   OTF_HandlerArray_setHandler( p_handler_array,
      (OTF_FunctionPointer*)Handle_DefCreator,
      OTF_DEFCREATOR_RECORD );		
   OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
      p_vec_loc_defs,
      OTF_DEFCREATOR_RECORD );	

   // ... OTF_DEFTIMERRESOLUTION_RECORD
   OTF_HandlerArray_setHandler( p_handler_array,
      (OTF_FunctionPointer*)Handle_DefTimerResolution,
      OTF_DEFTIMERRESOLUTION_RECORD );
   OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
      p_vec_loc_defs,
      OTF_DEFTIMERRESOLUTION_RECORD );	

   // ... OTF_DEFPROCESSGROUP_RECORD
   OTF_HandlerArray_setHandler( p_handler_array,
      (OTF_FunctionPointer*)Handle_DefProcessGroup,
      OTF_DEFPROCESSGROUP_RECORD );
   OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
      p_vec_loc_defs,
      OTF_DEFPROCESSGROUP_RECORD );

   // ... OTF_DEFPROCESS_RECORD
   OTF_HandlerArray_setHandler( p_handler_array,
      (OTF_FunctionPointer*)Handle_DefProcess,
      OTF_DEFPROCESS_RECORD );
   OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
      p_vec_loc_defs,
      OTF_DEFPROCESS_RECORD );

   // ... OTF_DEFSCLFILE_RECORD
   OTF_HandlerArray_setHandler( p_handler_array,
      (OTF_FunctionPointer*)Handle_DefSclFile,
      OTF_DEFSCLFILE_RECORD );
   OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
      p_vec_loc_defs,
      OTF_DEFSCLFILE_RECORD );

   // ... OTF_DEFSCL_RECORD
   OTF_HandlerArray_setHandler( p_handler_array,
      (OTF_FunctionPointer*)Handle_DefScl,
      OTF_DEFSCL_RECORD );
   OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
      p_vec_loc_defs,
      OTF_DEFSCL_RECORD );

   // ... OTF_DEFFUNCTIONGROUP_RECORD
   OTF_HandlerArray_setHandler( p_handler_array,
      (OTF_FunctionPointer*)Handle_DefFunctionGroup,
      OTF_DEFFUNCTIONGROUP_RECORD );
   OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
      p_vec_loc_defs,
      OTF_DEFFUNCTIONGROUP_RECORD );

   // ... OTF_DEFFUNCTION_RECORD
   OTF_HandlerArray_setHandler( p_handler_array,
      (OTF_FunctionPointer*)Handle_DefFunction,
      OTF_DEFFUNCTION_RECORD );
   OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
      p_vec_loc_defs,
      OTF_DEFFUNCTION_RECORD );

   // ... OTF_DEFCOLLOP_RECORD
   OTF_HandlerArray_setHandler( p_handler_array,
      (OTF_FunctionPointer*)Handle_DefCollectiveOperation,
      OTF_DEFCOLLOP_RECORD );
   OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
      p_vec_loc_defs,
      OTF_DEFCOLLOP_RECORD );

   // ... OTF_DEFCOUNTERGROUP_RECORD
   OTF_HandlerArray_setHandler( p_handler_array,
      (OTF_FunctionPointer*)Handle_DefCounterGroup,
      OTF_DEFCOUNTERGROUP_RECORD );
   OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
      p_vec_loc_defs,
      OTF_DEFCOUNTERGROUP_RECORD );

   // ... OTF_DEFCOUNTER_RECORD
   OTF_HandlerArray_setHandler( p_handler_array,
      (OTF_FunctionPointer*)Handle_DefCounter,
      OTF_DEFCOUNTER_RECORD );
   OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
      p_vec_loc_defs,
      OTF_DEFCOUNTER_RECORD );

   // read local definitions
   //
   for( uint32_t i = 0; i < m_vecUnifyCtls.size(); i++ )
   {
      // open file manager for reader stream
      OTF_FileManager * p_loc_def_manager 
	 = OTF_FileManager_open( 1 );
      assert( p_loc_def_manager );

      // open stream for reading
      OTF_RStream * p_loc_def_rstream =
	 OTF_RStream_open( Params.in_file_prefix.c_str(),
			   m_vecUnifyCtls[i]->streamid,
			   p_loc_def_manager );
      assert( p_loc_def_rstream );

      if( Params.beverbose )
	 std::cout << " Opened OTF reader stream [namestub "
		   << Params.in_file_prefix << " id "
		   << std::hex << m_vecUnifyCtls[i]->streamid << "]" 
		   << std::dec << std::endl;

      // read definitions
      OTF_RStream_readDefinitions( p_loc_def_rstream, p_handler_array );

      // close reader stream 
      OTF_RStream_close( p_loc_def_rstream );
      // close file manager for reader stream
      OTF_FileManager_close( p_loc_def_manager );

      if( Params.beverbose )
	 std::cout << " Closed OTF reader stream [namestub "
		   << Params.in_file_prefix << " id "
		   << std::hex << m_vecUnifyCtls[i]->streamid << "]"
		   << std::dec << std::endl;
   }

   // close record handler
   OTF_HandlerArray_close( p_handler_array );

   // sort local definitions
   std::sort( p_vec_loc_defs->begin(), p_vec_loc_defs->end(),
	      LocDefsCmp );
   
   // create global definitions
   //
   std::map<std::string, std::vector<uint32_t> > mapnodeprocs;
   uint32_t mpi_comm_idx = 0, omp_comm_idx = 0;

   for( uint32_t i = 0; i < p_vec_loc_defs->size(); i++ )
   {
      switch( (*p_vec_loc_defs)[i]->etype )
      {
	 // DefinitionComment
	 //
         case DEF_BUF_ENTRY_TYPE__DefinitionComment:
	 {
	    // get local definition entry
	    DefBufEntry_DefinitionComment_struct * p_loc_def_entry =
	       (DefBufEntry_DefinitionComment_struct*)((*p_vec_loc_defs)[i]);

	    // add definition without any changes to vector of
	    // global definitions
	    p_vecGlobDefs->push_back( new DefBufEntry_DefinitionComment_struct(
					 p_loc_def_entry->orderidx,
					 p_loc_def_entry->comment ) );
	    
	    break;
	 }
	 // DefCreator
	 //
         case DEF_BUF_ENTRY_TYPE__DefCreator:
	 {
	    // get local definition entry
	    DefBufEntry_DefCreator_struct * p_loc_def_entry =
	       (DefBufEntry_DefCreator_struct*)((*p_vec_loc_defs)[i]);

	    // add definition without any changes to vector of
	    // global definitions
	    p_vecGlobDefs->push_back( new DefBufEntry_DefCreator_struct(
					 p_loc_def_entry->creator ) );
	    
	    break;
	 }
	 // DefTimerResolution
	 //
         case DEF_BUF_ENTRY_TYPE__DefTimerResolution:
	 {
	    // get local definition entry
	    DefBufEntry_DefTimerResolution_struct * p_loc_def_entry =
	       (DefBufEntry_DefTimerResolution_struct*)((*p_vec_loc_defs)[i]);

	    // add definition without any changes to vector of
	    // global definitions
	    p_vecGlobDefs->push_back( new DefBufEntry_DefTimerResolution_struct(
					 p_loc_def_entry->ticksPerSecond ) );

	       break;
	 }
	 // DefProcess
	 //
         case DEF_BUF_ENTRY_TYPE__DefProcess:
	 {
	    // get local definition entry
	    DefBufEntry_DefProcess_struct *p_loc_def_entry =
	       (DefBufEntry_DefProcess_struct*)((*p_vec_loc_defs)[i]);

	    // add definition without any changes to vector of
	    // global definitions
	    p_vecGlobDefs->push_back( new DefBufEntry_DefProcess_struct(
					 p_loc_def_entry->deftoken,
					 p_loc_def_entry->name,
					 p_loc_def_entry->parent ) );

	    break;
	 }
	 // DefProcessGroup
	 //
         case DEF_BUF_ENTRY_TYPE__DefProcessGroup:
	 {
	    // get local definition entry
	    DefBufEntry_DefProcessGroup_struct * p_loc_def_entry =
	       (DefBufEntry_DefProcessGroup_struct*)((*p_vec_loc_defs)[i]);

	    if( strlen( p_loc_def_entry->name ) > 4
		&& strncmp( p_loc_def_entry->name, "Node", 4 ) == 0 )
	    {
	       std::string nodename = p_loc_def_entry->name+5;

	       std::vector<uint32_t>::iterator it =
		  std::find( mapnodeprocs[nodename].begin(),
			     mapnodeprocs[nodename].end(),
			     *(p_loc_def_entry->array) );

	       if( it == mapnodeprocs[nodename].end() )
		  mapnodeprocs[nodename].push_back( *(p_loc_def_entry->array) );
	    }
	    else
	    {
	       // get global token factory for this definition type
	       TokenFactory_DefProcessGroup * p_tkfac_defprocessgroup =
		  static_cast<TokenFactory_DefProcessGroup*>(theTokenFactory[TKFAC__DEF_PROCESS_GROUP]);
	       
	       // get global token
	       uint32_t global_token =
		  p_tkfac_defprocessgroup->getGlobalToken(
		     p_loc_def_entry->name,
		     p_loc_def_entry->n,
		     p_loc_def_entry->array );
	       
	       // global token found ?
	       if( global_token == 0 )
	       {
		  // no -> create it
		  global_token =
		     p_tkfac_defprocessgroup->createGlobalToken(
			p_loc_def_entry->loccpuid,
			p_loc_def_entry->deftoken,
			p_loc_def_entry->name,
			p_loc_def_entry->n,
			p_loc_def_entry->array );

		  char new_name[256];
		  if( strcmp( p_loc_def_entry->name, "MPI Communicator" ) == 0 )
		     snprintf( new_name, sizeof( new_name ),
			       "%s %d", p_loc_def_entry->name, mpi_comm_idx++ );
		  else if( strcmp( p_loc_def_entry->name,
				   "OMP Thread Team" ) == 0 )
		     snprintf( new_name, sizeof( new_name ),
			       "%s %d", p_loc_def_entry->name, omp_comm_idx++ );
		  else
		     strncpy( new_name, p_loc_def_entry->name,
			      sizeof( new_name ) );
		  
		  // add new definition to vector of global definitions
		  p_vecGlobDefs->push_back( new DefBufEntry_DefProcessGroup_struct(
					       0,
					       global_token,
					       new_name,
					       p_loc_def_entry->n,
					       p_loc_def_entry->array ) );
	       }
	       else
	       {
		  // yes -> (global definition already exists in vector)
		  
		  // set translation for this local process id, if necessary
		  //
		  if( p_tkfac_defprocessgroup->translateLocalToken(
			 p_loc_def_entry->loccpuid,
			 p_loc_def_entry->deftoken ) == 0 )
		  {
		     p_tkfac_defprocessgroup->setTranslation(
			p_loc_def_entry->loccpuid,
			p_loc_def_entry->deftoken,
			global_token );
		  }
	       }
	    }

	    break;
	 }
	 // DefSclFile
	 //
         case DEF_BUF_ENTRY_TYPE__DefSclFile:
	 {
	    // get local definition entry
	    DefBufEntry_DefSclFile_struct * p_loc_def_entry =
	       (DefBufEntry_DefSclFile_struct*)((*p_vec_loc_defs)[i]);

	    // get global token factory for this definition type
	    TokenFactory_DefSclFile * p_tkfac_defsclfile =
	       static_cast<TokenFactory_DefSclFile*>(theTokenFactory[TKFAC__DEF_SCL_FILE]);

	    // get global token
	    uint32_t global_token =
	       p_tkfac_defsclfile->getGlobalToken(
		  p_loc_def_entry->filename );

	    // global token found ?
	    if( global_token == 0 )
	    {
	       // no -> create it
	       global_token = 
		  p_tkfac_defsclfile->createGlobalToken(
		     p_loc_def_entry->loccpuid,
		     p_loc_def_entry->deftoken,
		     p_loc_def_entry->filename );

	       // add new definition to vector of global definitions
	       p_vecGlobDefs->push_back( new DefBufEntry_DefSclFile_struct(
					    0,
					    global_token,
					    p_loc_def_entry->filename ) );
	    }
	    else
	    {
	       // yes -> (global definition already exists in vector)

	       // set translation for this local process id, if necessary
	       //
	       if( p_tkfac_defsclfile->translateLocalToken(
		      p_loc_def_entry->loccpuid,
		      p_loc_def_entry->deftoken ) == 0 )
	       {
		  p_tkfac_defsclfile->setTranslation(
		     p_loc_def_entry->loccpuid,
		     p_loc_def_entry->deftoken,
		     global_token );
	       }
	    }

	    break;
	 }
	 // DefScl
	 //
         case DEF_BUF_ENTRY_TYPE__DefScl:
	 {
	    // get local definition entry
	    DefBufEntry_DefScl_struct * p_loc_def_entry =
	       (DefBufEntry_DefScl_struct*)((*p_vec_loc_defs)[i]);

	    // get global token factory for DefSclFile
	    TokenFactory_DefSclFile * p_tkfac_defsclfile =
	       static_cast<TokenFactory_DefSclFile*>(theTokenFactory[TKFAC__DEF_SCL_FILE]);

	    // get global token factory for this definition type
	    TokenFactory_DefScl * p_tkfac_defscl = 
	       static_cast<TokenFactory_DefScl*>(theTokenFactory[TKFAC__DEF_SCL]);

	    // get global token for DefSclFile (exit if not exists)
	    uint32_t global_sclfile =
	       p_tkfac_defsclfile->translateLocalToken(
		  p_loc_def_entry->loccpuid,
		  p_loc_def_entry->sclfile );
	    assert( global_sclfile != 0 );

	    // get global token
	    uint32_t global_token =
	       p_tkfac_defscl->getGlobalToken( global_sclfile,
					       p_loc_def_entry->sclline );

	    // global token found ?
	    if( global_token == 0 )
	    {
	       // no -> create it
	       global_token =
		  p_tkfac_defscl->createGlobalToken( p_loc_def_entry->loccpuid,
						     p_loc_def_entry->deftoken,
						     global_sclfile,
						     p_loc_def_entry->sclline );

	       // add new definition to vector of global definitions
	       p_vecGlobDefs->push_back( new DefBufEntry_DefScl_struct(
					    0,
					    global_token,
					    global_sclfile,
					    p_loc_def_entry->sclline ) );
	    }
	    else
	    {
	       // yes -> (global definition already exists in vector)

	       // set translation for this local process id, if necessary
	       //
	       if( p_tkfac_defscl->translateLocalToken(
		      p_loc_def_entry->loccpuid,
		      p_loc_def_entry->deftoken ) == 0 )
	       {
		  p_tkfac_defscl->setTranslation(
		     p_loc_def_entry->loccpuid,
		     p_loc_def_entry->deftoken,
		     global_token );
	       }
	    }

	    break;
	 }
	 // DefFunctionGroup
	 //
         case DEF_BUF_ENTRY_TYPE__DefFunctionGroup:
	 {
	    // get local definition entry
	    DefBufEntry_DefFunctionGroup_struct * p_loc_def_entry =
	       (DefBufEntry_DefFunctionGroup_struct*)((*p_vec_loc_defs)[i]);

	    // get global token factory for this definition type
	    TokenFactory_DefFunctionGroup * p_tkfac_deffunctiongroup = 
	       static_cast<TokenFactory_DefFunctionGroup*>(theTokenFactory[TKFAC__DEF_FUNCTION_GROUP]);

	    // get global token
	    uint32_t global_token =
	       p_tkfac_deffunctiongroup->getGlobalToken(
		  p_loc_def_entry->name );

	    // global token found ?
	    if( global_token == 0 )
	    {
	       // no -> create it
	       global_token = 
		  p_tkfac_deffunctiongroup->createGlobalToken(
		     p_loc_def_entry->loccpuid,
		     p_loc_def_entry->deftoken,
		     p_loc_def_entry->name );

	       // add new definition to vector of global definitions
	       p_vecGlobDefs->push_back( new DefBufEntry_DefFunctionGroup_struct(
					    0,
					    global_token,
					    p_loc_def_entry->name ) );
	    }
	    else
	    {
	       // yes -> (global definition already exists in vector)

	       // set translation for this local process id, if necessary
	       //
	       if( p_tkfac_deffunctiongroup->translateLocalToken(
		      p_loc_def_entry->loccpuid,
		      p_loc_def_entry->deftoken ) == 0 )
	       {
		  p_tkfac_deffunctiongroup->setTranslation(
		     p_loc_def_entry->loccpuid,
		     p_loc_def_entry->deftoken,
		     global_token );
	       }
	    }

	    break;
	 }
	 // DefFunction
	 //
         case DEF_BUF_ENTRY_TYPE__DefFunction:
	 {
	    // get local definition entry
	    DefBufEntry_DefFunction_struct * p_loc_def_entry =
	       (DefBufEntry_DefFunction_struct*)((*p_vec_loc_defs)[i]);

	    // get global token factory for DefFunctionGroup
	    TokenFactory_DefFunctionGroup * p_tkfac_deffunctiongroup = 
	       static_cast<TokenFactory_DefFunctionGroup*>(theTokenFactory[TKFAC__DEF_FUNCTION_GROUP]);

	    // get global token factory for DefScl
	    TokenFactory_DefScl * p_tkfac_defscl = 
	       static_cast<TokenFactory_DefScl*>(theTokenFactory[TKFAC__DEF_SCL]);

	    // get global token factory for this definition type
	    TokenFactory_DefFunction * p_tkfac_deffunction =
	       static_cast<TokenFactory_DefFunction*>(theTokenFactory[TKFAC__DEF_FUNCTION]);

	    // get global token for DefFunctionGroup (exit if not exists)
	    uint32_t global_group =
	       p_tkfac_deffunctiongroup->translateLocalToken(
		  p_loc_def_entry->loccpuid,
		  p_loc_def_entry->group );
	    assert( global_group != 0 );

	    // get global token for DefScl (exit if not exists)
	    uint32_t global_scltoken = p_loc_def_entry->scltoken;
	    if( p_loc_def_entry->scltoken != 0 )
	    {
	       global_scltoken = 
		  p_tkfac_defscl->translateLocalToken(
		     p_loc_def_entry->loccpuid,
		     p_loc_def_entry->scltoken );
	       assert( global_scltoken != 0 );
	    }

	    // get global token
	    uint32_t global_token =
	       p_tkfac_deffunction->getGlobalToken(
		  p_loc_def_entry->name,
		  global_group,
		  global_scltoken );

	    // global token found ?
	    if( global_token == 0 )
	    {
	       // no -> create it
	       global_token =
		  p_tkfac_deffunction->createGlobalToken(
		     p_loc_def_entry->loccpuid,
		     p_loc_def_entry->deftoken,
		     p_loc_def_entry->name,
		     global_group,
		     global_scltoken );

	       // add new definition to vector of global definitions
	       p_vecGlobDefs->push_back( new DefBufEntry_DefFunction_struct(
					    0,
					    global_token,
					    p_loc_def_entry->name,
					    global_group,
					    global_scltoken ) );
	    }
	    else
	    {
	       // yes -> (global definition already exists in vector)

	       // set translation for this local process id, if necessary
	       //
	       if( p_tkfac_deffunction->translateLocalToken(
		      p_loc_def_entry->loccpuid,
		      p_loc_def_entry->deftoken ) == 0 )
	       {
		  p_tkfac_deffunction->setTranslation(
		     p_loc_def_entry->loccpuid,
		     p_loc_def_entry->deftoken,
		     global_token );
	       }
	    }

	    break;
	 }
	 // DefCollectiveOperation
	 //
         case DEF_BUF_ENTRY_TYPE__DefCollectiveOperation:
	 {
	    // get local definition entry
	    DefBufEntry_DefCollectiveOperation_struct * p_loc_def_entry =
	       (DefBufEntry_DefCollectiveOperation_struct*)((*p_vec_loc_defs)[i]);

	    // get global token factory for this definition type
	    TokenFactory_DefCollectiveOperation * p_tkfac_defcollop =
	       static_cast<TokenFactory_DefCollectiveOperation*>(theTokenFactory[TKFAC__DEF_COLL_OP]);

	    // get global token
	    uint32_t global_token =
	       p_tkfac_defcollop->getGlobalToken(
		  p_loc_def_entry->name,
		  p_loc_def_entry->type );

	    // global token found ?
	    if( global_token == 0 )
	    {
	       // no -> create it
	       global_token =
		  p_tkfac_defcollop->createGlobalToken(
		     p_loc_def_entry->loccpuid,
		     p_loc_def_entry->deftoken,
		     p_loc_def_entry->name,
		     p_loc_def_entry->type );

	       // add new definition to vector of global definitions
	       p_vecGlobDefs->push_back( new DefBufEntry_DefCollectiveOperation_struct(
					    0,
					    global_token,
					    p_loc_def_entry->name,
					    p_loc_def_entry->type ) );
	    }
	    else
	    {
	       // yes -> (global definition already exists in vector)

	       // set translation for this local process id, if necessary
	       //
	       if( p_tkfac_defcollop->translateLocalToken(
		      p_loc_def_entry->loccpuid,
		      p_loc_def_entry->deftoken ) == 0 )
	       {
		  p_tkfac_defcollop->setTranslation(
		     p_loc_def_entry->loccpuid,
		     p_loc_def_entry->deftoken,
		     global_token );
	       }
	    }

	    break;
	 }
	 // DefCounterGroup
	 //
         case DEF_BUF_ENTRY_TYPE__DefCounterGroup:
	 {
	    // get local definition entry
	    DefBufEntry_DefCounterGroup_struct * p_loc_def_entry =
	       (DefBufEntry_DefCounterGroup_struct*)((*p_vec_loc_defs)[i]);

	    // get global token factory for this definition type
	    TokenFactory_DefCounterGroup * p_tkfac_defcountergroup =
	       static_cast<TokenFactory_DefCounterGroup*>(theTokenFactory[TKFAC__DEF_COUNTER_GROUP]);

	    // get global token
	    uint32_t global_token =
	       p_tkfac_defcountergroup->getGlobalToken(
		  p_loc_def_entry->name );

	    // global token found ?
	    if( global_token == 0 )
	    {
	       // no -> create it
	       global_token = 
		  p_tkfac_defcountergroup->createGlobalToken(
		     p_loc_def_entry->loccpuid,
		     p_loc_def_entry->deftoken,
		     p_loc_def_entry->name );
	       
	       // add new definition to vector of global definitions
	       p_vecGlobDefs->push_back( new DefBufEntry_DefCounterGroup_struct(
					    0,
					    global_token,
					    p_loc_def_entry->name ) );
	    }
	    else
	    {
	       // yes -> (global definition already exists in vector)
	       
	       // set translation for this local process id, if necessary
	       //
	       if( p_tkfac_defcountergroup->translateLocalToken(
		      p_loc_def_entry->loccpuid,
		      p_loc_def_entry->deftoken ) == 0 )
	       {
		  p_tkfac_defcountergroup->setTranslation(
		     p_loc_def_entry->loccpuid,
		     p_loc_def_entry->deftoken,
		     global_token );
	       }
	    }

	    break;
	 }
	 // DefCounter
	 //
         case DEF_BUF_ENTRY_TYPE__DefCounter:
	 {
	    // get local definition entry
	    DefBufEntry_DefCounter_struct * p_loc_def_entry =
	       (DefBufEntry_DefCounter_struct*)((*p_vec_loc_defs)[i]);

	    // get global token factory for DefCounterGroup
	    TokenFactory_DefCounterGroup * p_tkfac_defcountergroup =
	       static_cast<TokenFactory_DefCounterGroup*>(theTokenFactory[TKFAC__DEF_COUNTER_GROUP]);

	    // get global token factory for this definition type
	    TokenFactory_DefCounter * p_tkfac_defcounter = 
	       static_cast<TokenFactory_DefCounter*>(theTokenFactory[TKFAC__DEF_COUNTER]);

	    // get global token for DefCounterGroup (exit if not exists)
	    uint32_t global_countergroup =
	       p_tkfac_defcountergroup->translateLocalToken(
		  p_loc_def_entry->loccpuid,
		  p_loc_def_entry->countergroup );
	    assert( global_countergroup != 0 );

	    // get global token
	    uint32_t global_token =
	       p_tkfac_defcounter->getGlobalToken(
		  p_loc_def_entry->name,
		  p_loc_def_entry->properties,
		  global_countergroup,
		  p_loc_def_entry->unit );

	    // global token found ?
	    if( global_token == 0 )
	    {
	       // no -> create it
	       global_token =
		  p_tkfac_defcounter->createGlobalToken(
		     p_loc_def_entry->loccpuid,
		     p_loc_def_entry->deftoken,
		     p_loc_def_entry->name,
		     p_loc_def_entry->properties,
		     global_countergroup,
		     p_loc_def_entry->unit );

	       // add new definition to vector of global definitions
	       p_vecGlobDefs->push_back( new DefBufEntry_DefCounter_struct(
					    0,
					    global_token,
					    p_loc_def_entry->name,
					    p_loc_def_entry->properties,
					    global_countergroup,
					    p_loc_def_entry->unit ) );
	    }
	    else
	    {
	       // yes -> (global definition already exists in vector)

	       // set translation for this local process id, if necessary
	       //
	       if( p_tkfac_defcounter->translateLocalToken(
		      p_loc_def_entry->loccpuid,
		      p_loc_def_entry->deftoken ) == 0 )
	       {
		  p_tkfac_defcounter->setTranslation(
		     p_loc_def_entry->loccpuid,
		     p_loc_def_entry->deftoken,
		     global_token );
	       }
	    }

	    break;
	 }
      }
   }

   // add process group records for nodes to global definition records
   uint32_t seq_node_token = 1500000000;
   for( std::map<std::string, std::vector<uint32_t> >::iterator it =
	   mapnodeprocs.begin(); it != mapnodeprocs.end(); it++ )
   {
      p_vecGlobDefs->push_back( new DefBufEntry_DefProcessGroup_struct(
				   0,
				   seq_node_token++,
				   it->first,
				   it->second ) );
   }

   // sort global definition records
   std::sort( p_vecGlobDefs->begin(), p_vecGlobDefs->end(),
	      GlobDefsCmp );

   // free global definition record vector
   //
   for( uint32_t i = 0; i < p_vec_loc_defs->size(); i++ )
      delete (*p_vec_loc_defs)[i];
   delete p_vec_loc_defs;

   return true;
}

bool
Unifyer::unifyEvents()
{
   if( Params.beverbose )
      std::cout << "Unifying events ..." << std::endl;

   bool error = false;

   int i;
   int size = (int)m_vecUnifyCtls.size();

   std::string tmp_out_file_prefix =
      Params.out_file_prefix + TmpFileSuffix;

   std::vector< uint32_t > vec_progress;
   vec_progress.resize( size );
   for( i = 0; i < size; i++ )
      vec_progress[i] = 0;

#if (defined (VT_OMP))

   uint32_t threads_needed = m_vecUnifyCtls.size();
   uint32_t threads_set;

   uint32_t omp_max_threads = omp_get_max_threads();
   char * env_omp_num_threads = getenv( "OMP_NUM_THREADS" );

   if( env_omp_num_threads )
   {
      if( threads_needed < atoi( env_omp_num_threads ) )
      {
	 omp_set_num_threads( threads_needed );
	 threads_set = threads_needed;
      }
      else
      {
	 threads_set = atoi( env_omp_num_threads );
      }
   }
   else
   {
      if( threads_needed < omp_max_threads )
      {
	 omp_set_num_threads( threads_needed );
	 threads_set = threads_needed;
      }
      else
      {
	 omp_set_num_threads( omp_max_threads );
	 threads_set = omp_max_threads;
      }
   }

   if( Params.beverbose )
   {
      std::cout << " Using " << threads_set << " worker thread(s)" << std::endl;
   }

#  pragma omp parallel for private(i)
#endif
   for( i = 0; i < size; i++ )
   {
      // open file manager for reader stream
      OTF_FileManager * p_org_events_manager =
	 OTF_FileManager_open( 1 );
      assert( p_org_events_manager );

      // open stream for reading
      OTF_RStream * p_org_events_rstream =
	 OTF_RStream_open( Params.in_file_prefix.c_str(),
			   m_vecUnifyCtls[i]->streamid,
			   p_org_events_manager );
      assert( p_org_events_rstream );

      if( Params.beverbose )
      {
#if (defined (VT_OMP))
#        pragma omp critical
         {
	 std::cout << " [" << omp_get_thread_num() << "]:" << std::flush;
#endif
	 std::cout << " Opened OTF reader stream [namestub "
		   << Params.in_file_prefix << " id "
		   << std::hex << m_vecUnifyCtls[i]->streamid << "]" 
		   << std::dec << std::endl;

#if (defined (VT_OMP))
	 }
#endif
      }

      // open file manager for writer stream
      OTF_FileManager * p_uni_events_manager =
	 OTF_FileManager_open( 1 );
      assert( p_uni_events_manager );

      // open stream for writing
      OTF_WStream * p_uni_events_wstream =
	 OTF_WStream_open( tmp_out_file_prefix.c_str(),
			   m_vecUnifyCtls[i]->streamid,
			   p_uni_events_manager );
      assert( p_uni_events_wstream );

      if( Params.beverbose )
      {
#if (defined (VT_OMP))
#        pragma omp critical
         {
	 std::cout << " [" << omp_get_thread_num() << "]:" << std::flush;
#endif
	 std::cout << " Opened OTF writer stream [namestub "
		   << tmp_out_file_prefix << " id "
		   << std::hex << m_vecUnifyCtls[i]->streamid << "]"
		   << std::dec << std::endl;
#if (defined (VT_OMP))
	 }
#endif
      }

      // create record handler
      OTF_HandlerArray * p_handler_array =
	 OTF_HandlerArray_open();
      assert( p_handler_array );

      // create first handler argument
      EventFirstHandlerArg_struct * p_first_handler_arg =
	 new EventFirstHandlerArg_struct( p_uni_events_wstream,
					  ( uint32_t )i,
					  m_uMinStartTime );
      assert( p_first_handler_arg );

      // set record handler and first handler argument for ...
      //

      // ... OTF_ENTER_RECORD
      OTF_HandlerArray_setHandler( p_handler_array,
         (OTF_FunctionPointer*)Handle_Enter, OTF_ENTER_RECORD );
      OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
	 p_first_handler_arg, OTF_ENTER_RECORD );

      // ... OTF_LEAVE_RECORD
      OTF_HandlerArray_setHandler( p_handler_array,
         (OTF_FunctionPointer*)Handle_Leave, OTF_LEAVE_RECORD );
      OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
	 p_first_handler_arg, OTF_LEAVE_RECORD );

      // ... OTF_SEND_RECORD
      OTF_HandlerArray_setHandler( p_handler_array,
         (OTF_FunctionPointer*)Handle_SendMsg, OTF_SEND_RECORD );
      OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
	 p_first_handler_arg, OTF_SEND_RECORD );

      // ... OTF_RECEIVE_RECORD
      OTF_HandlerArray_setHandler( p_handler_array,
         (OTF_FunctionPointer*)Handle_RecvMsg, OTF_RECEIVE_RECORD );
      OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
	 p_first_handler_arg, OTF_RECEIVE_RECORD );

      // ... OTF_COLLOP_RECORD
      OTF_HandlerArray_setHandler( p_handler_array,
         (OTF_FunctionPointer*)Handle_CollectiveOperation, OTF_COLLOP_RECORD );
      OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
	 p_first_handler_arg, OTF_COLLOP_RECORD );

      // ... OTF_COUNTER_RECORD
      OTF_HandlerArray_setHandler( p_handler_array,
         (OTF_FunctionPointer*)Handle_Counter, OTF_COUNTER_RECORD );
      OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
	 p_first_handler_arg, OTF_COUNTER_RECORD );

      // ... OTF_EVENTCOMMENT_RECORD
      OTF_HandlerArray_setHandler( p_handler_array,
         (OTF_FunctionPointer*)Handle_EventComment, OTF_EVENTCOMMENT_RECORD );
      OTF_HandlerArray_setFirstHandlerArg( p_handler_array,
	 p_first_handler_arg, OTF_EVENTCOMMENT_RECORD );

      // set file compression
      if( Params.docompress )
      {
	 OTF_WStream_setCompression( p_uni_events_wstream,
				     OTF_FILECOMPRESSION_COMPRESSED );
      }

      // set record limit
      if( Params.beverbose )
	 OTF_RStream_setRecordLimit( p_org_events_rstream, 10000 );

      // read events
      //
      uint64_t records_read = 0;
      uint64_t minimum; uint64_t current; uint64_t maximum;
      while( ( records_read =
	       OTF_RStream_readEvents( p_org_events_rstream,
				       p_handler_array ) ) == 10000 )
      {
	 OTF_RStream_eventProgress( p_org_events_rstream, 
				    &minimum, &current, &maximum );

	 if( Params.beverbose )
	 {
#if (defined (VT_OMP))
#           pragma omp critical
	    {
#endif
	    vec_progress[i] = ( ( current - minimum ) * 100 )
	                      / ( maximum - minimum );
	 
	    UPDATE_PROGESSBAR;
#if (defined (VT_OMP))
	    }
#endif
	 }
      }
      
      // check for reading error
      if( records_read == OTF_READ_ERROR )
      {
	 std::cerr << ExeName << ": Error: An error occurred during reading local events" << std::endl;
#if (defined (VT_OMP))
#        pragma omp critical
#endif
	 error = true;
      }

      // close record handler
      OTF_HandlerArray_close( p_handler_array );

      // close writer stream
      OTF_WStream_close( p_uni_events_wstream );
      // close file manager for writer stream
      OTF_FileManager_close( p_uni_events_manager );

      if( Params.beverbose )
      {
#if (defined (VT_OMP))
#        pragma omp critical
         {
	 std::cout << " [" << omp_get_thread_num() << "]:" << std::flush;
#endif
	 std::cout << " Closed OTF writer stream [namestub "
		   << tmp_out_file_prefix << " id "
		   << std::hex << m_vecUnifyCtls[i]->streamid << "]"
		   << std::dec << std::endl;
#if (defined (VT_OMP))
	 }
#endif
      }

      // close reader stream
      OTF_RStream_close( p_org_events_rstream );
      // close file manager for reader stream
      OTF_FileManager_close( p_org_events_manager );

      if( Params.beverbose )
      {
#if (defined (VT_OMP))
#        pragma omp critical
         {
	 std::cout << " [" << omp_get_thread_num() << "]:" << std::flush;
#endif
	 std::cout << " Closed OTF reader stream [namestub "
		   << Params.in_file_prefix << " id "
		   << std::hex << m_vecUnifyCtls[i]->streamid << "]"
		   << std::dec << std::endl;
	 UPDATE_PROGESSBAR;
#if (defined (VT_OMP))
	 }
#endif
      }

      delete p_first_handler_arg;
   }

   if( Params.beverbose )
      std::cout << std::endl;

   return !error;
}

bool
Unifyer::writeGlobalDefinitions( std::vector<DefBufEntry_Base_struct*> *
				 p_vecGlobDefs )
{
   if( Params.beverbose )
      std::cout << "Writing global definitions ..."  << std::endl;

   assert( p_vecGlobDefs->size() > 0 );

   std::string tmp_out_file_prefix =
      Params.out_file_prefix + TmpFileSuffix;

   // open file manager for writer stream
   OTF_FileManager * p_glob_def_manager 
      = OTF_FileManager_open( 1 );
   assert( p_glob_def_manager );

   // open stream for writing (stream id = 0)
   OTF_WStream * p_glob_def_wstream =
      OTF_WStream_open( tmp_out_file_prefix.c_str(), 0, p_glob_def_manager );
   assert( p_glob_def_wstream );

   // set file compression
   if( Params.docompress )
   {
      OTF_WStream_setCompression( p_glob_def_wstream,
				  OTF_FILECOMPRESSION_COMPRESSED );
   }

   // try to get def. buffer
   if( !OTF_WStream_getDefBuffer( p_glob_def_wstream ) )
   {
      std::cerr << ExeName << ": Error: "
		<< "Cannot OTF writer stream [namestub "
		<< tmp_out_file_prefix.c_str() << " id 0]" << std::endl;
      OTF_WStream_close( p_glob_def_wstream );
      OTF_FileManager_close( p_glob_def_manager );
      return false;
   }

   if( Params.beverbose )
   {
      std::cout << " Opened OTF writer stream [namestub "
		<< tmp_out_file_prefix.c_str() << " id 0]" << std::endl;
   }

   // write global definition records
   //
   for( uint32_t i = 0; i < p_vecGlobDefs->size(); i++ )
   {
      switch( (*p_vecGlobDefs)[i]->etype )
      {
         case DEF_BUF_ENTRY_TYPE__DefinitionComment:
	 {
	    DefBufEntry_DefinitionComment_struct * p_entry =
	       (DefBufEntry_DefinitionComment_struct*)((*p_vecGlobDefs)[i]);

	    OTF_WStream_writeDefinitionComment( p_glob_def_wstream,
               p_entry->comment );

	    break;
	 }
         case DEF_BUF_ENTRY_TYPE__DefCreator:
	 {
	    DefBufEntry_DefCreator_struct * p_entry =
	       (DefBufEntry_DefCreator_struct*)((*p_vecGlobDefs)[i]);

	    OTF_WStream_writeDefCreator( p_glob_def_wstream,
               p_entry->creator );

	    break;
	 }
         case DEF_BUF_ENTRY_TYPE__DefTimerResolution:
	 {
	    DefBufEntry_DefTimerResolution_struct * p_entry =
	       (DefBufEntry_DefTimerResolution_struct*)((*p_vecGlobDefs)[i]);

	    OTF_WStream_writeDefTimerResolution( p_glob_def_wstream,
	       p_entry->ticksPerSecond );

	    break;
	 }
         case DEF_BUF_ENTRY_TYPE__DefProcess:
	 {
	    DefBufEntry_DefProcess_struct *p_entry =
	       (DefBufEntry_DefProcess_struct*)((*p_vecGlobDefs)[i]);

	    OTF_WStream_writeDefProcess( p_glob_def_wstream,
	       p_entry->deftoken,
	       p_entry->name,
	       p_entry->parent );

	    break;
	 }
         case DEF_BUF_ENTRY_TYPE__DefProcessGroup:
	 {
	    DefBufEntry_DefProcessGroup_struct * p_entry =
	       (DefBufEntry_DefProcessGroup_struct*)((*p_vecGlobDefs)[i]);

	    OTF_WStream_writeDefProcessGroup( p_glob_def_wstream,
	       p_entry->deftoken,
	       p_entry->name,
	       p_entry->n,
	       p_entry->array );

	    break;
	 }
         case DEF_BUF_ENTRY_TYPE__DefSclFile:
	 {
	    DefBufEntry_DefSclFile_struct * p_entry =
	       (DefBufEntry_DefSclFile_struct*)((*p_vecGlobDefs)[i]);

	    OTF_WStream_writeDefSclFile( p_glob_def_wstream,
	       p_entry->deftoken,
	       p_entry->filename );

	    break;
	 }
         case DEF_BUF_ENTRY_TYPE__DefScl:
	 {
	    DefBufEntry_DefScl_struct * p_entry =
	       (DefBufEntry_DefScl_struct*)((*p_vecGlobDefs)[i]);

	    OTF_WStream_writeDefScl( p_glob_def_wstream,
	       p_entry->deftoken,
	       p_entry->sclfile,
	       p_entry->sclline );

	    break;
	 }
         case DEF_BUF_ENTRY_TYPE__DefFunctionGroup:
	 {
	    DefBufEntry_DefFunctionGroup_struct * p_entry =
	       (DefBufEntry_DefFunctionGroup_struct*)((*p_vecGlobDefs)[i]);
	    
	    OTF_WStream_writeDefFunctionGroup( p_glob_def_wstream,
	       p_entry->deftoken,
	       p_entry->name );

	    break;
	 }
         case DEF_BUF_ENTRY_TYPE__DefFunction:
	 { 
	    DefBufEntry_DefFunction_struct * p_entry =
	       (DefBufEntry_DefFunction_struct*)((*p_vecGlobDefs)[i]);

	    OTF_WStream_writeDefFunction( p_glob_def_wstream,
	       p_entry->deftoken,
	       p_entry->name,
	       p_entry->group,
	       p_entry->scltoken );

	    break;
	 }
         case DEF_BUF_ENTRY_TYPE__DefCollectiveOperation:
	 {
	    DefBufEntry_DefCollectiveOperation_struct * p_entry =
	       (DefBufEntry_DefCollectiveOperation_struct*)((*p_vecGlobDefs)[i]);

	    OTF_WStream_writeDefCollectiveOperation( p_glob_def_wstream,
	       p_entry->deftoken,
	       p_entry->name,
	       p_entry->type );

	    break;
	 }
         case DEF_BUF_ENTRY_TYPE__DefCounterGroup:
	 {
	    DefBufEntry_DefCounterGroup_struct * p_entry =
	       (DefBufEntry_DefCounterGroup_struct*)((*p_vecGlobDefs)[i]);

	    OTF_WStream_writeDefCounterGroup( p_glob_def_wstream,
	       p_entry->deftoken,
	       p_entry->name );

	    break;
	 }
         case DEF_BUF_ENTRY_TYPE__DefCounter:
	 {
	    DefBufEntry_DefCounter_struct * p_entry =
	       (DefBufEntry_DefCounter_struct*)((*p_vecGlobDefs)[i]);
	    
	    OTF_WStream_writeDefCounter( p_glob_def_wstream,
	       p_entry->deftoken,
	       p_entry->name,
	       p_entry->properties,
	       p_entry->countergroup,
	       p_entry->unit );

	    break;
	 }
      }
   }

   // close writer stream
   OTF_WStream_close( p_glob_def_wstream );
   // close file manager for writer stream
   OTF_FileManager_close( p_glob_def_manager );

   if( Params.beverbose )
      std::cout << " Closed OTF writer stream [namestub "
		<< tmp_out_file_prefix << " id 0]" << std::endl;

   return true;
}

bool
Unifyer::writeMasterControl()
{
   if( Params.beverbose )
      std::cout << "Writing OTF master control ..." << std::endl;

   bool error = false;

   std::string tmp_out_file_prefix =
      Params.out_file_prefix + TmpFileSuffix;

   // open file manager
   OTF_FileManager * p_uni_mastercontrol_manager =
      OTF_FileManager_open( 1 );
   assert( p_uni_mastercontrol_manager );

   // create master control
   OTF_MasterControl * p_uni_mastercontrol =
      OTF_MasterControl_new( p_uni_mastercontrol_manager );
   assert( p_uni_mastercontrol );

   // put stream/process matching to master control
   //
   for( uint32_t i = 0; i < m_vecUnifyCtls.size(); i++ )
   {
      if( OTF_MasterControl_append( p_uni_mastercontrol,
				    m_vecUnifyCtls[i]->streamid,
				    m_vecUnifyCtls[i]->streamid ) == 0 )
      {
	 std::cerr << ExeName << ": Error: "
		   << "Cannot append "
		   << m_vecUnifyCtls[i]->streamid << ":"
		   << std::hex << m_vecUnifyCtls[i]->streamid
		   << " to OTF master control"
		   << std::dec << std::endl;
	 error = true;
	 break;
      }
   }

   // write master control
   if( !error )
   {
      OTF_MasterControl_write( p_uni_mastercontrol,
			       tmp_out_file_prefix.c_str() );

   if( Params.beverbose )
      std::cout << " Opened OTF master control [namestub "
		<< tmp_out_file_prefix << "]" << std::endl;
   }

   // close file master control
   OTF_MasterControl_close( p_uni_mastercontrol );
   // close file manager
   OTF_FileManager_close( p_uni_mastercontrol_manager );

   if( !error && Params.beverbose )
      std::cout << " Closed OTF master control [namestub "
		<< tmp_out_file_prefix << "]" << std::endl;

   return !error;
}

bool
Unifyer::getMinStartTime()
{
   for( uint32_t i = 0; i < m_vecUnifyCtls.size(); i++ )
   {
      // open file manager for reader stream
      OTF_FileManager * p_org_events_manager =
	 OTF_FileManager_open( 1 );
      assert( p_org_events_manager );

      // open stream for reading
      OTF_RStream * p_org_events_rstream =
	 OTF_RStream_open( Params.in_file_prefix.c_str(),
			   m_vecUnifyCtls[i]->streamid,
			   p_org_events_manager );
      assert( p_org_events_rstream );

      // create record handler
      OTF_HandlerArray * p_handler_array =
	 OTF_HandlerArray_open();
      assert( p_handler_array );

      // set zero record limit
      OTF_RStream_setRecordLimit( p_org_events_rstream, 0 );

      // start psoudo reading
      OTF_RStream_readEvents( p_org_events_rstream, p_handler_array );
      
      // get minimum timestamp
      uint64_t minimum; uint64_t current; uint64_t maximum;
      OTF_RStream_eventProgress( p_org_events_rstream, 
				 &minimum, &current, &maximum );

      if( m_uMinStartTime == (uint64_t)-1 ||
	  correctTime( i, minimum ) < m_uMinStartTime )
	 m_uMinStartTime = correctTime( i, minimum );

      // close record handler
      OTF_HandlerArray_close( p_handler_array );

      // close reader stream
      OTF_RStream_close( p_org_events_rstream );
      // close file manager for reader stream
      OTF_FileManager_close( p_org_events_manager );
   }
   
   return true;
}

bool
Unifyer::cleanUp()
{
   if( Params.beverbose )
      std::cout << "Cleaning up ..." << std::endl;

   uint32_t i;
   char filename1[STRBUFSIZE];
   char filename2[STRBUFSIZE];

   if( Params.doclean )
   {
      // remove unify control files
      //
      for( i = 0; i < Params.uctl_files_num; i++ )
      {
	 sprintf( filename1, "%s.%x.uctl",
		  Params.in_file_prefix.c_str(), i+1 );
	 
	 if( remove( filename1 ) != 0 )
	 {
	    std::cerr << ExeName << ": Error: Could not remove "
		      << filename1 << std::endl;
	    break;
	 }
	 
	 if( Params.beverbose )
	    std::cout << " Removed " << filename1 << std::endl;
      }

      if( i != Params.uctl_files_num )
	 return false;

      // remove local def./events trace files
      //
      for( i = 0; i < m_vecUnifyCtls.size(); i++ )
      {
	 for( uint32_t j = 0; j < 2; j++ )
	 {
	    OTF_getFilename( Params.in_file_prefix.c_str(),
			     m_vecUnifyCtls[i]->streamid,
			     j == 0 ? OTF_FILETYPE_DEF : OTF_FILETYPE_EVENT,
			     STRBUFSIZE, filename1 );
	    
	    if( access( filename1, F_OK ) != 0 )
	    {
	       // file not found, try '.z' suffix
	       strcat( filename1, ".z" );
	    }

	    if( remove( filename1 ) != 0 )
	    {
	       std::cerr << ExeName << ": Error: Could not remove "
			 << filename1 << "[.z]" << std::endl;
	       break;
	    }
	    
	    if( Params.beverbose )
	       std::cout << " Removed " << filename1 << std::endl;
	 }
      }

      if( i != m_vecUnifyCtls.size() )
	 return false;
   }

   std::string tmp_out_file_prefix =
      Params.out_file_prefix + TmpFileSuffix;

   // rename temporary global definition trace file
   //
   OTF_getFilename( tmp_out_file_prefix.c_str(), 0,
		    OTF_FILETYPE_DEF,
		    STRBUFSIZE, filename1 );
   OTF_getFilename( Params.out_file_prefix.c_str(), 0,
		    OTF_FILETYPE_DEF,
		    STRBUFSIZE, filename2 );
   
   if( access( filename1, F_OK ) != 0 )
   {
      // file not found, try '.z' suffix
      strcat( filename1, ".z" );
      strcat( filename2, ".z" );
   }

   if( rename( filename1, filename2 ) != 0 )
   {
      std::cerr << ExeName << ": Error: Could not rename " 
		<< filename1 << " to "
		<< filename2 << std::endl;
      return false;
   }
   
   if( Params.beverbose )
      std::cout << " Renamed " << filename1 << " to " << filename2 << std::endl;

   // rename temporary master control file
   //
   OTF_getFilename( tmp_out_file_prefix.c_str(), 0,
		    OTF_FILETYPE_MASTER,
		    STRBUFSIZE, filename1 );
   OTF_getFilename( Params.out_file_prefix.c_str(), 0,
		    OTF_FILETYPE_MASTER,
		    STRBUFSIZE, filename2 );

   if( rename( filename1, filename2 ) != 0 )
   {
      std::cerr << ExeName << ": Error: Could not rename " 
		<< filename1 << " to "
		<< filename2 << std::endl;
      return false;
   }

   if( Params.beverbose )
      std::cout << " Renamed " << filename1 << " to " << filename2 << std::endl;

   // rename all temporary event trace files
   //
   for( i = 0; i < m_vecUnifyCtls.size(); i++ )
   {
      OTF_getFilename( tmp_out_file_prefix.c_str(),
		       m_vecUnifyCtls[i]->streamid,
		       OTF_FILETYPE_EVENT,
		       STRBUFSIZE, filename1 );
      OTF_getFilename( Params.out_file_prefix.c_str(),
		       m_vecUnifyCtls[i]->streamid,
		       OTF_FILETYPE_EVENT,
		       STRBUFSIZE, filename2 );

      if( access( filename1, F_OK ) != 0 )
      {
	 // file not found, try '.z' suffix
	 strcat( filename1, ".z" );
	 strcat( filename2, ".z" );
      }

      if( rename( filename1, filename2 ) != 0 )
      {
	 std::cerr << ExeName << ": Error: Could not rename " 
		   << filename1 << " to "
		   << filename2 << std::endl;
	 return false;
      }

      if( Params.beverbose )
	 std::cout << " Renamed " << filename1 << " to " << filename2 << std::endl;
   }

   return true;
}
