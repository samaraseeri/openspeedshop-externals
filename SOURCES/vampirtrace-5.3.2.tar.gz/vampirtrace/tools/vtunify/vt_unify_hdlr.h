/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2007, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich GmbH, Federal
 * Republic of Germany
 *
 * See the file COPYRIGHT in the package base directory for details
 **/

#ifndef _VT_UNIFY_HDLR_H_
#define _VT_UNIFY_HDLR_H_

#include "vt_unify_defs.h"

#include <map>
#include <string>
#include <vector>

#include <otf.h>

//
// data structure of first event handler argument
//
struct EventFirstHandlerArg_struct
{
   EventFirstHandlerArg_struct() : wstream(0), uid(0) {}
   EventFirstHandlerArg_struct( OTF_WStream * _wstream,
				uint32_t _uid, uint64_t _minstime )
      : wstream(_wstream), uid(_uid), minstime(_minstime) {}

   OTF_WStream * wstream;
   uint32_t uid;
   uint64_t minstime;
};

//////////////////// OTF record handler ////////////////////

// definition record handler
//

int Handle_DefinitionComment(
   std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
   uint32_t streamid, const char* comment );
int Handle_DefCreator(
   std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
   uint32_t streamid, const char* creator );

int Handle_DefTimerResolution(
   std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
   uint32_t streamid, uint64_t ticksPerSecond );

int Handle_DefProcessGroup(
   std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
   uint32_t streamid, uint32_t deftoken, const char* name,
   uint32_t n, uint32_t* array ); 

int Handle_DefProcess(
   std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
   uint32_t streamid, uint32_t deftoken, const char* name,
   uint32_t parent );

int Handle_DefSclFile(
   std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
   uint32_t streamid, uint32_t deftoken, const char* filename );

int Handle_DefScl(
   std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
   uint32_t streamid, uint32_t deftoken, uint32_t sclfile,
   uint32_t sclline );

int Handle_DefFunctionGroup(
   std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
   uint32_t streamid, uint32_t deftoken, const char* name );

int Handle_DefFunction(
   std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
   uint32_t streamid, uint32_t deftoken, const char* name,
   uint32_t group, uint32_t scltoken );

int Handle_DefCollectiveOperation(
   std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
   uint32_t streamid, uint32_t collOp, const char* name,
   uint32_t type );

int Handle_DefCounterGroup(
   std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
   uint32_t streamid, uint32_t deftoken, const char* name );

int Handle_DefCounter(
   std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
   uint32_t streamid, uint32_t deftoken, const char* name,
   uint32_t properties, uint32_t countergroup, const char* unit );

// event record handler
//

int Handle_Enter(
   EventFirstHandlerArg_struct* fharg,
   uint64_t time, uint32_t statetoken, uint32_t cpuid,
   uint32_t scltoken );

int Handle_Leave(
   EventFirstHandlerArg_struct* fharg,
   uint64_t time, uint32_t statetoken, uint32_t cpuid,
   uint32_t scltoken );

int Handle_SendMsg(
   EventFirstHandlerArg_struct* fharg,
   uint64_t time, uint32_t sender, uint32_t receiver,
   uint32_t communicator, uint32_t msgtag, 
   uint32_t msglength, uint32_t scltoken );

int Handle_RecvMsg(
   EventFirstHandlerArg_struct* fharg,
   uint64_t time, uint32_t receiver, uint32_t sender,
   uint32_t communicator, uint32_t msgtag,
   uint32_t msglength, uint32_t scltoken );

int Handle_CollectiveOperation(
   EventFirstHandlerArg_struct* fharg,
   uint64_t time, uint32_t process,
   uint32_t functionToken, uint32_t communicator,
   uint32_t rootprocess, uint32_t sent,
   uint32_t received, uint64_t duration,
   uint32_t scltoken );

int Handle_Counter(
   EventFirstHandlerArg_struct* fharg,
   uint64_t time, uint32_t process, uint32_t counter_token,
   uint64_t value );

int Handle_EventComment(
   EventFirstHandlerArg_struct* fharg,
   uint64_t time, uint32_t process, const char* comment );

#endif // _VT_UNIFY_HDLR_H_
