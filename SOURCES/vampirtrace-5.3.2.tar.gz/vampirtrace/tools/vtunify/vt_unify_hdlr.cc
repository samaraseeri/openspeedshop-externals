/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2007, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich GmbH, Federal
 * Republic of Germany
 *
 * See the file COPYRIGHT in the package base directory for details
 **/

#include "vt_unify_hdlr.h"
#include "vt_unify_tkfac.h"
#include "vt_unify.h"

//////////////////// OTF record handler ////////////////////

// definition record handler
//

int Handle_DefinitionComment( std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
			      uint32_t streamid, const char* comment )
{
   static uint32_t orderidx = 0;

   if( streamid == 1 )
      p_vecLocDefRecs->push_back( new DefBufEntry_DefinitionComment_struct(
				     orderidx++,
				     comment ) );

   return OTF_RETURN_OK;
}

int Handle_DefCreator( std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
		       uint32_t streamid, const char* creator )
{
   static bool creator_wrote = false;

   if( !creator_wrote )
   {
      p_vecLocDefRecs->push_back( new DefBufEntry_DefCreator_struct(
				     creator ) );
      creator_wrote = true;
   }

   return OTF_RETURN_OK;
}

int
Handle_DefTimerResolution( std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
			   uint32_t streamid, uint64_t ticksPerSecond )
{
   static bool timerres_wrote = false;

   if( !timerres_wrote )
   {
      p_vecLocDefRecs->push_back( new DefBufEntry_DefTimerResolution_struct(
				     ticksPerSecond ) );
      timerres_wrote = true;
   }

   return OTF_RETURN_OK;
}

int
Handle_DefProcessGroup( std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
			uint32_t streamid, uint32_t deftoken, const char* name,
			uint32_t n, uint32_t* array )
{
   p_vecLocDefRecs->push_back( new DefBufEntry_DefProcessGroup_struct(
				  streamid % 65536,
				  deftoken,
				  name,
				  n,
				  array ) );

   return OTF_RETURN_OK;
}

int
Handle_DefProcess( std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
		   uint32_t streamid, uint32_t deftoken, const char* name,
		   uint32_t parent )
{
   p_vecLocDefRecs->push_back( new DefBufEntry_DefProcess_struct(
				  deftoken,
				  name,
				  parent ) );
   return OTF_RETURN_OK;
}

int
Handle_DefSclFile( std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
		   uint32_t streamid, uint32_t deftoken, const char* filename )
{
   p_vecLocDefRecs->push_back( new DefBufEntry_DefSclFile_struct(
				  streamid % 65536,
				  deftoken,
				  filename ) );

   return OTF_RETURN_OK;
}

int
Handle_DefScl( std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
	       uint32_t streamid, uint32_t deftoken, uint32_t sclfile, uint32_t sclline )
{
   p_vecLocDefRecs->push_back( new DefBufEntry_DefScl_struct(
				  streamid % 65536,
				  deftoken,
				  sclfile,
				  sclline ) );

   return OTF_RETURN_OK;
}

int Handle_DefFunctionGroup( std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
			     uint32_t streamid, uint32_t deftoken, const char* name )
{
   p_vecLocDefRecs->push_back( new DefBufEntry_DefFunctionGroup_struct(
				  streamid % 65536,
				  deftoken, name ) );

   return OTF_RETURN_OK;
}

int
Handle_DefFunction( std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
		    uint32_t streamid, uint32_t deftoken, const char* name,
		    uint32_t group, uint32_t scltoken )
{
   p_vecLocDefRecs->push_back( new DefBufEntry_DefFunction_struct(
				  streamid % 65536,
				  deftoken,
				  name,
				  group,
				  scltoken ) );

   return OTF_RETURN_OK;
}

int
Handle_DefCollectiveOperation( std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
			       uint32_t streamid, uint32_t collOp, const char* name,
			       uint32_t type )
{
   p_vecLocDefRecs->push_back( new DefBufEntry_DefCollectiveOperation_struct(
				  streamid % 65536,
				  collOp,
				  name,
				  type ) );

   return OTF_RETURN_OK;
}

int
Handle_DefCounterGroup( std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
			uint32_t streamid, uint32_t deftoken, const char* name )
{
   p_vecLocDefRecs->push_back( new DefBufEntry_DefCounterGroup_struct(
				  streamid % 65536,
				  deftoken,
				  name ) );
   
   return OTF_RETURN_OK;
}

int
Handle_DefCounter( std::vector<DefBufEntry_Base_struct*>* p_vecLocDefRecs,
		   uint32_t streamid, uint32_t deftoken, const char* name,
		   uint32_t properties, uint32_t countergroup, const char* unit )
{
   p_vecLocDefRecs->push_back( new DefBufEntry_DefCounter_struct(
				  streamid % 65536,
				  deftoken,
				  name,
				  properties,
				  countergroup,
				  unit ) );

   return OTF_RETURN_OK;
}

// event record handler
//

int
Handle_Enter( EventFirstHandlerArg_struct* fharg,
	      uint64_t time, uint32_t statetoken, uint32_t cpuid,
	      uint32_t scltoken )
{
   uint32_t mcpuid = cpuid % 65536;

   TokenFactory_DefFunction * p_tkfac_deffunction =
      static_cast<TokenFactory_DefFunction*>(theTokenFactory[TKFAC__DEF_FUNCTION]);

   TokenFactory_DefScl * p_tkfac_defscl = 
      static_cast<TokenFactory_DefScl*>(theTokenFactory[TKFAC__DEF_SCL]);

   uint32_t global_statetoken =
      p_tkfac_deffunction->translateLocalToken( mcpuid, statetoken );
   assert( global_statetoken != 0 );
   
   uint32_t global_scltoken = scltoken;

   if( scltoken != 0 )
   {
      global_scltoken =
	 p_tkfac_defscl->translateLocalToken( mcpuid, scltoken );
      assert( global_scltoken != 0 );
   }

   time = theUnifyer->correctTime( fharg->uid, time ) -
      fharg->minstime;

   int wrrc = OTF_WStream_writeEnter( fharg->wstream,
				      time,
				      global_statetoken,
				      cpuid,
				      global_scltoken );
   return wrrc == 1 ? OTF_RETURN_OK : OTF_RETURN_ABORT;
}
		  
int
Handle_Leave( EventFirstHandlerArg_struct* fharg,
	      uint64_t time, uint32_t statetoken, uint32_t cpuid,
	      uint32_t scltoken )
{
   uint32_t mcpuid = cpuid % 65536;

   TokenFactory_DefFunction * p_tkfac_deffunction =
      static_cast<TokenFactory_DefFunction*>(theTokenFactory[TKFAC__DEF_FUNCTION]);

   TokenFactory_DefScl * p_tkfac_defscl = 
      static_cast<TokenFactory_DefScl*>(theTokenFactory[TKFAC__DEF_SCL]);

   uint32_t global_statetoken = statetoken;

   if( statetoken != 0 )
   {
      global_statetoken =
	 p_tkfac_deffunction->translateLocalToken( mcpuid, statetoken );
      assert( global_statetoken != 0 );
   }
   
   uint32_t global_scltoken = scltoken;

   if( scltoken != 0 )
   {
      global_scltoken =
	 p_tkfac_defscl->translateLocalToken( mcpuid, scltoken );
      assert( global_scltoken != 0 );
   }

   time = theUnifyer->correctTime( fharg->uid, time ) -
      fharg->minstime;

   int wrrc = OTF_WStream_writeLeave( fharg->wstream,
				      time,
				      global_statetoken,
				      cpuid,
				      global_scltoken );
   return wrrc == 1 ? OTF_RETURN_OK : OTF_RETURN_ABORT;
}

int
Handle_SendMsg( EventFirstHandlerArg_struct* fharg,
		uint64_t time, uint32_t sender, uint32_t receiver,
		uint32_t communicator, uint32_t msgtag, 
		uint32_t msglength, uint32_t scltoken )
{
   uint32_t msender = sender % 65536;

   TokenFactory_DefProcessGroup * p_tkfac_defprocessgroup =
      static_cast<TokenFactory_DefProcessGroup*>(theTokenFactory[TKFAC__DEF_PROCESS_GROUP]);

   TokenFactory_DefScl * p_tkfac_defscl = 
      static_cast<TokenFactory_DefScl*>(theTokenFactory[TKFAC__DEF_SCL]);

   uint32_t global_communicator = 
      p_tkfac_defprocessgroup->translateLocalToken( msender, communicator );
   assert( global_communicator != 0 );

   uint32_t global_scltoken = scltoken;

   if( scltoken != 0 )
   {
      global_scltoken =
	 p_tkfac_defscl->translateLocalToken( msender, scltoken );
      assert( global_scltoken != 0 );
   }

   time = theUnifyer->correctTime( fharg->uid, time ) -
      fharg->minstime;

   int wrrc = OTF_WStream_writeSendMsg( fharg->wstream,
					time, sender, receiver,
					global_communicator, msgtag,
					msglength, global_scltoken );
   return wrrc == 1 ? OTF_RETURN_OK : OTF_RETURN_ABORT;
}

int
Handle_RecvMsg( EventFirstHandlerArg_struct* fharg,
		uint64_t time, uint32_t receiver, uint32_t sender,
		uint32_t communicator, uint32_t msgtag,
		uint32_t msglength, uint32_t scltoken )
{
   uint32_t mreceiver = receiver % 65536;

   TokenFactory_DefProcessGroup * p_tkfac_defprocessgroup =
      static_cast<TokenFactory_DefProcessGroup*>(theTokenFactory[TKFAC__DEF_PROCESS_GROUP]);

   TokenFactory_DefScl * p_tkfac_defscl = 
      static_cast<TokenFactory_DefScl*>(theTokenFactory[TKFAC__DEF_SCL]);

   uint32_t global_communicator = 
      p_tkfac_defprocessgroup->translateLocalToken( mreceiver, communicator );
   assert( global_communicator != 0 );

   uint32_t global_scltoken = scltoken;

   if( scltoken != 0 )
   {
      global_scltoken =
	 p_tkfac_defscl->translateLocalToken( mreceiver, scltoken );
      assert( global_scltoken != 0 );
   }

   time = theUnifyer->correctTime( fharg->uid, time ) -
      fharg->minstime;

   int wrrc = OTF_WStream_writeRecvMsg( fharg->wstream,
					time, receiver, sender,
					global_communicator, msgtag,
					msglength, global_scltoken );
   return wrrc == 1 ? OTF_RETURN_OK : OTF_RETURN_ABORT;
}

int
Handle_CollectiveOperation( EventFirstHandlerArg_struct* fharg,
			    uint64_t time, uint32_t process,
			    uint32_t functionToken, uint32_t communicator,
			    uint32_t rootprocess, uint32_t sent,
			    uint32_t received, uint64_t duration,
			    uint32_t scltoken )
{
   uint32_t mprocess = process % 65536;

   TokenFactory_DefCollectiveOperation * p_tkfac_defcollop =
      static_cast<TokenFactory_DefCollectiveOperation*>(theTokenFactory[TKFAC__DEF_COLL_OP]);

   TokenFactory_DefProcessGroup * p_tkfac_defprocessgroup =
      static_cast<TokenFactory_DefProcessGroup*>(theTokenFactory[TKFAC__DEF_PROCESS_GROUP]);

   TokenFactory_DefScl * p_tkfac_defscl = 
      static_cast<TokenFactory_DefScl*>(theTokenFactory[TKFAC__DEF_SCL]);

   uint32_t global_functionToken =
      p_tkfac_defcollop->translateLocalToken( mprocess, functionToken );
   assert( global_functionToken != 0 );

   uint32_t global_communicator =
      p_tkfac_defprocessgroup->translateLocalToken( mprocess, communicator );
   assert( global_communicator != 0 );

   uint32_t global_scltoken = scltoken;
   
   if( scltoken != 0 )
   {
      global_scltoken =
	 p_tkfac_defscl->translateLocalToken( mprocess, scltoken );
      assert( global_scltoken != 0 );
   }

   time = theUnifyer->correctTime( fharg->uid, time ) -
      fharg->minstime;

   int wrrc = OTF_WStream_writeCollectiveOperation( fharg->wstream,
						    time, process,
						    global_functionToken,
						    global_communicator,
						    rootprocess, sent,
						    received, duration,
						    global_scltoken );
   return wrrc == 1 ? OTF_RETURN_OK : OTF_RETURN_ABORT;
}

int
Handle_Counter( EventFirstHandlerArg_struct* fharg,
		uint64_t time, uint32_t process, uint32_t counter_token,
		uint64_t value )
{
   uint32_t mprocess = process % 65536;

   TokenFactory_DefCounter * p_tkfac_defcounter = 
      static_cast<TokenFactory_DefCounter*>(theTokenFactory[TKFAC__DEF_COUNTER]);

   uint32_t global_counter_token =
      p_tkfac_defcounter->translateLocalToken( mprocess, counter_token );
   assert( global_counter_token != 0 );

   time = theUnifyer->correctTime( fharg->uid, time ) -
      fharg->minstime;

   int wrrc = OTF_WStream_writeCounter( fharg->wstream,
					time, process, global_counter_token,
					value );
   return wrrc == 1 ? OTF_RETURN_OK : OTF_RETURN_ABORT;
}

int
Handle_EventComment( EventFirstHandlerArg_struct* fharg,
		     uint64_t time, uint32_t process, const char* comment )
{
   time = theUnifyer->correctTime( fharg->uid, time ) -
      fharg->minstime;

   int wrrc = OTF_WStream_writeEventComment( fharg->wstream,
					     time, process, comment );
   return wrrc == 1 ? OTF_RETURN_OK : OTF_RETURN_ABORT;
}

