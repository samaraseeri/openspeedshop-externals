/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2007, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich GmbH, Federal
 * Republic of Germany
 *
 * See the file COPYRIGHT in the package base directory for details
 **/

#ifndef _VT_UNIFY_DEF_H_
#define _VT_UNIFY_DEF_H_

#include <assert.h>
#include "vt_inttypes.h"
#include <stdlib.h>
#include <string.h>

#include <string>
#include <vector>

// definition buffer entry types
//
typedef enum { DEF_BUF_ENTRY_TYPE__DefinitionComment,
	       DEF_BUF_ENTRY_TYPE__DefCreator,
               DEF_BUF_ENTRY_TYPE__DefTimerResolution,
	       DEF_BUF_ENTRY_TYPE__DefProcess,
	       DEF_BUF_ENTRY_TYPE__DefProcessGroup,
	       DEF_BUF_ENTRY_TYPE__DefSclFile,
	       DEF_BUF_ENTRY_TYPE__DefScl,
	       DEF_BUF_ENTRY_TYPE__DefFunctionGroup,
	       DEF_BUF_ENTRY_TYPE__DefFunction,
	       DEF_BUF_ENTRY_TYPE__DefCollectiveOperation,
	       DEF_BUF_ENTRY_TYPE__DefCounterGroup,
	       DEF_BUF_ENTRY_TYPE__DefCounter } DefEntryTypeT;

//
// DefBufEntry_Base_struct
//
struct DefBufEntry_Base_struct
{
   DefBufEntry_Base_struct() {}
   DefBufEntry_Base_struct(DefEntryTypeT _etype)
      : etype(_etype), loccpuid(0), deftoken(0) {}
   virtual ~DefBufEntry_Base_struct() {}

   DefEntryTypeT etype;
   uint32_t      loccpuid;
   uint32_t      deftoken;
};

//
// DefBufEntry_DefinitionComment_struct
//
struct DefBufEntry_DefinitionComment_struct : DefBufEntry_Base_struct
{
   DefBufEntry_DefinitionComment_struct() 
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefinitionComment) {}
   DefBufEntry_DefinitionComment_struct(uint32_t _orderidx,
					const char* _comment)
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefinitionComment),
   orderidx(_orderidx) { comment = strdup(_comment); }
   ~DefBufEntry_DefinitionComment_struct()
      {
	 free( const_cast<char*>(comment) );
      }

   uint32_t     orderidx;
   const char * comment;
};

//
// DefBufEntry_DefCreator_struct
//
struct DefBufEntry_DefCreator_struct : DefBufEntry_Base_struct
{
   DefBufEntry_DefCreator_struct() 
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefCreator) {}
   DefBufEntry_DefCreator_struct(const char* _creator)
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefCreator)
      { creator = strdup(_creator); }
   ~DefBufEntry_DefCreator_struct()
      {
	 free( const_cast<char*>(creator) );
      }

   const char * creator;
};

//
// DefBufEntry_DefTimerResolution_struct
//
struct DefBufEntry_DefTimerResolution_struct : DefBufEntry_Base_struct
{
   DefBufEntry_DefTimerResolution_struct() 
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefTimerResolution) {}
   DefBufEntry_DefTimerResolution_struct(uint64_t _ticksPerSecond)
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefTimerResolution),
   ticksPerSecond(_ticksPerSecond) {}

   uint64_t ticksPerSecond;
};

//
// DefBufEntry_DefProcess_struct
//
struct DefBufEntry_DefProcess_struct : DefBufEntry_Base_struct
{
   DefBufEntry_DefProcess_struct()
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefProcess) {}
   DefBufEntry_DefProcess_struct(uint32_t _deftoken, const char* _name,
				 uint32_t _parent)
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefProcess),
   parent(_parent) { deftoken = _deftoken; name = strdup(_name); }
   ~DefBufEntry_DefProcess_struct()
      {
	 free( const_cast<char*>(name) );
      }

   const char * name;
   uint32_t     parent;
};

//
// DefBufEntry_DefProcessGroup_struct
//
struct DefBufEntry_DefProcessGroup_struct : DefBufEntry_Base_struct
{
   DefBufEntry_DefProcessGroup_struct()
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefProcessGroup) {}
   DefBufEntry_DefProcessGroup_struct(uint32_t _loccpuid,
				      uint32_t _deftoken,
				      const char* _name,
				      uint32_t _n,
				      uint32_t* _array)
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefProcessGroup),
   n(_n), array(0) 
      {
	 loccpuid = _loccpuid;
	 deftoken = _deftoken;
	 name = strdup(_name); 
	 array = (uint32_t*)calloc(_n, sizeof(uint32_t));
	 assert(array);
	 for(uint32_t i = 0; i < _n; i++)
	    array[i] = _array[i];
      }
   DefBufEntry_DefProcessGroup_struct(uint32_t _loccpuid,
				      uint32_t _deftoken,
				      std::string _name,
				      std::vector<uint32_t> _array)
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefProcessGroup),
   n(0), array(0)
      {
	 loccpuid = _loccpuid;
	 deftoken = _deftoken;
	 name = strdup( _name.c_str() );
	 n = _array.size();
	 array = (uint32_t*)calloc(n, sizeof(uint32_t));
	 assert(array);
	 for(uint32_t i = 0; i < n; i++)
	    array[i] = _array[i];
      }
   ~DefBufEntry_DefProcessGroup_struct()
      {
	 free( const_cast<char*>(name) );
	 free( array );
      }

   const char * name;
   uint32_t     n;
   uint32_t   * array;
};

//
// DefBufEntry_DefSclFile_struct
//
struct DefBufEntry_DefSclFile_struct : DefBufEntry_Base_struct
{
   DefBufEntry_DefSclFile_struct()
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefSclFile) {}
   DefBufEntry_DefSclFile_struct(uint32_t _loccpuid, uint32_t _deftoken,
				 const char* _filename)
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefSclFile)
      { loccpuid = _loccpuid; deftoken = _deftoken; filename = strdup(_filename); }
   ~DefBufEntry_DefSclFile_struct()
      {
	 free( const_cast<char*>(filename) );
      }

   const char * filename;
};

//
// DefBufEntry_DefScl_struct
//
struct DefBufEntry_DefScl_struct : DefBufEntry_Base_struct
{
   DefBufEntry_DefScl_struct()
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefScl) {}
   DefBufEntry_DefScl_struct(uint32_t _loccpuid, uint32_t _deftoken,
			     uint32_t _sclfile, uint32_t _sclline)
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefScl),
   sclfile(_sclfile), sclline(_sclline) { loccpuid = _loccpuid; deftoken = _deftoken; }
   ~DefBufEntry_DefScl_struct() {}

   uint32_t sclfile;
   uint32_t sclline;
};

//
// DefBufEntry_DefFunctionGroup_struct
//
struct DefBufEntry_DefFunctionGroup_struct : DefBufEntry_Base_struct
{
   DefBufEntry_DefFunctionGroup_struct()
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefFunctionGroup) {}
   DefBufEntry_DefFunctionGroup_struct(uint32_t _loccpuid,
				       uint32_t _deftoken,
				       const char* _name)
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefFunctionGroup)
      { loccpuid = _loccpuid; deftoken = _deftoken; name = strdup(_name); }
   ~DefBufEntry_DefFunctionGroup_struct()
      {
	 free( const_cast<char*>(name) );
      }

   const char * name;
};

//
// DefBufEntry_DefFunction_struct
//
struct DefBufEntry_DefFunction_struct : DefBufEntry_Base_struct
{
   DefBufEntry_DefFunction_struct()
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefFunction) {}
   DefBufEntry_DefFunction_struct(uint32_t _loccpuid, uint32_t _deftoken,
				  const char* _name, uint32_t _group,
				  uint32_t _scltoken)
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefFunction),
   group(_group), scltoken(_scltoken) { loccpuid = _loccpuid; deftoken = _deftoken; name = strdup(_name); }
   ~DefBufEntry_DefFunction_struct()
      {
	 free( const_cast<char*>(name) );
      }

   const char * name;
   uint32_t     group;
   uint32_t     scltoken;
};

//
// DefBufEntry_DefCollectiveOperation_struct
//
struct DefBufEntry_DefCollectiveOperation_struct : DefBufEntry_Base_struct
{
   DefBufEntry_DefCollectiveOperation_struct()
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefCollectiveOperation) {}
   DefBufEntry_DefCollectiveOperation_struct(uint32_t _loccpuid,
					     uint32_t _collOp,
					     const char* _name,
					     uint32_t _type)
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefCollectiveOperation),
   type(_type) { loccpuid = _loccpuid; deftoken = _collOp; name = strdup(_name); }
   ~DefBufEntry_DefCollectiveOperation_struct()
      {
	 free( const_cast<char*>(name) );
      }

   const char * name;
   uint32_t     type;
};

//
// DefBufEntry_DefCounterGroup_struct
//
struct DefBufEntry_DefCounterGroup_struct : DefBufEntry_Base_struct
{
   DefBufEntry_DefCounterGroup_struct()
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefCounterGroup) {}
   DefBufEntry_DefCounterGroup_struct(uint32_t _loccpuid, 
				      uint32_t _deftoken,
				      const char* _name)
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefCounterGroup)
      { loccpuid = _loccpuid; deftoken = _deftoken; name = strdup(_name); }
   ~DefBufEntry_DefCounterGroup_struct()
      {
	 free( const_cast<char*>(name) );
      }

   const char * name;
};

//
// DefBufEntry_DefCounter_struct
//
struct DefBufEntry_DefCounter_struct : DefBufEntry_Base_struct
{
   DefBufEntry_DefCounter_struct()
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefCounter) {}
   DefBufEntry_DefCounter_struct(uint32_t _loccpuid, uint32_t _deftoken,
				 const char* _name, uint32_t _properties,
				 uint32_t _countergroup, const char* _unit)
      : DefBufEntry_Base_struct(DEF_BUF_ENTRY_TYPE__DefCounter),
   properties(_properties), countergroup(_countergroup)
      { loccpuid = _loccpuid; deftoken = _deftoken; name = strdup(_name); unit = strdup(_unit); }
   ~DefBufEntry_DefCounter_struct()
      {
	 free( const_cast<char*>(name) );
	 free( const_cast<char*>(unit) );
      }

   const char * name;
   uint32_t     properties;
   uint32_t     countergroup;
   const char * unit;
};

#endif // _VT_UNIFY_DEF_H_
