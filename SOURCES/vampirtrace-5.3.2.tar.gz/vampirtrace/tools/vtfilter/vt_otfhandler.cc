/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2007, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich GmbH, Federal
 * Republic of Germany
 *
 * See the file COPYRIGHT in the package base directory for details
 **/

#include "vt_otfhandler.h"
#include "vt_filter.h"
#include <otf.h>
using namespace std;


int handleDefTimerResolution( void* ud,
	uint32_t /*streamid*/, uint64_t tickspersecond ) {


	((HandlerArgument*)ud)->filter.setTimerResolution( tickspersecond );

	
	return OTF_RETURN_OK;
}


int handleDefFunction( void* ud, uint32_t /*streamid*/,
	uint32_t func, const char* name, uint32_t /*group*/, uint32_t /*scltoken*/ ) {


	string escaped;

	for( uint32_t i= 0; i < strlen(name); ++i ) {
	
		if( '*' == name[i] ) {
			escaped.append( 1, '\\' );
		}
		
		escaped.append( 1, name[i] );
	}


	((HandlerArgument*)ud)->filter.addFunction( func, escaped );
	

	return OTF_RETURN_OK;
}


int handleEnter( void* ud, uint64_t time, uint32_t function,
	uint32_t process, uint32_t /*source*/ ) {


	((HandlerArgument*)ud)->filter.addEnter( function, process, time );


	return OTF_RETURN_OK;
}


int handleLeave( void* ud, uint64_t time, uint32_t function,
	uint32_t process, uint32_t /*source*/ ) {
	
	
	((HandlerArgument*)ud)->filter.addLeave( process, time );

	
	return OTF_RETURN_OK;
}


int handleCollectiveOperation( void* ud, uint64_t /*time*/,
    uint32_t /*process*/, uint32_t /*functionToken*/, uint32_t /*communicator*/, 
    uint32_t /*rootprocess*/, uint32_t /*sent*/, uint32_t /*received*/, 
    uint64_t /*duration*/, uint32_t /*scltoken*/ ) {


	((HandlerArgument*)ud)->filter.incrCollectiveCount();


	return OTF_RETURN_OK;
}


int handleRecvMsg( void* ud, uint64_t /*time*/,
	uint32_t /*receiver*/, uint32_t /*sender*/, uint32_t /*communicator*/, 
	uint32_t /*msgtype*/, uint32_t /*msglength*/,
	uint32_t /*scltoken*/ ) {


	((HandlerArgument*)ud)->filter.incrMessageCount();


	return OTF_RETURN_OK;
}


int handleSendMsg( void* ud, uint64_t /*time*/,
	uint32_t /*sender*/, uint32_t /*receiver*/, uint32_t /*communicator*/, 
	uint32_t /*msgtype*/, uint32_t /*msglength*/, uint32_t /*scltoken*/ ) {


	((HandlerArgument*)ud)->filter.incrMessageCount();


	return OTF_RETURN_OK;
}
