/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2007, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich GmbH, Federal
 * Republic of Germany
 *
 * See the file COPYRIGHT in the package base directory for details
 **/

#include "vt_filter.h"
#include "vt_otfhandler.h"
#include <otf.h>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <assert.h>
#include <string.h>
#include <fnmatch.h>
using namespace std;

#if HAVE_CONFIG_H
#  include <config.h>
#endif

#if SIZEOF_LONG == 4
#  define ATOL8 atoll
#else
#  define ATOL8 atol
#endif

#define HELPTEXT "" \
"                                                                          \n" \
" vtfilter - filter generator for VampirTrace.                             \n" \
"                                                                          \n" \
" Syntax: vtfilter [options] <input tracefile>                             \n" \
"                                                                          \n" \
"   options:                                                               \n" \
"     -h, --help            show this help message                         \n" \
"     -o <file>             output filterfile name                         \n" \
"                                                                          \n" \
"     --reduce <n>          Reduce the trace size to <n> percent of the    \n" \
"                           original size. The program relies on the fact  \n" \
"                           that the major part of the trace are function  \n" \
"                           calls. The approximation of size will get      \n" \
"                           worse with a rising percentage of              \n" \
"                           communication and other non function calling-  \n" \
"                           or performancecounter-records.                 \n" \
"     --limit <n>           Limit the number of accepted functioncalls for \n" \
"                           filtered functions to <n>. Standard is 0.      \n" \
"     --exclude <f>,<f>,... Exclude certain symbols from filtering.        \n" \
"                           A Symbol may contain wildcards.                \n" \
"     --include <f>,<f>,... Force to include certain symbols into the      \n" \
"                           filter. A Symbol may contain wildcards.        \n" \
"     --include-children    Automatically include children of included     \n" \
"                           functions as well into the filter.             \n" \
"                                                                          \n" \
"     --plot                Prints out the desired and the expected        \n" \
"                           percentage of filesize.                        \n" \
"                                                                          \n" \
"   environment variables:                                                 \n" \
"     TRACEFILTER_EXCLUDEFILE  Specifies a file containing a list of       \n" \
"                              symbols not to be filtered. The list of     \n" \
"                              members can be seperated by space, comma,   \n" \
"                              tab, newline and may contain wildcards.     \n" \
"     TRACEFILTER_INCLUDEFILE  Specifies a file containing a list of       \n" \
"                              symbols  to be filtered.                    \n" \
"                                                                          \n" \



static void dump ( const vector<Function>& functions, const set<uint32_t>& excluded,
	uint64_t timerresolution, uint64_t limit, ostream& out );

static void readTokensFromFile( const char* filename, vector<string>& vec );



int main( int argc, char** argv ) {


	OTF_FileManager* manager;
	OTF_Reader* reader;
	OTF_HandlerArray* handlers;
	ofstream of;

	char* infile= NULL;
	char* outfile= NULL;
	
	HandlerArgument fha;

	vector<string> excludeSymbols;
	vector<string> includeSymbols;

	float expected_reducepercentage= 100.0f;
	float desired_reducepercentage= 100.0f;

	uint64_t limit= 0;

	bool includechildren= false;
	bool plot= false;

	
	if ( 1 >= argc ) {

			fprintf( stdout, HELPTEXT );
			return 0;
	}

	
	for ( int i = 1; i < argc; i++ ) {


		if ( 0 == strcmp( "--help", argv[i] ) ||
				0 == strcmp( "-h", argv[i] ) ) {

			fprintf( stdout, HELPTEXT );
			return 0;

		}else if ( 0 == strcmp( "-o", argv[i] ) && ( i+1 < argc ) ) {

			++i;
			outfile= argv[i];
			
		} else if ( 0 == strcmp( "--reduce", argv[i] ) && ( i+1 < argc ) ) {

			++i;

			desired_reducepercentage= (float) atof( argv[i] );

			expected_reducepercentage= desired_reducepercentage;

		} else if ( 0 == strcmp( "--limit", argv[i] ) && ( i+1 < argc ) ) {

			++i;

			limit= (uint64_t) ATOL8( argv[i] );

		} else if ( 0 == strcmp( "--exclude", argv[i] ) && ( i+1 < argc ) ) {

			++i;
			
			char* token= strtok( argv[i], "," );
			while( NULL != token ) {

				excludeSymbols.push_back( token );

				token= strtok( NULL, "," );
			}
			
		} else if ( 0 == strcmp( "--include", argv[i] ) && ( i+1 < argc ) ) {

			++i;
			
			char* token= strtok( argv[i], "," );
			while( NULL != token ) {

				includeSymbols.push_back( token );

				token= strtok( NULL, "," );
			}
			
		} else if ( 0 == strcmp( "--include-children", argv[i] ) ) {

			includechildren= true;

		} else if ( 0 == strcmp( "--plot", argv[i] ) ) {

			plot= true;

		} else {

			if ( '-' != argv[i][0] ) {

				infile= argv[i];

			} else{

				fprintf( stderr, "ERROR: Unknown option: '%s'\n", argv[i] );
				exit(1);
			}
		}
	}


	if( NULL == infile ) {

		fprintf( stderr, " no input file has been specified.\n" );

		exit(1);
	}


	if( desired_reducepercentage < 0.0f || desired_reducepercentage >= 100.0f ) {

		fprintf( stderr, " wrong reduction percentage: %.2f. aborting\n", desired_reducepercentage );

		exit(1);
	}


	/* read the exclude symbols file, if there is one */
	char* excludefilename= getenv( "TRACEFILTER_EXCLUDEFILE" );
	char* includefilename= getenv( "TRACEFILTER_INCLUDEFILE" );

	if( NULL != excludefilename ) {
		readTokensFromFile( excludefilename, excludeSymbols );
		//free( excludefilename );
	}
	if( NULL != includefilename ) {
		readTokensFromFile( includefilename, includeSymbols );
		//free( includefilename );
	}


	/* init otf */
	manager= OTF_FileManager_open( 100 );
	assert( NULL != manager );
	reader = OTF_Reader_open( infile, manager );
	assert( NULL != reader );
	handlers = OTF_HandlerArray_open();
	assert( NULL != handlers );


	OTF_HandlerArray_setHandler( handlers,
		(OTF_FunctionPointer*) handleDefTimerResolution, OTF_DEFTIMERRESOLUTION_RECORD );
	OTF_HandlerArray_setFirstHandlerArg( handlers, 
        &fha, OTF_DEFTIMERRESOLUTION_RECORD );

	OTF_HandlerArray_setHandler( handlers,
		(OTF_FunctionPointer*) handleDefFunction, OTF_DEFFUNCTION_RECORD );
	OTF_HandlerArray_setFirstHandlerArg( handlers, 
        &fha, OTF_DEFFUNCTION_RECORD );

	OTF_HandlerArray_setHandler( handlers,
		(OTF_FunctionPointer*) handleEnter, OTF_ENTER_RECORD );
	OTF_HandlerArray_setFirstHandlerArg( handlers, 
        &fha, OTF_ENTER_RECORD );

	OTF_HandlerArray_setHandler( handlers,
		(OTF_FunctionPointer*) handleLeave, OTF_LEAVE_RECORD );
	OTF_HandlerArray_setFirstHandlerArg( handlers, 
        &fha, OTF_LEAVE_RECORD );

	OTF_HandlerArray_setHandler( handlers, 
		(OTF_FunctionPointer*) handleCollectiveOperation,
		OTF_COLLOP_RECORD );
	OTF_HandlerArray_setFirstHandlerArg( handlers, 
        &fha, OTF_COLLOP_RECORD );

	OTF_HandlerArray_setHandler( handlers, 
		(OTF_FunctionPointer*) handleRecvMsg,
		OTF_RECEIVE_RECORD );
	OTF_HandlerArray_setFirstHandlerArg( handlers, 
        &fha, OTF_RECEIVE_RECORD );

	OTF_HandlerArray_setHandler( handlers, 
		(OTF_FunctionPointer*) handleSendMsg,
		OTF_SEND_RECORD );
	OTF_HandlerArray_setFirstHandlerArg( handlers, 
        &fha, OTF_SEND_RECORD );


	OTF_Reader_readDefinitions( reader, handlers );
	OTF_Reader_readEvents( reader, handlers );


	OTF_HandlerArray_close( handlers );
	OTF_Reader_close( reader );
	OTF_FileManager_close( manager );


	/* do some calculations after adding all functions */
	fha.filter.postProcessing();

	/* get the excluded and included function tokens from their names */
	set<uint32_t> excludes;
	set<uint32_t> includes;
	vector<string>::const_iterator itsymbols; /* iterator ex/include symbols */
	vector<Function> functions= fha.filter.getFunctions();
	vector<Function>::const_iterator itfuncs;
	bool excludedsomething= false;
	
	
	for( itfuncs= functions.begin(); itfuncs != functions.end(); ++itfuncs ) {

		excludedsomething= false;
	
		for( itsymbols= excludeSymbols.begin(); itsymbols != excludeSymbols.end(); ++itsymbols ) {

			if( 0 == fnmatch( itsymbols->c_str(), itfuncs->name.c_str(), FNM_NOESCAPE ) ) {
				excludes.insert( itfuncs->id );
				excludedsomething= true;
				break;
			}
		}

		/* you cannot include something you already excluded */
		if( true == excludedsomething ) continue;
		

		
		for( itsymbols= includeSymbols.begin(); itsymbols != includeSymbols.end(); ++itsymbols ) {

			if( 0 == fnmatch( itsymbols->c_str(), itfuncs->name.c_str(), FNM_NOESCAPE ) ) {
				includes.insert( itfuncs->id );
				break;
			}
		}
	}


	/* reduce functions */
	set<uint32_t> killed= fha.filter.reduceTo( &expected_reducepercentage, excludes,
		includes, includechildren, limit );

	/* print out some information for gnuplot */
	if( true == plot ) {
		fprintf( stderr, "desired %.2f%% expected %.2f%%\n", desired_reducepercentage,
			expected_reducepercentage );
	}

	/* print the filter + report to a file or cout if no file has been specified */
	if( NULL != outfile ) {
		of.open( outfile );
		
		if( of.is_open() ) {
		
			dump( functions, killed, fha.filter.getTimerResolution(), limit, of );
			
		} else {
		
			cerr << "ERROR: could not open outputfile \"" << outfile << "\"" << endl;

		}

		of.close();

	} else {
	
		dump( functions, killed, fha.filter.getTimerResolution(), limit, cout );
			
	}


	return 0;
}


void dump ( const vector<Function>& functions, const set<uint32_t>& excluded, uint64_t timerresolution, uint64_t limit, ostream& out ) {


	vector<string> excludedNames;

	out << "#### all functions sorted by stackdepth, subfunction count and invocationcount ###" << endl;
	out << "# del? - token - maxstackdepth - subfunccount - invocationcount - avg duration incl - avg duration excl - symbolname - subfunctionlist" << endl;


	for( vector<Function>::const_iterator it= functions.begin(); it != functions.end(); ++it ) {

		out << "# ";
		
		/* add the excluded function to the names list */
		if( excluded.find( it->id ) != excluded.end() ) {
			excludedNames.push_back( it->name );
			out << "x";
		} else {
			out << " ";
		}
		
		out.width( 5 );
		out << it->id  << " ";
		out.width( 3 );
		out << it->depth << " ";
		out.width( 3 );
		out << it->subFuncs.size() << " ";
		out.width( 9 );
		out << it->invocations << " ";
		out.width( 18 ); out.precision( 8 );
		if( 0 != it->invocations ) out << fixed << ((double)it->accDurationIncl / (double)it->invocations) / (double)timerresolution << " ";
		else out << "-" << " ";
		out.width( 18 ); out.precision( 8 );
		if( 0 != it->invocations ) out << fixed << ((double)it->accDurationExcl / (double)it->invocations) / (double)timerresolution << "   ";
		else out << "-" << "   ";
		out.width( 0 );
		out << it->name << "  -->  { ";
			
		for( set<uint32_t>::const_iterator it2= it->subFuncs.begin(); it2 != it->subFuncs.end(); ++it2 ) {

			out << *it2 << ", ";
		}

		out << " }" << endl;
	}


	out << endl << endl;

	out << "#### Filter ###" << endl;


	vector<string>::const_iterator its;
	for( its= excludedNames.begin(); its != excludedNames.end(); ++its ) {

		out << *its << " -- " << limit << endl;
	}
}


#define BUFSIZE 4096
void readTokensFromFile( const char* filename, vector<string>& vec ) {


	FILE* file;


	if( NULL != filename && NULL != ( file= fopen( filename, "r" ) ) ) {

		uint64_t readsize= 0;
		uint64_t lastreadsize= 0;
		uint64_t bufc= BUFSIZE;
		char *bufv= (char*) malloc( sizeof(char) * bufc );
		char *bufv2= bufv;
		

		readsize= lastreadsize= fread( bufv2, sizeof( char ), BUFSIZE, file );
		bufv2+= lastreadsize;
		while( lastreadsize > 0 ) {

			if( readsize+BUFSIZE > bufc ) {
				bufc+= BUFSIZE;
				bufv= (char*) realloc( bufv, sizeof(char)* bufc);
			}

			lastreadsize= fread( bufv2, sizeof( char ), BUFSIZE, file );
			bufv2+= lastreadsize;
			readsize+= lastreadsize;
		}
		fclose( file );
		

		char* token= strtok( bufv, " ,\n\t" );
		while( NULL != token ) {

			vec.push_back( token );

			token= strtok( NULL, ",\n\t " );
		}

		free( bufv );
	}

}
#undef BUFSIZE
