/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2007, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich GmbH, Federal
 * Republic of Germany
 *
 * See the file COPYRIGHT in the package base directory for details
 **/

#if HAVE_CONFIG_H
#  include <config.h>
#endif

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "vt_inttypes.h"

#include "compwrap.h"

static bool ReadEnvironmentVars();
static bool ParseCommandLine( int argc, char ** argv );

#ifdef WRAP_LANG_CC
#define WRAP_LANG_SUFFIX "cc"
static const std::string ExeName = "vtcc";
#elif defined(WRAP_LANG_CXX)
#define WRAP_LANG_SUFFIX "cxx"
static const std::string ExeName = "vtcxx";
#elif defined(WRAP_LANG_F77)
#define WRAP_LANG_SUFFIX "f77"
static const std::string ExeName = "vtf77";
#elif defined(WRAP_LANG_F90)
#define WRAP_LANG_SUFFIX "f90"
static const std::string ExeName = "vtf90";
#else
#define WRAP_LANG_SUFFIX "unknown"
static const std::string ExeName = "";
#error Macro WRAP_LANG_* not defined or invalid
#endif

Wrapper * theWrapper;   // instance of class Wrapper

int
main( int argc, char ** argv )
{
   int rc;

   // create instance of wrapper (initialize)
   theWrapper = new Wrapper();
   assert( theWrapper );

   // read environment variables
   if( !ReadEnvironmentVars() )
      return 1;

   // parse command line
   if( !ParseCommandLine( argc, argv ) )
      return 1;

   // start compiling/linking
   rc = theWrapper->run();

   delete theWrapper;
   return rc;
}

static bool
ReadEnvironmentVars()
{
   char * env;

   // read environment var. for compiler command
   // (VT_<CC|CXX|F77|F90>)
   //
#ifdef WRAP_LANG_CC
   env = getenv( "VT_CC" );
#elif defined(WRAP_LANG_CXX)
   env = getenv( "VT_CXX" );
#elif defined(WRAP_LANG_F77)
   env = getenv( "VT_F77" );
#elif defined(WRAP_LANG_F90)
   env = getenv( "VT_F90" );
#endif
   if( env )
      theWrapper->comp_setCmd( env );

   // read environment var. for instrumentation type
   // (VT_INST)
   //
   env = getenv( "VT_INST" );
   if( env )
   {
      bool error = false;
      std::string senv = env;
      
      if( senv.compare("gnu") == 0 )
	 error = !theWrapper->setInstType( INST_TYPE_GNU );
      else if( senv.compare("intel9") == 0 )
	 error = !theWrapper->setInstType( INST_TYPE_INTEL9 );
      else if( senv.compare("intel10") == 0 )
	 error = !theWrapper->setInstType( INST_TYPE_INTEL10 );
      else if( senv.compare("pgi") == 0 )
	 error = !theWrapper->setInstType( INST_TYPE_PGI );
      else if( senv.compare("phat") == 0 )
	 error = !theWrapper->setInstType( INST_TYPE_PHAT );
      else if( senv.compare("xl") == 0 )
	 error = !theWrapper->setInstType( INST_TYPE_XL );
      else if( senv.compare("ftrace") == 0 )
	 error = !theWrapper->setInstType( INST_TYPE_FTRACE );
      else if( senv.compare("manual") == 0 )
	 error = !theWrapper->setInstType( INST_TYPE_MANUAL );
      else if( senv.compare("pomp") == 0 )
	 error = !theWrapper->setInstType( INST_TYPE_POMP );
      else if( senv.compare("dyninst") == 0 )
	 error = !theWrapper->setInstType( INST_TYPE_DYNINST );
      else
      {
	 std::cerr << ExeName << ": error: VT_INST: "
		   << "unknown instrumentation type '"
		   << senv << "'" << std::endl;
	 return false;
      }

      if( error )
      {
	 std::cerr << ExeName << ": error: VT_INST: "
		   << "instrumentation type '" << senv << "' "
		   << "not supported" << std::endl;
	 return false;
      }
   }

   return true;
}

static bool
ParseCommandLine( int argc, char ** argv )
{
   bool addlibs = false;
   int i;
   std::string arg;

   for( i = 1; i < argc; i++ )
   {
      arg = argv[i];

      //
      // -vt:showme
      //
      if( arg.compare("-vt:showme") == 0 )
      {
	 theWrapper->setShowme( true );
      }
      //
      // -vt:showme_compile
      //
      else if( arg.compare("-vt:showme_compile") == 0 )
      {
	 theWrapper->setShowmeCompile( true );
      }
      //
      // -vt:showme_link
      //
      else if( arg.compare("-vt:showme_link") == 0 )
      {
	 theWrapper->setShowmeLink( true );
      }
   }

   for( i = 1; i < argc; i++ )
   {
      arg = argv[i];

      //
      // -vt:help 
      //
      if( arg.compare("-vt:help") == 0 )
      {
	 theWrapper->showUsageText();
	 exit(0);
      }
      //
      // -vt:verbose
      //
      else if( arg.compare("-vt:verbose") == 0 )
      {
	 theWrapper->setBeVerbose( true );
      }
      //
      // -vt:info
      //
      else if( arg.compare("-vt:info") == 0 )
      {
	 theWrapper->setShowmeInfo( true );
      }
      //
      // -vt:<cc|cxx|f77|f90> <cmd>
      //
      else if( arg.compare("-vt:"WRAP_LANG_SUFFIX) == 0 )
      {
	 if( i == argc - 1 )
	 {
	    std::cerr << ExeName << ": <cmd> expected -- -vt:"WRAP_LANG_SUFFIX
		      << std::endl;
	    return false;
	 }
	 
	 theWrapper->comp_setCmd( argv[++i] );
      }
      //
      // -vt:inst <type>
      //
      else if( arg.compare("-vt:inst") == 0 )
      {
	 if( i == argc - 1 )
	 {
	    std::cerr << ExeName << ": <type> expected -- -vt:inst"
		      << std::endl;
	    return false;
	 }

	 bool error = false;

	 arg = argv[++i];

	 if( arg.compare("gnu") == 0 )
	    error = !theWrapper->setInstType( INST_TYPE_GNU );
	 else if( arg.compare("intel9") == 0 )
	    error = !theWrapper->setInstType( INST_TYPE_INTEL9 );
	 else if( arg.compare("intel10") == 0 )
	    error = !theWrapper->setInstType( INST_TYPE_INTEL10 );
	 else if( arg.compare("pgi") == 0 )
	    error = !theWrapper->setInstType( INST_TYPE_PGI );
	 else if( arg.compare("phat") == 0 )
	    error = !theWrapper->setInstType( INST_TYPE_PHAT );
	 else if( arg.compare("xl") == 0 )
	    error = !theWrapper->setInstType( INST_TYPE_XL );
	 else if( arg.compare("ftrace") == 0 )
	    error = !theWrapper->setInstType( INST_TYPE_FTRACE );
	 else if( arg.compare("manual") == 0 )
	    error = !theWrapper->setInstType( INST_TYPE_MANUAL );
	 else if( arg.compare("pomp") == 0 )
	    error = !theWrapper->setInstType( INST_TYPE_POMP );
	 else if( arg.compare("dyninst") == 0 )
	    error = !theWrapper->setInstType( INST_TYPE_DYNINST );
	 else
	 {
	    std::cerr << ExeName << ": unknown instrumentation type '"
		      << arg << "'" << std::endl;
	    return false;
	 }

	 if( error )
	 {
	    std::cerr << ExeName << ": instrumentation type '"
		      << arg << "' not supported" << std::endl;
	    return false;
	 }
      }
      //
      // -vt:opari <args>
      //
      else if( arg.compare("-vt:opari") == 0 )
      {
	 if( i == argc - 1 )
	 {
	    std::cerr << ExeName << ": <args> expected -- -vt:opari"
		      << std::endl;
	    return false;
	 }

	 char * args = strdup( argv[++i] );
	 char * token = strtok( args, " " );

	 do
	 {
	    if( strcmp( token, "-table" ) == 0 )
	    {
	       token = strtok( 0, " " );
	       if( !token )
	       {
		  std::cerr << ExeName << ": <tabfile> expected -- -table"
			    << std::endl;
		  free( args );
		  return false;
	       }
	       
	       theWrapper->opari_setTabFile( token );
	    }
	    else
	    {
	       theWrapper->opari_addArg( token );
	    }
	 } while( ( token = strtok( 0, " " ) ) );

	 free( args );
      }
      //
      // -vt:mpi
      //
      else if( arg.compare("-vt:mpi") == 0 )
      {
	 theWrapper->setUsesMPI( true );
      }
      //
      // -vt:omp
      //
      else if( arg.compare("-vt:omp") == 0 )
      {
	 theWrapper->setUsesOMP( true );
      }
      //
      // -vt:hyb
      //
      else if( arg.compare("-vt:hyb") == 0 )
      {
	 theWrapper->setUsesMPI( true );
	 theWrapper->setUsesOMP( true );
      }
      //
      // -vt:showme, -vt:showme_compile, or -vt:showme_link
      // (processed above)
      //
      else if( arg.compare("-vt:showme") == 0 
	       || arg.compare("-vt:showme_compile") == 0
	       || arg.compare("-vt:showme_link") == 0 )
      {
	 // no nothing
      }
      //
      // source file
      //
      else if( ( arg.length() >= 2 
		 && arg.compare( arg.length() - 2, 2, ".c" ) == 0 )
	       || ( arg.length() >= 2
		    && arg.compare( arg.length() - 2, 2, ".C" ) == 0 )
	       || ( arg.length() >= 3
		    && arg.compare( arg.length() - 3, 3, ".cc" ) == 0 )
	       || ( arg.length() >= 3
		    && arg.compare( arg.length() - 3, 3, ".CC" ) == 0 )
	       || ( arg.length() >= 4
		    && arg.compare( arg.length() - 4, 4, ".cpp" ) == 0 )
	       || ( arg.length() >= 4
		    && arg.compare( arg.length() - 4, 4, ".CPP" ) == 0 )
	       || ( arg.length() >= 4
		    && arg.compare( arg.length() - 4, 4, ".cxx" ) == 0 )
	       || ( arg.length() >= 4
		    && arg.compare( arg.length() - 4, 4, ".CXX" ) == 0 )
	       || ( arg.length() >= 2
		    && arg.compare( arg.length() - 2, 2, ".f" ) == 0 )
	       || ( arg.length() >= 2
		    && arg.compare( arg.length() - 2, 2, ".F" ) == 0 )
	       || ( arg.length() >= 4
		    && arg.compare( arg.length() - 4, 4, ".f77" ) == 0 )
	       || ( arg.length() >= 4
		    && arg.compare( arg.length() - 4, 4, ".F77" ) == 0 )
	       || ( arg.length() >= 4
		    && arg.compare( arg.length() - 4, 4, ".f90" ) == 0 )
	       || ( arg.length() >= 4
		    && arg.compare( arg.length() - 4, 4, ".F90" ) == 0 )
	       || ( arg.length() >= 4
		    && arg.compare( arg.length() - 4, 4, ".f95" ) == 0 )
	       || ( arg.length() >= 4
		    && arg.compare( arg.length() - 4, 4, ".F95" ) == 0 ) )
      {
	 if( ( !theWrapper->showmeCompile() && !theWrapper->showmeLink() )
	     && ( theWrapper->usesOMP()
		  || theWrapper->getInstType() == INST_TYPE_POMP ) )
	 {
	    theWrapper->opari_addSrcFile( arg );
	 }
	 else
	 {
	    theWrapper->comp_addArg( arg );
	 }
      }
      //
      // -c
      //
      else if( arg.compare("-c") == 0 )
      {
	 theWrapper->setComponly( true );
	 theWrapper->comp_addArg( arg );
      }
      //
      // pflag
      //
      else if( ( arg.compare(0, 1, "-") == 0
		 && arg.compare( arg.length() - 2, 2, "64" ) == 0 )
	       || arg.compare( "amd64" ) == 0
	       || arg.compare( "amd64e" ) == 0
	       || arg.compare( "k8-64e" ) == 0
	       || arg.compare( 0, 9, "-xarch=v9" ) == 0
	       || ( arg.compare( 0, 7, "-xarch=" ) == 0
		    && arg.compare( arg.length() - 2, 2, "64" ) == 0 )
	       || ( arg.compare( 0, 9, "-xtarget=" ) == 0
		    && arg.compare( arg.length() - 2, 2, "64" ) == 0 )
	       || ( arg.compare( 0, 1, "-" ) == 0
		    && arg.compare( arg.length() - 2, 2, "32" ) == 0 )
	       || arg.compare( "k8-32" ) == 0
	       || arg.compare( 0, 7, "-xarch=" ) == 0
	       || arg.compare( 0, 9, "-xtarget=" ) == 0 )
      {
	 theWrapper->comp_setPFlag( arg );
	 theWrapper->comp_addArg( arg );
      }
      //
      // -l<mpilib>
      //
      else if( arg.compare( 0, 5, "-lmpi" ) == 0
	       || arg.compare( 0, 7, "-lmtmpi" ) == 0
	       || arg.compare( 0, 7, "-lhpmpi" ) == 0
               || arg.compare( 0, 7, "-lscmpi" ) == 0 )
      {
	 theWrapper->setUsesMPI( true );
	 theWrapper->comp_addULib( arg );
	 addlibs = true;
      }
      //
      // openmp flag
      //
      else if( arg.compare( "-openmp" ) == 0
	       || arg.compare( "-Popenmp" ) == 0
	       || arg.compare( "-mp" ) == 0
	       || arg.compare( 0, 4, "-mp=" ) == 0
	       || ( arg.compare( 0, 1, "-" ) == 0
		    && (int)(arg.find( "openmp" )) != -1 )
	       || arg.compare( "-qsmp=omp" ) == 0 )
      {
	 theWrapper->setUsesOMP( true );
	 theWrapper->comp_addArg( arg );
      }
      //
      // -l*
      //
      else if( arg.compare( 0, 2, "-l" ) == 0 )
      {
	 if( addlibs )
	    theWrapper->comp_addULib( arg );
	 else
	    theWrapper->comp_addArg( arg );
      }
      //
      // -vt:*  -> unknown wrapper argument
      //
      else if( arg.compare( 0, 4, "-vt:" ) == 0 )
      {
	 std::cerr << ExeName << ": error: unknown option -- "
		   << arg << std::endl;
	 return false; 
      }
      //
      // unknown argument
      //
      else
      {
	 theWrapper->comp_addArg( arg );
      }
   }

   return true;
}

//////////////////// class Wrapper ////////////////////

// public methods
//

Wrapper::Wrapper()
{
   // initialize wrapper
   initialize();
}

Wrapper::~Wrapper()
{
   // empty
}

void
Wrapper::initialize()
{
   // compiler command
   //
#ifdef WRAP_LANG_CC
   comp_setCmd( DEF_CC );
#elif defined(WRAP_LANG_CXX)
   comp_setCmd( DEF_CXX );
#elif defined(WRAP_LANG_F77)
   comp_setCmd( DEF_F77 );
#elif defined(WRAP_LANG_F90)
   comp_setCmd( DEF_F90 );
#endif 

   // available instrumentation types
   //
#ifdef INST_GNU
   Properties.inst_avail |= INST_TYPE_GNU;
#endif
#ifdef INST_INTEL9
   Properties.inst_avail |= INST_TYPE_INTEL9;
#endif
#ifdef INST_INTEL10
   Properties.inst_avail |= INST_TYPE_INTEL10;
#endif
#ifdef INST_PGI
   Properties.inst_avail |= INST_TYPE_PGI;
#endif
#ifdef INST_PHAT
   Properties.inst_avail |= INST_TYPE_PHAT;
#endif
#ifdef INST_XL
   Properties.inst_avail |= INST_TYPE_XL;
#endif
#ifdef INST_FTRACE
   Properties.inst_avail |= INST_TYPE_FTRACE;
#endif
#ifdef INST_DYNINST
   Properties.inst_avail |= INST_TYPE_DYNINST;
#endif

   // instrumentation type
   //
#ifdef DEFAULT_COMPINST
   if( std::string(DEFAULT_COMPINST).compare( "gnu" ) == 0 )
      assert( setInstType( INST_TYPE_GNU ) );
   else if( std::string(DEFAULT_COMPINST).compare( "intel9" ) == 0 )
      assert( setInstType( INST_TYPE_INTEL9 ) );
   else if( std::string(DEFAULT_COMPINST).compare( "intel10" ) == 0 )
      assert( setInstType( INST_TYPE_INTEL10 ) );
   else if( std::string(DEFAULT_COMPINST).compare( "pgi" ) == 0 )
      assert( setInstType( INST_TYPE_PGI ) );
   else if( std::string(DEFAULT_COMPINST).compare( "phat" ) == 0 )
      assert( setInstType( INST_TYPE_PHAT ) );
   else if( std::string(DEFAULT_COMPINST).compare( "xl" ) == 0 )
      assert( setInstType( INST_TYPE_XL ) );
   else if( std::string(DEFAULT_COMPINST).compare( "ftrace" ) == 0 )
      assert( setInstType( INST_TYPE_FTRACE ) );
   else
      assert( setInstType( INST_TYPE_MANUAL ) );
#else
   assert( setInstType( INST_TYPE_MANUAL ) );
#endif

   // opari's table file
   Properties.opari_tabfile =
      std::make_pair("opari.tab.c", "opari.tab.o");
}

void
Wrapper::showUsageText()
{
   std::cout << std::endl
	     << " " << ExeName << " - "
#ifdef WRAP_LANG_CC
             << "C"
#elif defined(WRAP_LANG_CXX)
             << "C++"
#elif defined(WRAP_LANG_F77)
             << "Fortran 77"
#elif defined(WRAP_LANG_F90)
             << "Fortran 90"
#endif 
	     << " compiler wrapper for VampirTrace."
	     << std::endl << std::endl
	     << " Syntax: " << ExeName << " "
	     << "[-vt:"WRAP_LANG_SUFFIX" <cmd>] "
	     << "[-vt:inst <insttype>] [-vt:<mpi|omp|hyb>] "
	     << std::endl << "         "
	     << "[-vt:opari <args>]"
	     << std::endl << "         "
	     << "[-vt:verbose] "
	     << "[-vt:info] "
	     << "[-vt:showme] "
	     << "[-vt:showme_compile] "
	     << "[-vt:showme_link] ..."
	     << std::endl << std::endl;

   std::cout << "   options:"
	     << std::endl
	     << "     -vt:help            Show this help message."
	     << std::endl
	     << "     -vt:"WRAP_LANG_SUFFIX" <cmd>       ";
   if( strlen( WRAP_LANG_SUFFIX ) == 2 ) std::cout << " ";
   std::cout << "Set the underlying compiler command. (default: ";
#ifdef WRAP_LANG_CC
   std::cout << DEF_CC;
#elif defined(WRAP_LANG_CXX)
   std::cout << DEF_CXX;
#elif defined(WRAP_LANG_F77)
   std::cout << DEF_F77;
#elif defined(WRAP_LANG_F90)
   std::cout << DEF_F90;
#endif 
   std::cout << ")" << std::endl << std::endl;

   std::cout << "     -vt:inst <insttype> Set the instrumentation type."
	     << std::endl << std::endl
	     << "      possible values:"
	     << std::endl << std::endl
	     << "       gnu               fully-automatic by GNU compiler"
	     << std::endl
	     << "       intel9            ... Intel (version 9.x) ..."
	     << std::endl
	     << "       intel10           ... Intel (version >= 10.x) ..."
	     << std::endl
	     << "       pgi               ... Portland Group (PGI) ..."
	     << std::endl
	     << "       phat              ... SUN Fortran 90 ..."
	     << std::endl
	     << "       xl                ... IBM ..."
	     << std::endl
	     << "       ftrace            ... NEC SX ..."
	     << std::endl
	     << "       manual            manual by using VampirTrace's API"
	     << std::endl
	     << "       pomp              manual by using POMP INST directives"
	     << std::endl
	     << "       dyninst           binary by using Dyninst (www.dyninst.org)"
	     << std::endl << std::endl
	     << "       default: ";
#ifdef DEFAULT_COMPINST
   if( std::string(DEFAULT_COMPINST).compare( "gnu" ) == 0 )
      std::cout << "gnu";
   else if( std::string(DEFAULT_COMPINST).compare( "intel9" ) == 0 )
      std::cout << "intel9";
   else if( std::string(DEFAULT_COMPINST).compare( "intel10" ) == 0 )
      std::cout << "intel10";
   else if( std::string(DEFAULT_COMPINST).compare( "pgi" ) == 0 )
      std::cout << "pgi";
   else if( std::string(DEFAULT_COMPINST).compare( "phat" ) == 0 )
      std::cout << "phat";
   else if( std::string(DEFAULT_COMPINST).compare( "xl" ) == 0 )
      std::cout << "xl";
   else if( std::string(DEFAULT_COMPINST).compare( "ftrace" ) == 0 )
      std::cout << "ftrace";
   else
      std::cout << "manual";
#else
   std::cout << "manual";
#endif

   std::cout << std::endl << std::endl;

   std::cout << "     -vt:opari <args>    Set options for OPARI command."
	     << std::endl
	     << "                         (see "VTDOCDIR"/opari/Readme.html for more information)"
	     << std::endl << std::endl
	     << "     -vt:<mpi|omp|hyb>"
	     << std::endl
	     << "                         Force application's parallelization type."
	     << std::endl
	     << "                         It's necessary, if this could not determined"
	     << std::endl
	     << "                         by underlying compiler and flags."
	     << std::endl
	     << "                         mpi = parallel (uses MPI)"
	     << std::endl
	     << "                         omp = parallel (uses OpenMP)"
	     << std::endl
	     << "                         hyb = hybrid parallel (MPI + OpenMP)"
	     << std::endl
	     << "                         (default: automatically determining by"
	     << std::endl
	     << "                          underlying compiler and flags)"
	     << std::endl << std::endl
	     << "     -vt:verbose         Enable verbose mode."
	     << std::endl << std::endl
	     << "     -vt:info            Show some information about currently wrapper settings."
	     << std::endl
	     << "                         (e.g., underlying compiler, instrumentation type)"
	     << std::endl << std::endl
	     << "     -vt:showme          Do not invoke the underlying compiler."
	     << std::endl
	     << "                         Instead, show the command line that would be"
	     << std::endl
	     << "                         executed to compile and link the program."
	     << std::endl << std::endl
	     << "     -vt:showme_compile  Do not invoke the underlying compiler."
	     << std::endl
	     << "                         Instead, show the compiler flags that would be"
	     << std::endl
	     << "                         supplied to the compiler."
	     << std::endl << std::endl
	     << "     -vt:showme_link     Do not invoke the underlying compiler."
	     << std::endl
	     << "                         Instead, show the linker flags the would be"
	     << std::endl
	     << "                         supplied to the compiler."
	     << std::endl << std::endl
	     << "     See the man page for your underlying compiler for other options that can"
	     << std::endl
	     << "     be passed through 'vt"WRAP_LANG_SUFFIX"'."
	     << std::endl << std::endl
	     << "   environment variables:"
	     << std::endl
#ifdef WRAP_LANG_CC
	     << "     VT_CC "
#elif defined(WRAP_LANG_CXX)
	     << "     VT_CXX"
#elif defined(WRAP_LANG_F77)
	     << "     VT_F77"
#elif defined(WRAP_LANG_F90)
	     << "     VT_F90"
#endif
	     << "              Equivalent to '-vt:"WRAP_LANG_SUFFIX"'"
	     << std::endl
	     << "     VT_INST             Equivalent to '-vt:inst'"
	     << std::endl << std::endl
	     << "     The corresponding command line options overwrites the environment"
	     << std::endl
	     << "     variables setting."
	     << std::endl << std::endl
	     << "   examples:"
	     << std::endl
	     << "     automatically instrumentation by using GNU compiler:"
	     << std::endl << std::endl
#ifdef WRAP_LANG_CC
	     << "        vtcc -vt:cc gcc -vt:inst gnu -c foo.c -o foo.o"
	     << std::endl
	     << "        vtcc -vt:cc gcc -vt:inst gnu -c bar.c -o bar.o"
	     << std::endl
	     << "        vtcc -vt:cc gcc -vt:inst gnu foo.o bar.o -o foo"
	     << std::endl << std::endl
	     << "     manually instrumentation by using VT's API:"
	     << std::endl << std::endl
	     << "        vtcc -vt:inst manual foobar.c -o foobar -DVTRACE"
#elif defined(WRAP_LANG_CXX)
	     << "        vtcxx -vt:cxx g++ -vt:inst gnu -c foo.cpp -o foo.o"
	     << std::endl
	     << "        vtcxx -vt:cxx g++ -vt:inst gnu bar.cpp -o bar.o"
	     << std::endl
	     << "        vtcxx -vt:cxx g++ -vt:inst gnu foo.o bar.o -o foo"
	     << std::endl << std::endl
	     << "     manually instrumentation by using VT's API:"
	     << std::endl << std::endl
	     << "        vtcxx -vt:inst manual foobar.cpp -o foobar -DVTRACE"
#elif defined(WRAP_LANG_F77)
	     << "        vtf77 -vt:f77 g77 -vt:inst gnu -c foo.F -o foo.o"
	     << std::endl
	     << "        vtf77 -vt:f77 g77 -vt:inst gnu bar.F -o bar.o"
	     << std::endl
	     << "        vtf77 -vt:f77 g77 -vt:inst gnu foo.o bar.o -o foo"
	     << std::endl << std::endl
	     << "     manually instrumentation by using VT's API:"
	     << std::endl << std::endl
	     << "        vtf77 -vt:inst manual foobar.F -o foobar -DVTRACE"
#elif defined(WRAP_LANG_F90)
	     << "        vtf90 -vt:f90 gfortran -vt:inst gnu -c foo.F90 -o foo.o"
	     << std::endl
	     << "        vtf90 -vt:f90 gfortran -vt:inst gnu bar.F90 -o bar.o"
	     << std::endl
	     << "        vtf90 -vt:f90 gfortran -vt:inst gnu foo.o bar.o -o foo"
	     << std::endl << std::endl
	     << "     manually instrumentation by using VT's API:"
	     << std::endl << std::endl
	     << "        vtf90 -vt:inst manual foobar.F90 -o foobar -DVTRACE"
#endif

#if defined(WRAP_LANG_F77) || defined(WRAP_LANG_F90)
	     << std::endl << std::endl
	     << "     IMPORTANT: Fortran source files instrumented by using VT's API or POMP"
	     << std::endl
	     << "                directives have to be (CPP) preprocessed."
#endif
	     << std::endl << std::endl;
}

void
Wrapper::showInfo()
{
   // underlying compiler
   //
   std::cout << "Underlying compiler:                       "
	     << Properties.comp_cmd << std::endl;

   // instrumentation type
   //
   InstTypeT inst_type = getInstType();
   std::cout << "Instrumentation type:                      ";

   switch( inst_type )
   {
      case INST_TYPE_GNU:
	 std::cout << "gnu" << std::endl;
	 std::cout << " Compiler/Linker flag for instrumentation: "
		   << INSTFLAG_GNU << std::endl;
	 break;
      case INST_TYPE_INTEL9:
	 std::cout << "intel9" << std::endl;
	 break;
      case INST_TYPE_INTEL10:
	 std::cout << "intel10" << std::endl;
	 break;
      case INST_TYPE_PGI:
	 std::cout << "pgi" << std::endl;
	 break;
      case INST_TYPE_PHAT:
	 std::cout << "phat" << std::endl;
	 break;
      case INST_TYPE_XL:
	 std::cout << "xl" << std::endl;
	 break;
      case INST_TYPE_FTRACE:
	 std::cout << "ftrace" << std::endl;
	 break;
      case INST_TYPE_MANUAL:
	 std::cout << "manual" << std::endl;
	 break;
      case INST_TYPE_POMP:
	 std::cout << "pomp" << std::endl;
	 break;
      case INST_TYPE_DYNINST:
	 std::cout << "dyninst" << std::endl;
	 break;
      default:
	 assert( 0 );
	 break;
   }

   // available instrumentation types
   //
   std::cout << " Available instrumentation types:         ";
   if( isInstAvail( INST_TYPE_GNU ) )
      std::cout << " gnu";
   if( isInstAvail( INST_TYPE_INTEL9 ) )
      std::cout << " intel9";
   if( isInstAvail( INST_TYPE_INTEL10 ) )
      std::cout << " intel10";
   if( isInstAvail( INST_TYPE_PGI ) )
      std::cout << " pgi";
   if( isInstAvail( INST_TYPE_PHAT ) )
      std::cout << " phat";
   if( isInstAvail( INST_TYPE_XL ) )
      std::cout << " xl";
   if( isInstAvail( INST_TYPE_FTRACE ) )
      std::cout << " ftrace";
   if( isInstAvail( INST_TYPE_MANUAL ) )
      std::cout << " manual";
   if( isInstAvail( INST_TYPE_POMP ) )
      std::cout << " pomp";
   if( isInstAvail( INST_TYPE_DYNINST ) )
      std::cout << " dyninst";
   std::cout << std::endl;
}

void
Wrapper::show()
{
   // show compiler command
   //
   if( showme() )
      std::cout << Properties.comp_cmd << " ";

   // show compiler flags
   //
   if( showmeCompile() )
   {
      std::cout << Properties.comp_instflag << " "
		<< VTINCDIR << " "
		<< Properties.comp_args << " ";
      if( !showmeLink() ) std::cout << std::endl;
   }
   
   // show linker flags
   //
   if( showmeLink() )
   {
      char vtlib[STRBUFSIZE];

      if( usesOMP() )
      {
	 if( usesMPI() )
	 {
	    sprintf( vtlib, VTLIBDIR" %s %s "VTHYBLIB" "PMPILIB" %s "METRLIB,
		     getInstType() == INST_TYPE_DYNINST ?
		     VTDYNATTLIB : "",
#if defined(WRAP_LANG_F77) || defined(WRAP_LANG_F90)
		     FMPILIB,
#else
		     "",
#endif
		     Properties.comp_ulibs.c_str() );
	 }
	 else
	 {
	    sprintf( vtlib, VTLIBDIR" %s "VTOMPLIB" %s "METRLIB,
		     getInstType() == INST_TYPE_DYNINST ?
		     VTDYNATTLIB : "",
		     Properties.comp_ulibs.c_str() );
	 }
      }
      if( usesMPI() )
      {
	 sprintf( vtlib, VTLIBDIR" %s %s "VTMPILIB" "PMPILIB" %s "METRLIB,
		  getInstType() == INST_TYPE_DYNINST ?
		  VTDYNATTLIB : "",
#if defined(WRAP_LANG_F77) || defined(WRAP_LANG_F90)
		  FMPILIB,
#else
		  "",
#endif	     
		  Properties.comp_ulibs.c_str() );
      }
      else
      {
	 sprintf( vtlib, VTLIBDIR" %s "VTSEQLIB" %s "METRLIB,
		  getInstType() == INST_TYPE_DYNINST ?
		  VTDYNATTLIB : "",
		  Properties.comp_ulibs.c_str() );	     
      }

      std::cout << (showmeCompile() ? "" : Properties.comp_args) << " "
		<< (showmeCompile() ? "" : Properties.comp_instflag) << " "
		<< vtlib << std::endl;
   }
}

int
Wrapper::run()
{
   // show info ?
   //
   if( showmeInfo() )
   {
      showInfo();
      return 0;
   }

   // show compiler/linker flags ?
   //
   if( showmeCompile() || showmeLink() )
   {
      show();
      return 0;
   }
   
   std::string cmd;
   int rc = 0;

   // call compiler without any parameters, if
   // insufficient arguments given
   //
   if( Properties.comp_args.length() == 0
       && !showmeCompile() && !showmeLink() )
   {
      rc = system( Properties.comp_cmd.c_str() );
      return WEXITSTATUS( rc );
   }

   // run opari on every collected source file
   //
   if( usesOMP() || getInstType() == INST_TYPE_POMP )
   {
      // add opari option '-nodecl' if PGI compiler will be used
      if( getInstType() == INST_TYPE_PGI )
	 opari_addArg( "-nodecl" );

      for( uint32_t i = 0; i < Properties.vec_opari_files.size(); i++ )
      {
	 cmd =
	    Properties.opari_cmd + " "
	    + Properties.opari_args + " "
	    + (usesOMP() ? "" : "-disable omp") + " "
	    + "-table "
	    + Properties.opari_tabfile.first + " "
	    + Properties.vec_opari_files[i];

	 if( beverbose() )
	    std::cout << "+++ " << cmd << std::endl;
	 rc = system( cmd.c_str() );
	 if( WEXITSTATUS( rc ) != 0 )
	    return WEXITSTATUS( rc );
      }
   }

   // executing modified command
   //
   if( componly() )
   {
      cmd =
	 Properties.comp_cmd + " "VTINCDIR" "
	 + Properties.comp_instflag + " "
	 + Properties.comp_args;

      if( beverbose() )
	 std::cout << "+++ " << cmd << std::endl;
      rc = system( cmd.c_str() );
      if( WEXITSTATUS( rc ) != 0 )
	 return WEXITSTATUS( rc );
   }
   else
   {
      char vtlib[STRBUFSIZE];

      if( usesOMP() || getInstType() == INST_TYPE_POMP )
      {
	 // compile opari table file
	 //
	 cmd =
	    DEF_CC" "
	    + Properties.comp_pflag + " "VTINCDIR" "
	    + "-c " + Properties.opari_tabfile.first + " "
	    + "-o " + Properties.opari_tabfile.second;

	 if( beverbose() )
	    std::cout << "+++ " << cmd << std::endl;
	 rc = system( cmd.c_str() );
	 if( WEXITSTATUS( rc ) != 0 )
	    return WEXITSTATUS( rc );
      }

      if( usesOMP() )
      {
	 if( usesMPI() )
	 {
	    sprintf( vtlib, VTLIBDIR" %s %s "VTHYBLIB" "PMPILIB" %s "METRLIB,
		     getInstType() == INST_TYPE_DYNINST ?
		     VTDYNATTLIB : "",
#if defined(WRAP_LANG_F77) || defined(WRAP_LANG_F90)
		     FMPILIB,
#else
		     "",
#endif
		     Properties.comp_ulibs.c_str() );
	 }
	 else
	 {
	    sprintf( vtlib, VTLIBDIR" %s "VTOMPLIB" %s "METRLIB,
		     getInstType() == INST_TYPE_DYNINST ?
		     VTDYNATTLIB : "",
		     Properties.comp_ulibs.c_str() );
	 }
      }
      else
      {
	 if( usesMPI() )
	 {
	    sprintf( vtlib, VTLIBDIR" %s %s "VTMPILIB" "PMPILIB" %s "METRLIB,
		     getInstType() == INST_TYPE_DYNINST ?
		     VTDYNATTLIB : "",
#if defined(WRAP_LANG_F77) || defined(WRAP_LANG_F90)
		     FMPILIB,
#else
		     "",
#endif	     
		     Properties.comp_ulibs.c_str() );
	 }
	 else
	 {
	    sprintf( vtlib, VTLIBDIR" %s "VTSEQLIB" %s "METRLIB,
		     getInstType() == INST_TYPE_DYNINST ?
		     VTDYNATTLIB : "",
		     Properties.comp_ulibs.c_str() );	     
	 }
      }

      cmd =
	 Properties.comp_cmd + " "
	 + Properties.comp_instflag + " "VTINCDIR" "
	 + Properties.comp_args + " "
	 + (( usesOMP() || getInstType() == INST_TYPE_POMP ) ? Properties.opari_tabfile.second : "" ) + " "
	 + vtlib;

      if( beverbose() )
	 std::cout << "+++ " << cmd << std::endl;

      rc = system( cmd.c_str() );
      if( WEXITSTATUS( rc ) != 0 )
	 return WEXITSTATUS( rc );

      // cleanup intermediate files (in non-verbose mode)
      //
      if( !beverbose()
	  && (usesOMP() || getInstType() == INST_TYPE_POMP) )
      {
	 std::vector<std::string> vec_incfiles =
	    opari_getIncFilesFromTabFile(
	       Properties.opari_tabfile.first );

	 for( uint32_t i = 0; i < vec_incfiles.size(); i++ )
	    remove( vec_incfiles[i].c_str() );

	 remove( Properties.opari_tabfile.first.c_str() );
	 remove( Properties.opari_tabfile.second.c_str() );
      }
   }

   if( usesOMP() || getInstType() == INST_TYPE_POMP )
   {
      uint32_t i;

      // rename compiler output to original file name
      //
      for( i = 0; i < Properties.vec_opari_mfiles_obj.size(); i++ )
      {
	 if( access( Properties.vec_opari_mfiles_obj[i].c_str(), F_OK ) == 0 )
	 {
	    int32_t modi = Properties.vec_opari_mfiles_obj[i].find( ".mod" );

	    if( modi != -1 )
	    {
	       std::string target = Properties.vec_opari_mfiles_obj[i];
	       target.erase( modi, 4 );
	       
	       if( beverbose() )
		  std::cout << "+++ rename " << Properties.vec_opari_mfiles_obj[i]
			    << " to " << target << std::endl;
	       
	       rename( Properties.vec_opari_mfiles_obj[i].c_str(),
		       target.c_str() );
	    }
	 }
      }

      // delete intermediate opari output (in non-verbose mode)
      //
      if( !beverbose() )
      {
	 for( i = 0; i < Properties.vec_opari_mfiles_src.size(); i++ )
	    remove( Properties.vec_opari_mfiles_src[i].c_str() );
      }
   }

   return 0;
}

bool
Wrapper::setInstType( const InstTypeT type )
{
   assert( Properties.inst_avail != 0 );

   // instrumentation available ?
   if( !isInstAvail( type ) )
      return false;

   Properties.inst_type = type;

   char tmp[STRBUFSIZE];

   switch( type )
   {
      case INST_TYPE_GNU:
	 Properties.comp_instflag = INSTFLAG_GNU;
	 sprintf( tmp, "%s %s %s", OTFLIB, BFDLIB, LIBERTYLIB );
	 break;
      case INST_TYPE_INTEL9:
	 Properties.comp_instflag = INSTFLAG_INTEL9;
	 sprintf( tmp, "%s", OTFLIB );
	 break;
      case INST_TYPE_INTEL10:
	 Properties.comp_instflag = INSTFLAG_INTEL10;
	 sprintf( tmp, "%s %s %s", OTFLIB, BFDLIB, LIBERTYLIB );
	 break;
      case INST_TYPE_PGI:
	 Properties.comp_instflag = INSTFLAG_PGI;
	 sprintf( tmp, "%s", OTFLIB );
	 break;
      case INST_TYPE_PHAT:
	 Properties.comp_instflag = INSTFLAG_PHAT;
	 sprintf( tmp, "%s", OTFLIB );
	 break;
      case INST_TYPE_XL:
	 Properties.comp_instflag = INSTFLAG_XL;
	 sprintf( tmp, "%s", OTFLIB );
	 break;
      case INST_TYPE_FTRACE:
	 Properties.comp_instflag = INSTFLAG_FTRACE;
	 sprintf( tmp, "%s", OTFLIB );
	 break;
      default:
	 Properties.comp_instflag = "";
	 sprintf( tmp, "%s", OTFLIB );
	 break;
   }

   Properties.comp_ulibs = tmp;

   return true;
}

void
Wrapper::comp_setCmd( const std::string cmd )
{
   std::string bcomp = cmd;
   int32_t ls = cmd.rfind('/');

   if( ls != -1 ) bcomp = cmd.substr( ls+1 );
   
   if( !Properties.uses_mpi && bcomp.compare( 0, 2, "mp" ) == 0 )
      Properties.uses_mpi = true;

   Properties.comp_cmd = cmd;
}

void
Wrapper::comp_setPFlag( const std::string pflag )
{
   Properties.comp_pflag = pflag;
}

void
Wrapper::comp_addArg( const std::string arg )
{
   if( Properties.comp_args.length() > 0 )
      Properties.comp_args += " ";

   Properties.comp_args += arg;
}

void
Wrapper::comp_addULib( const std::string ulib )
{
   if( Properties.comp_ulibs.length() > 0 )
      Properties.comp_ulibs += " ";

   Properties.comp_ulibs += ulib;
}

void
Wrapper::opari_setTabFile( const std::string tabfile )
{
   std::string file_src;
   std::string file_obj;

   if( !( tabfile.length() >= 2
	  && tabfile.compare( tabfile.length()-2, 2, ".c" ) == 0 ) )
   {
      file_src = tabfile + ".c";
      file_obj = tabfile + ".o";
   }
   else
   {
      file_src = file_obj = tabfile;
      file_obj.replace( tabfile.length()-2, 2, ".o" );
   }

   Properties.opari_tabfile = std::make_pair( file_src, file_obj );

}

void
Wrapper::opari_addArg( const std::string arg )
{
   if( Properties.opari_args.length() > 0 )
      Properties.opari_args += " ";

   Properties.opari_args += arg;
}

void
Wrapper::opari_addSrcFile( const std::string srcfile )
{
   std::string base = srcfile.substr(0, srcfile.rfind('.'));
   std::string suf = srcfile.substr(srcfile.rfind('.'));
   std::string newsrcfile;
   std::string newobjfile = base + std::string(".mod.o");

   // erase path of object file
   int32_t si = newobjfile.rfind('/');
   if( si != -1 ) newobjfile.erase( 0, si+1 );

   // replace 'f' by 'F'
   // so the compiler invokes the C-preprocessor
   int32_t fi = suf.rfind( 'f' );
   if( fi != -1 ) suf.replace( fi, 1, "F" );

   newsrcfile = base + std::string(".mod") + suf;

   Properties.vec_opari_files.push_back( srcfile );
   Properties.vec_opari_mfiles_src.push_back( newsrcfile );
   Properties.vec_opari_mfiles_obj.push_back( newobjfile );

   if( !( ( srcfile.length() >= 2
	    && srcfile.compare( srcfile.length() - 2, 2, ".f" ) == 0 )
	  || ( srcfile.length() >= 2
	       && srcfile.compare( srcfile.length() - 2, 2, ".F" ) == 0 )
	  || ( srcfile.length() >= 4
	       && srcfile.compare( srcfile.length() - 4, 4, ".f77" ) == 0 )
	  || ( srcfile.length() >= 4
	       && srcfile.compare( srcfile.length() - 4, 4, ".F77" ) == 0 )
	  || ( srcfile.length() >= 4
	       && srcfile.compare( srcfile.length() - 4, 4, ".f90" ) == 0 )
	  || ( srcfile.length() >= 4
	       && srcfile.compare( srcfile.length() - 4, 4, ".F90" ) == 0 )
	  || ( srcfile.length() >= 4
	       && srcfile.compare( srcfile.length() - 4, 4, ".f95" ) == 0 )
	  || ( srcfile.length() >= 4
	       && srcfile.compare( srcfile.length() - 4, 4, ".F95" ) == 0 ) ) )
   {
      std::string incfile = srcfile + std::string(".opari.inc");
      Properties.vec_opari_mfiles_src.push_back( incfile );
   }

   comp_addArg( newsrcfile );
}

std::vector<std::string>
Wrapper::opari_getIncFilesFromTabFile( const std::string tabfile )
{
   std::vector<std::string> vec_incfiles;

   std::ifstream in( tabfile.c_str() );
   if( in )
   {
      char buffer[STRBUFSIZE];
      std::string line;

      while( in.getline( buffer, STRBUFSIZE ) )
      {
	 line = buffer;

	 if( (int)(line.find( "#include" )) != -1
	     && (int)(line.find( ".opari.inc" )) != -1 )
	 {
	    std::string incfile = line.substr( line.find("#include")+10 );
	    incfile.erase( incfile.length()-1 );

	    vec_incfiles.push_back( incfile );
	 }
      }

      in.close();
   }

   return vec_incfiles;
}
