/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2007, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich GmbH, Federal
 * Republic of Germany
 *
 * See the file COPYRIGHT in the package base directory for details
 **/

#ifndef _COMPWRAP_H_
#define _COMPWRAP_H_

#include "compwrap_conf.h"

#define STRBUFSIZE 4096

typedef enum
{
   INST_TYPE_GNU     = 0x1,     // auto. instrumentation by GNU comp.
   INST_TYPE_INTEL9  = 0x2,     // ^ Intel version 9
   INST_TYPE_INTEL10 = 0x4,     // ^ Intel version >=10
   INST_TYPE_PGI     = 0x8,     // ^ PGI
   INST_TYPE_PHAT    = 0x10,    // ^ SUN
   INST_TYPE_XL      = 0x20,    // ^ IBM (xlc, xlC,...)
   INST_TYPE_FTRACE  = 0x40,    // ^ NEC SX
   INST_TYPE_MANUAL  = 0x80,    // manual instr. by VT API
   INST_TYPE_POMP    = 0x100,   // semi auto. instr. by POMP directives
   INST_TYPE_DYNINST = 0x200    // binary instrumentation by Dyninst
} InstTypeT;

class Wrapper
{
public:
   
   struct ProperiesS
   {
      ProperiesS() :
	 comp_cmd(""), comp_args(""), comp_instflag(""),
         comp_ulibs(""), comp_pflag(""),
         opari_cmd(VTBINDIR"/opari"), opari_args(""),
         inst_type(INST_TYPE_MANUAL), inst_avail(0x180),
         beverbose(false), componly(false), uses_mpi(false),
         uses_omp(false), showme_info(false), showme(false),
         showme_compile(false), showme_link(false) {}

      std::string comp_cmd;        // compiler command
      std::string comp_args;       // compiler arguments
      std::string comp_instflag;   // compiler instrumentation flag
      std::string comp_ulibs;      // necessary libs. for VT
      std::string comp_pflag;      // flag for specifying compile mode
                                   // (e.g. 32bit o. 64bit)

      std::string opari_cmd;       // OPARI command
      std::string opari_args;      // OPARI arguments
      std::pair<std::string, std::string>
	 opari_tabfile;            // OPARI's table source file 
      std::vector<std::string>
         vec_opari_files;          // OPARI's input source files
      std::vector<std::string>
         vec_opari_mfiles_src;     // OPARI's output source files (*.mod.*)
      std::vector<std::string>
         vec_opari_mfiles_obj;     // ^ corresponding obj. files

      InstTypeT inst_type;         // instrumentation type
                                   // (e.g. gnu,intel9,manual,...)
      int       inst_avail;        // bitmask for available instr.-types
      bool      beverbose;         // FLAG: be verbose ?
      bool      componly;          // FLAG: compile only ?
      bool      uses_mpi;          // FLAG: uses MPI ?
      bool      uses_omp;          // FLAG: uses OpenMP ?
      bool      showme_info;       // FLAG: show info ?
      bool      showme;            // FLAG: show compiler/linker flags ?
      bool      showme_compile;    // FLAG: show compiler flags ?
      bool      showme_link;       // FLAG: show linker flags ?
   } Properties;

   Wrapper();    // contructor
   ~Wrapper();   // destructor

   void initialize();
   void showUsageText();
   void showInfo();
   void show();
   int  run();

   bool setInstType( const InstTypeT type );
   InstTypeT getInstType() { return Properties.inst_type; }
   bool isInstAvail( InstTypeT type ) {
      return (Properties.inst_avail & type); }
   void comp_setCmd( const std::string cmd );
   void comp_setPFlag( const std::string pflag );
   void comp_addArg( const std::string arg );
   void comp_addULib( const std::string ulib );

   void opari_setTabFile( const std::string tabfile );
   void opari_addArg( const std::string arg );
   void opari_addSrcFile( const std::string srcfile );
   std::vector<std::string> opari_getIncFilesFromTabFile
      ( const std::string tabfile );

   void setBeVerbose( const bool set ) { Properties.beverbose = set; }
   bool beverbose() { return Properties.beverbose; }
   void setComponly( const bool set ) { Properties.componly = set; }
   bool componly() { return Properties.componly; }
   void setUsesMPI( const bool set ) { Properties.uses_mpi = set; }
   bool usesMPI() { return Properties.uses_mpi; }
   void setUsesOMP( const bool set ) { Properties.uses_omp = set; }
   bool usesOMP() { return Properties.uses_omp; }
   void setShowmeInfo( const bool set ) { Properties.showme_info = set; }
   bool showmeInfo() { return Properties.showme_info; }
   void setShowme( const bool set ) {
      Properties.showme = Properties.showme_compile =
	 Properties.showme_link = set; }
   bool showme() { return Properties.showme; }
   void setShowmeCompile( const bool set ) { Properties.showme_compile = set; }
   bool showmeCompile() { return Properties.showme_compile; }
   void setShowmeLink( const bool set ) { Properties.showme_link = set; }
   bool showmeLink() { return Properties.showme_link; }

};

extern Wrapper * theWrapper;

#endif // _WRAPPER_H_
