/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2007, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich GmbH, Federal
 * Republic of Germany
 *
 * See the file COPYRIGHT in the package base directory for details
 **/

#if HAVE_CONFIG_H
#  include <config.h>
#endif

#include "vt_pform.h"

#include <stdio.h>
#include <catamount/dclock.h>
#include <catamount/data.h>

/* platform specific initialization */
void vt_pform_init() {}

/* directory of global file system  */
char* vt_pform_gdir() {
  return ".";
}

/* directory of local file system  */
char* vt_pform_ldir() {
  #ifdef PFORM_LDIR
    return PFORM_LDIR;
  #else
    return "/tmp";
  #endif
}

/* is a global clock provided ? */ 
int vt_pform_is_gclock() {
  return 0;
}

/* clock resolution */
uint64_t vt_pform_clockres() {
  return 1e15;
}

/* local or global wall-clock time */
uint64_t vt_pform_wtime() {
  return (uint64_t)(dclock() * 1.0e15);
}

/* unique numeric SMP-node identifier */
long vt_pform_node_id() {
  return _my_rank;
}

/* unique string SMP-node identifier */
char* vt_pform_node_name() {
  static char node[16];
  sprintf(node, "node%d", _my_pnid);
  return node;              
}

/* number of CPUs */
int vt_pform_num_cpus() {
  return 1;
}
