/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2007, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich GmbH, Federal
 * Republic of Germany
 *
 * See the file COPYRIGHT in the package base directory for details
 **/

#if HAVE_CONFIG_H
#  include <config.h>
#endif

#include "vt_pform.h"
#include "vt_defs.h"
#include "vt_error.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>

#ifndef VT_PROCDIR 
#  define VT_PROCDIR "/proc/"
#endif

#if TIMER != TIMER_CYCLE_COUNTER && \
    TIMER != TIMER_GETTIMEOFDAY && \
    TIMER != TIMER_POSIX_CLOCK
# error Unknown timer specified! Check the timer configuration in 'config.h'.
#endif

#if TIMER == TIMER_POSIX_CLOCK || TIMER == TIMER_GETTIMEOFDAY
# include <time.h>
# include <sys/time.h>
  static uint64_t vt_time_base = 0;
#else
  static uint64_t vt_ticks_per_sec = 1;
#endif

static uint32_t vt_cpu_count=0;

/* platform specific initialization */
void vt_pform_init()
{
  FILE   *cpuinfofp;
  char   line[1024];
  
#if TIMER == TIMER_POSIX_CLOCK
  struct timespec tp;
  clock_gettime(CLOCK_REALTIME, &tp);
  vt_time_base = tp.tv_sec - (tp.tv_sec & 0xFF);
#elif TIMER == TIMER_GETTIMEOFDAY
  struct timeval tp;
  gettimeofday(&tp, 0);
  vt_time_base = tp.tv_sec - (tp.tv_sec & 0xFFFF);
#endif

  if ((cpuinfofp = fopen (VT_PROCDIR "cpuinfo", "r")) == NULL) 
    vt_error_msg("Cannot open file %s: %s\n", VT_PROCDIR "cpuinfo",
                  strerror(errno));
  
  while (fgets(line, sizeof (line), cpuinfofp))
  {
    if (!strncmp("processor", line, 9))
      vt_cpu_count++;
#if TIMER != TIMER_POSIX_CLOCK && TIMER != TIMER_GETTIMEOFDAY
    {
      if (!strncmp("cpu MHz", line, 7))
      {
	strtok(line, ":");
      
	vt_ticks_per_sec =
	  strtol((char*) strtok(NULL, " \n"), (char**) NULL, 0) * 1e6;
      }
      if (!strncmp("timebase", line, 8))
      {
	strtok(line, ":");
      
	vt_ticks_per_sec =
	  strtol((char*) strtok(NULL, " \n"), (char**) NULL, 0);
      }
    }
#endif
  }
  
  fclose(cpuinfofp);
}

/* directory of global file system  */
char* vt_pform_gdir()
{
  return ".";
}

/* directory of local file system  */
char* vt_pform_ldir()
{
#  ifdef PFORM_LDIR
    return PFORM_LDIR;
#  else
    return "/tmp";
#  endif
}

/* is a global clock provided ? */
int vt_pform_is_gclock()
{
  return 0;
}

/* clock resolution */
uint64_t vt_pform_clockres()
{
#if TIMER == TIMER_POSIX_CLOCK
  return 1e9;
#elif TIMER == TIMER_GETTIMEOFDAY
  return 1e6;
#else
  return vt_ticks_per_sec;
#endif
}

/* local or global wall-clock time */
uint64_t vt_pform_wtime()
{
#if TIMER == TIMER_POSIX_CLOCK
  struct timespec tp;
  clock_gettime(CLOCK_REALTIME, &tp);
  return ((tp.tv_sec - vt_time_base) * 1e9) + tp.tv_nsec;
#elif TIMER == TIMER_GETTIMEOFDAY
  struct timeval tp;
  gettimeofday(&tp, 0);
  return ((tp.tv_sec - vt_time_base) * 1e6) + tp.tv_usec;
#else
  uint64_t clock_value;

# ifdef __powerpc64__
    /* ... PPC64 */
    asm volatile("mftb %0" : "=r" (clock_value));
# elif defined(__powerpc__)
    /* ... PPC32 */
    {
      uint32_t low = 0;
      uint32_t higha = 0;
      uint32_t highb = 0;
    
      do {
	asm volatile ("mftbu %0" : "=r"(highb));
	asm volatile ("mftb %0" : "=r"(low));
	asm volatile ("mftbu %0" : "=r"(higha));
      } while (highb != higha);
      clock_value = ((uint64_t)higha << 32) | (uint64_t)low;
    }
# elif defined(__ia64__)
    /* ... ITC */
    asm volatile ("mov %0=ar.itc" : "=r"(clock_value));
# else
    /* ... TSC */
    {
      uint32_t low = 0;
      uint32_t high = 0;
       
      asm volatile ("rdtsc" : "=a" (low), "=d" (high));
       
      clock_value = ((uint64_t)high << 32) | (uint64_t)low;
    }
# endif

  return clock_value;
#endif
}

/* unique numeric SMP-node identifier */
long vt_pform_node_id()
{
  return gethostid(); 
}

/* unique string SMP-node identifier */
char* vt_pform_node_name()
{
  static char host_name[20];

  gethostname(host_name, 20);

  return host_name;
}

/* number of CPUs */
int vt_pform_num_cpus()
{
   return vt_cpu_count;
}
