/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2006, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich GmbH, Federal
 * Republic of Germany
 *
 * See the file COPYRIGHT in the package base directory for details
 **/

#ifndef _VT_MEMHOOK_H
#define _VT_MEMHOOK_H

#ifdef __cplusplus
#   define EXTERN extern "C" 
#else
#   define EXTERN extern 
#endif

#include <inttypes.h>
#include <stdlib.h>

#if (defined(VT_MEMHOOK))
# include <malloc.h>
# define VT_MEMHOOKS_OFF() \
    if ( memhook_is_initialized ) __malloc_hook = org_malloc_hook; \
    if ( memhook_is_initialized ) __realloc_hook = org_realloc_hook; \
    if ( memhook_is_initialized ) __free_hook = org_free_hook
# define VT_MEMHOOKS_ON() \
    if ( memhook_is_initialized ) __malloc_hook = vt_malloc_hook; \
    if ( memhook_is_initialized ) __realloc_hook = vt_realloc_hook; \
    if ( memhook_is_initialized ) __free_hook = vt_free_hook
#else
# define VT_MEMHOOKS_OFF()
# define VT_MEMHOOKS_ON()
#endif

/* memory hooks initialization */
EXTERN void vt_memhook_init();

/* memory hooks finalization */
EXTERN void vt_memhook_finalize();

/* Prototypes for our hooks */
EXTERN void* vt_malloc_hook(size_t size, const void* caller);
EXTERN void* vt_realloc_hook(void* ptr, size_t size, const void* caller);
EXTERN void  vt_free_hook(void* ptr, const void* caller);

/* Variables to save original hooks */
EXTERN void* (*org_malloc_hook)(size_t, const void *);
EXTERN void* (*org_realloc_hook)(void* ptr, size_t size, const void* caller);
EXTERN void  (*org_free_hook)(void* ptr, const void* caller);

EXTERN uint8_t memhook_is_initialized;

#endif /* _VT_MEMHOOK_H */

