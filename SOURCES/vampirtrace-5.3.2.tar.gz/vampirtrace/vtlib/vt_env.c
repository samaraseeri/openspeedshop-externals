/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2007, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich GmbH, Federal
 * Republic of Germany
 *
 * See the file COPYRIGHT in the package base directory for details
 **/

#include "vt_env.h"
#include "vt_error.h"
#include "vt_defs.h"
#include "vt_pform.h"

#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <limits.h>
#include <ctype.h>

#define VT_MAX_NUM_THRDS 65536

static char* replace_vars(char *v) {
  char* start;
  char* end;
  char* vname;
  char* vval;
  char* res;
  int extra = 0;
  int plen = 0;

  if ((start = strchr(v, '$')) == NULL ) {
    /* no $ in v -> no replacement necessary */
    return v;
  } else {
    if ( start[1] == '{' ) {
      /* ${....} form */
      extra = 1;
      end = start += 2;
      while ( *end && *end != '}' ) end++;
    } else {
      /* $### form where # is letter, digit, or underscore */
      end = ++start;
      while ( *end && (isalnum(*end) || *end == '_')) end++;
    }
    /* determine name of variable */
    vname = (char*)malloc(end-start);
    strncpy(vname, start, end-start);
    vname[end-start] = '\0';

    /* get its content */
    if ((vval = getenv(vname)) == NULL) vval = "";

    /* put together string with variable replaced by value */
    /* -- allocate enough space and copy stuff before variable part */
    res = (char*)malloc(strlen(v)+strlen(vval));
    plen = (start - v) - 1 - extra;
    if (plen) strncpy(res, v, plen);
    res[plen] = '\0';
    /* -- add variable content */
    strcat(res, vval);
    /* -- add stuff after variable */
    if ( *end ) strcat(res, end + extra);
    return res;
  }
}

static int parse_bool(char *str) {
  static char strbuf[128];
  char* ptr = strbuf;

  strncpy(strbuf, str, 128);
  while ( *ptr )
    {
      *ptr = tolower(*ptr);
      ++ptr;
    }

  if ( strcmp(strbuf, "yes") == 0  ||
       strcmp(strbuf, "true") == 0 ||
       strcmp(strbuf, "1") == 0)
    {
      return 1;
    }
  else
    {
      return 0;
    }
}

static size_t parse_size(char *str) {
  size_t size = 0;

  if (strlen(str) > 1)
  {
     int multiply = 1;

     if (str[strlen(str)-1] == 'M' 
	 || str[strlen(str)-1] == 'm')
     {
	multiply = 1e6;
     }
     else if (str[strlen(str)-1] == 'G' 
	      || str[strlen(str)-1] == 'g')
     {
	multiply = 1e9;
     }

     size = atoll(str) * multiply;
  }

  return size;
}

char* vt_env_apppath()
{
  return getenv("VT_APPPATH");
}

char* vt_env_dyn_blacklist()
{
  return getenv("VT_DYN_BLACKLIST");
}

char* vt_env_dyn_shlibs()
{
  return getenv("VT_DYN_SHLIBS");
}

char* vt_env_gdir()
{
  static char* gdir = NULL;
  char* tmp;

  if (! gdir)
    {
      tmp = getenv("VT_PFORM_GDIR");
      if (tmp != NULL)
        {
          gdir = replace_vars(tmp);
        }
      else
        {
          gdir = replace_vars(vt_pform_gdir());
        } 
    }
  return gdir;
}

char* vt_env_ldir()
{
  static char* ldir = NULL;
  char* tmp;

  if (! ldir)
    {
      tmp = getenv("VT_PFORM_LDIR");
      if (tmp != NULL)
        {
          ldir = replace_vars(tmp);
        }
      else
        {
          ldir = replace_vars(vt_pform_ldir());
        } 
    }
  return ldir;
}

char* vt_env_fprefix()
{
  static char* fprefix = NULL;
  char* tmp;

  if (! fprefix)
    {
      tmp = getenv("VT_FILE_PREFIX");
      if (tmp != NULL)
        {
          fprefix = replace_vars(tmp);
        }
      else
        {
          fprefix = "a";
        } 
    }
  return fprefix;
}

size_t vt_env_bsize()
{
  size_t buffer_size = VT_DEF_BUFSIZE;

  char* tmp = getenv("VT_BUFFER_SIZE");
  if (tmp != NULL)
    {
      buffer_size = parse_size(tmp);
      if (buffer_size <= 0)
	  vt_error_msg("VT_BUFFER_SIZE not properly set");
      else if (buffer_size < VT_MIN_BUFSIZE) {
          vt_warning("VT_BUFFER_SIZE=%d resized to %d bytes", 
                      buffer_size, VT_MIN_BUFSIZE);
          buffer_size = VT_MIN_BUFSIZE;
      }
    }

  return buffer_size;
}

int vt_env_is_verbose()
{
  char* tmp = getenv("VT_VERBOSE");
  if (tmp != NULL)
    {
      int val = atoi(tmp);
      if (val != 0) return val;

      return parse_bool(tmp);
    }
  return 0;
}

int vt_env_do_unify()
{
  char* tmp = getenv("VT_UNIFY");
  if (tmp != NULL)
    {
      return parse_bool(tmp);
    }
  return 1;
}

int vt_env_do_clean()
{
  char* tmp = getenv("VT_CLEAN");
  if (tmp != NULL)
    {
      return parse_bool(tmp);
    }
  return 1;
}

int vt_env_memtrace()
{
  char* tmp = getenv("VT_MEMTRACE");
  if (tmp != NULL)
    {
      int val = atoi(tmp);
      if (val != 0) return val;

      return parse_bool(tmp);
    }
  return 0;
}

int vt_env_mpitrace()
{
  char* tmp = getenv("VT_MPITRACE");
  if (tmp != NULL)
    {
      return parse_bool(tmp);
    }
  return 1;
}

char* vt_env_metrics()
{
  return getenv("VT_METRICS");
}

/* The file with the metrics specifications can be defined with the
VT_METRICS_SPEC environment variable, otherwise it is looked for in
the current directory and the VampirTrace installation DATADIR. */

#define METRICS_SPEC "METRICS.SPEC"

char* vt_env_metrics_spec()
{
  char  msg[128];
  char* spec = getenv("VT_METRICS_SPEC");

  if ( spec != NULL ) { /* use specified file */
    sprintf(msg, "VT_METRICS_SPEC=%s", spec);
  } else if (access(METRICS_SPEC, R_OK) == 0) {
    /* use file in current directory */
    spec = (char*)calloc(strlen(METRICS_SPEC)+3, 1);
    sprintf(spec, "./%s", METRICS_SPEC);
    sprintf(msg, "[CURDIR] VT_METRICS_SPEC=%s", spec);
  } else {
#ifdef DATADIR
    /* default to installation file */
    spec = (char*)calloc(strlen(DATADIR)+strlen(METRICS_SPEC)+2, 1);
    sprintf(spec, "%s/%s", DATADIR, METRICS_SPEC);
    sprintf(msg, "[DATADIR] VT_METRICS_SPEC=%s", spec);
#else
    sprintf(msg, "VT_METRICS_SPEC not set");
#endif
  }
  vt_cntl_msg(msg);
  return spec;
}

int vt_env_max_num_thrds()
{
  char* tmp = getenv("VT_MAX_NUM_THRDS");
  
  if (tmp != NULL)
    {
      return atoi(tmp);
    }
  return VT_MAX_NUM_THRDS;
}

char* vt_env_nmfile()
{
  return getenv("VT_NMFILE");
}

int vt_env_compression()
{
  char* tmp = getenv("VT_COMPRESSION");
  if (tmp != NULL)
    {
      return parse_bool(tmp);
    }
  return 1;
}

char*  vt_env_filter_spec()
{
  return getenv("VT_FILTER_SPEC");
}

char*  vt_env_groups_spec()
{
  return getenv("VT_GROUPS_SPEC");
}
