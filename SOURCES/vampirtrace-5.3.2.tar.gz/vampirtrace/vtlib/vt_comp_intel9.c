/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2007, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich GmbH, Federal
 * Republic of Germany
 *
 * See the file COPYRIGHT in the package base directory for details
 **/

#include <stdlib.h>
#include <string.h>
#include "vt_comp.h"
#include "vt_memhook.h"
#include "vt_pform.h"
#include "vt_trc.h"

#if (defined (VT_OMPI) || defined (VT_OMP))
#include <omp.h>
#define VT_MY_THREAD   omp_get_thread_num() 
#define VT_NUM_THREADS omp_get_max_threads() 
#else
#define VT_MY_THREAD   0
#define VT_NUM_THREADS 1 
#endif

static long *stk_level;

#define VT_DEF_REGION(str) \
 vt_def_region(str, VT_NO_ID, VT_NO_LNO, VT_NO_LNO, VT_DEF_GROUP, VT_FUNCTION)

static int intel_init = 1;       /* is initialization needed? */

static void intel_wrapup() {
  uint64_t time;

  VT_MEMHOOKS_OFF();

  while(stk_level[VT_MY_THREAD] > 0) {
    stk_level[VT_MY_THREAD]--; 
    time = vt_pform_wtime();
    vt_exit(&time);
  }
  vt_close();
}

/*
 * This function is called at the entry of each function
 */

void VT_IntelEntry(char* str, uint32_t* id) {
  int mt = VT_MY_THREAD;
  uint64_t time;

  VT_MEMHOOKS_OFF();

  /* -- if not yet initialized, initialize VampirTrace -- */
  if ( intel_init ) {
    intel_init = 0;
    stk_level = (long*)calloc(VT_NUM_THREADS, sizeof(long));
    vt_open();
    vt_comp_finalize = &intel_wrapup;
  }

  time = vt_pform_wtime();

  /* -- get region identifier -- */
  if ( *id == 0 ) {
    /* -- region entered the first time, register region -- */
#   if defined (VT_OMPI) || defined (VT_OMP)
    if (omp_in_parallel()) {
#     pragma omp critical (vt_comp_intel_1)
      {
        if (*id == 0) *id = VT_DEF_REGION(str);
      }
    } else {
      *id = VT_DEF_REGION(str);
    }
#   else
    *id = VT_DEF_REGION(str);
#   endif
  }

  /* -- write enter record -- */
  vt_enter(&time, *id);
  stk_level[mt]++;

  VT_MEMHOOKS_ON();
}


/*
 * This function is called at the exit of each function
 */

void VT_IntelExit() {
  int mt = VT_MY_THREAD;
  uint64_t time;

  VT_MEMHOOKS_OFF();

  /* -- write exit record -- */
  time = vt_pform_wtime();
  vt_exit(&time);
  stk_level[mt]--;

  VT_MEMHOOKS_ON();
}
