/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2007, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich GmbH, Federal
 * Republic of Germany
 *
 * See the file COPYRIGHT in the package base directory for details
 **/

#if HAVE_CONFIG_H
#  include <config.h>
#endif

#include <stdio.h>
#include <sys/time.h>
#include "vt_pform.h"
#include <sys/mpconf.h>
#include <sys/sysinfo.h>

static uint64_t vt_time_base = 0;

/* platform specific initialization */
void vt_pform_init() {
  struct timespec tp;
  clock_gettime(CLOCK_SGI_CYCLE,&tp);
  vt_time_base = tp.tv_sec - (tp.tv_sec & 0xFFFF);
}

/* directory of global file system  */
char* vt_pform_gdir() {
  return ".";
}

/* directory of local file system  */
char* vt_pform_ldir() {
  #ifdef PFORM_LDIR
    return PFORM_LDIR;
  #else
    return "/tmp";
  #endif
}

/* is a global clock provided ? */ 
int vt_pform_is_gclock() {
  return 1;
}

/* clock resolution */
uint64_t vt_pform_clockres() {
  return 1e9;
}

/* local or global wall-clock time */
uint64_t vt_pform_wtime() {
  struct timespec tp;
  clock_gettime(CLOCK_SGI_CYCLE,&tp);
  return ((tp.tv_sec - vt_time_base) * 1e9) + tp.tv_nsec;
}

/* unique numeric SMP-node identifier */
long vt_pform_node_id() {
  return gethostid();
}

/* unique string SMP-node identifier */
char* vt_pform_node_name() {
  static char host_name[20];
  gethostname(host_name, 20);
  return host_name;              
}

/* number of CPUs */
int vt_pform_num_cpus() {
  return mpconf(_MIPS_MP_NPROCESSORS);
}
