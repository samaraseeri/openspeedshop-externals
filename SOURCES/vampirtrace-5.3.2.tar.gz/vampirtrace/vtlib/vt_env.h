/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2007, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich GmbH, Federal
 * Republic of Germany
 *
 * See the file COPYRIGHT in the package base directory for details
 **/

#ifndef _VT_ENV_H
#define _VT_ENV_H

#ifdef __cplusplus
#   define EXTERN extern "C" 
#else
#   define EXTERN extern 
#endif

#include <stdio.h>

EXTERN char*  vt_env_apppath();
EXTERN char*  vt_env_dyn_blacklist();
EXTERN char*  vt_env_dyn_shlibs();
EXTERN char*  vt_env_gdir();
EXTERN char*  vt_env_ldir();
EXTERN char*  vt_env_fprefix();
EXTERN size_t vt_env_bsize();
EXTERN int    vt_env_is_verbose();
EXTERN int    vt_env_do_unify();
EXTERN int    vt_env_do_clean();
EXTERN int    vt_env_memtrace();
EXTERN int    vt_env_mpitrace();
EXTERN char*  vt_env_metrics();
EXTERN char*  vt_env_metrics_spec();
EXTERN int    vt_env_max_num_thrds();
EXTERN char*  vt_env_nmfile();
EXTERN int    vt_env_compression();
EXTERN char*  vt_env_filter_spec();
EXTERN char*  vt_env_groups_spec();

#endif



















