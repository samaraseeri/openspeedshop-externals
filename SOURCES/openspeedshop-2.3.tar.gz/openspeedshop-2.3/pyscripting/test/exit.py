# exit

import openss

output = openss.exit()

print output
