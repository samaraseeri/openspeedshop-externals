# Test a redundant exit 
import openss

openss.exit()
openss.exit()
