# Test a single exit 
import openss

openss.exit()
