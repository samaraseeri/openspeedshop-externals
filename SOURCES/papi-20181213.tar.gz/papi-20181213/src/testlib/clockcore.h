#define CLOCKCORE_VIRT_CYC_FAIL	-1
#define CLOCKCORE_VIRT_USEC_FAIL -2

int clockcore( int quiet );

