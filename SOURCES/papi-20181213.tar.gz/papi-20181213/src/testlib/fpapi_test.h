#include "fpapi.h"
#define SUCCESS 1
#define NUM_FLOPS  20000000
