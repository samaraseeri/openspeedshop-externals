int papi_print_header( char *prompt, const PAPI_hw_info_t ** hwinfo );

