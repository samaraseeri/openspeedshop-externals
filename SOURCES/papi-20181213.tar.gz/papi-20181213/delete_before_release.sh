#!/bin/sh
rm PAPI_FAQ.html
rm release_procedure.txt
rm gitlog2changelog.py
rm bitbucket-pipelines.yml
rm doc/DataRange.html
rm doc/PAPI-C.html
rm doc/README
rm src/buildbot_configure_with_components.sh
rm -rf .git
rm delete_before_release.sh
rm src/ctests/.gitignore
rm src/libpfm4/.gitignore
rm src/utils/.gitignore
rm src/.gitignore
rm src/ftests/.gitignore
rm src/testlib/.gitignore
rm src/components/.gitignore
