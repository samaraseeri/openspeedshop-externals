#include "DevicesSortFilterProxyModel.h"

DevicesSortFilterProxyModel::DevicesSortFilterProxyModel(QObject *parent) : QObject(parent)
{

}
