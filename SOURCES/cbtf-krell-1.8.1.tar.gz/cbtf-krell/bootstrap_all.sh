#! /bin/bash
cd contrib
./bootstrap
cd ..
cd core
./bootstrap
cd ..
cd examples
./bootstrap
cd ..
cd messages
./bootstrap
cd ..
cd services
./bootstrap
cd ..
cd test
./bootstrap
cd ..
