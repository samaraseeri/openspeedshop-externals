#include <stdio.h>

int main(int argc, char**argv)
{
    printf("hello\n");
    return 0;
}

void _start() {}
void _fini() {}
void _init() {}
void _Unwind_Resume() {}
void _Unwind_Backtrace() {}
void _Unwind_GetIP() {}

/*
void _dl_resolve_conflicts() {

}
*/

void _dl_rtld_map() {}
void _dl_num_cache_relocations() {}
void __gcc_personality_v0() {}
void __divdi3() {}
void __moddi3() {}
void __umoddi3() {}
void __udivdi3(){}
void _Unwind_GetGR(){}
void _Unwind_GetCFA(){}
void _dl_num_relocations(){}
void __rel_iplt_start(){}
void __rel_iplt_end(){}
void __validuser2_sa(){}
